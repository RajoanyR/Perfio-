export {};
//# sourceMappingURL=transfert_tache.js.map