import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type roleModel = runtime.Types.Result.DefaultSelection<Prisma.$rolePayload>;
export type AggregateRole = {
    _count: RoleCountAggregateOutputType | null;
    _avg: RoleAvgAggregateOutputType | null;
    _sum: RoleSumAggregateOutputType | null;
    _min: RoleMinAggregateOutputType | null;
    _max: RoleMaxAggregateOutputType | null;
};
export type RoleAvgAggregateOutputType = {
    id_role: number | null;
};
export type RoleSumAggregateOutputType = {
    id_role: bigint | null;
};
export type RoleMinAggregateOutputType = {
    id_role: bigint | null;
    nom_role: string | null;
    description: string | null;
};
export type RoleMaxAggregateOutputType = {
    id_role: bigint | null;
    nom_role: string | null;
    description: string | null;
};
export type RoleCountAggregateOutputType = {
    id_role: number;
    nom_role: number;
    description: number;
    _all: number;
};
export type RoleAvgAggregateInputType = {
    id_role?: true;
};
export type RoleSumAggregateInputType = {
    id_role?: true;
};
export type RoleMinAggregateInputType = {
    id_role?: true;
    nom_role?: true;
    description?: true;
};
export type RoleMaxAggregateInputType = {
    id_role?: true;
    nom_role?: true;
    description?: true;
};
export type RoleCountAggregateInputType = {
    id_role?: true;
    nom_role?: true;
    description?: true;
    _all?: true;
};
export type RoleAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.roleWhereInput;
    orderBy?: Prisma.roleOrderByWithRelationInput | Prisma.roleOrderByWithRelationInput[];
    cursor?: Prisma.roleWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | RoleCountAggregateInputType;
    _avg?: RoleAvgAggregateInputType;
    _sum?: RoleSumAggregateInputType;
    _min?: RoleMinAggregateInputType;
    _max?: RoleMaxAggregateInputType;
};
export type GetRoleAggregateType<T extends RoleAggregateArgs> = {
    [P in keyof T & keyof AggregateRole]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateRole[P]> : Prisma.GetScalarType<T[P], AggregateRole[P]>;
};
export type roleGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.roleWhereInput;
    orderBy?: Prisma.roleOrderByWithAggregationInput | Prisma.roleOrderByWithAggregationInput[];
    by: Prisma.RoleScalarFieldEnum[] | Prisma.RoleScalarFieldEnum;
    having?: Prisma.roleScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: RoleCountAggregateInputType | true;
    _avg?: RoleAvgAggregateInputType;
    _sum?: RoleSumAggregateInputType;
    _min?: RoleMinAggregateInputType;
    _max?: RoleMaxAggregateInputType;
};
export type RoleGroupByOutputType = {
    id_role: bigint;
    nom_role: string;
    description: string | null;
    _count: RoleCountAggregateOutputType | null;
    _avg: RoleAvgAggregateOutputType | null;
    _sum: RoleSumAggregateOutputType | null;
    _min: RoleMinAggregateOutputType | null;
    _max: RoleMaxAggregateOutputType | null;
};
export type GetRoleGroupByPayload<T extends roleGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<RoleGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof RoleGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], RoleGroupByOutputType[P]> : Prisma.GetScalarType<T[P], RoleGroupByOutputType[P]>;
}>>;
export type roleWhereInput = {
    AND?: Prisma.roleWhereInput | Prisma.roleWhereInput[];
    OR?: Prisma.roleWhereInput[];
    NOT?: Prisma.roleWhereInput | Prisma.roleWhereInput[];
    id_role?: Prisma.BigIntFilter<"role"> | bigint | number;
    nom_role?: Prisma.StringFilter<"role"> | string;
    description?: Prisma.StringNullableFilter<"role"> | string | null;
    role_permission?: Prisma.Role_permissionListRelationFilter;
    utilisateur?: Prisma.UtilisateurListRelationFilter;
};
export type roleOrderByWithRelationInput = {
    id_role?: Prisma.SortOrder;
    nom_role?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    role_permission?: Prisma.role_permissionOrderByRelationAggregateInput;
    utilisateur?: Prisma.utilisateurOrderByRelationAggregateInput;
};
export type roleWhereUniqueInput = Prisma.AtLeast<{
    id_role?: bigint | number;
    nom_role?: string;
    AND?: Prisma.roleWhereInput | Prisma.roleWhereInput[];
    OR?: Prisma.roleWhereInput[];
    NOT?: Prisma.roleWhereInput | Prisma.roleWhereInput[];
    description?: Prisma.StringNullableFilter<"role"> | string | null;
    role_permission?: Prisma.Role_permissionListRelationFilter;
    utilisateur?: Prisma.UtilisateurListRelationFilter;
}, "id_role" | "nom_role">;
export type roleOrderByWithAggregationInput = {
    id_role?: Prisma.SortOrder;
    nom_role?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    _count?: Prisma.roleCountOrderByAggregateInput;
    _avg?: Prisma.roleAvgOrderByAggregateInput;
    _max?: Prisma.roleMaxOrderByAggregateInput;
    _min?: Prisma.roleMinOrderByAggregateInput;
    _sum?: Prisma.roleSumOrderByAggregateInput;
};
export type roleScalarWhereWithAggregatesInput = {
    AND?: Prisma.roleScalarWhereWithAggregatesInput | Prisma.roleScalarWhereWithAggregatesInput[];
    OR?: Prisma.roleScalarWhereWithAggregatesInput[];
    NOT?: Prisma.roleScalarWhereWithAggregatesInput | Prisma.roleScalarWhereWithAggregatesInput[];
    id_role?: Prisma.BigIntWithAggregatesFilter<"role"> | bigint | number;
    nom_role?: Prisma.StringWithAggregatesFilter<"role"> | string;
    description?: Prisma.StringNullableWithAggregatesFilter<"role"> | string | null;
};
export type roleCreateInput = {
    id_role?: bigint | number;
    nom_role: string;
    description?: string | null;
    role_permission?: Prisma.role_permissionCreateNestedManyWithoutRoleInput;
    utilisateur?: Prisma.utilisateurCreateNestedManyWithoutRoleInput;
};
export type roleUncheckedCreateInput = {
    id_role?: bigint | number;
    nom_role: string;
    description?: string | null;
    role_permission?: Prisma.role_permissionUncheckedCreateNestedManyWithoutRoleInput;
    utilisateur?: Prisma.utilisateurUncheckedCreateNestedManyWithoutRoleInput;
};
export type roleUpdateInput = {
    id_role?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_role?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    role_permission?: Prisma.role_permissionUpdateManyWithoutRoleNestedInput;
    utilisateur?: Prisma.utilisateurUpdateManyWithoutRoleNestedInput;
};
export type roleUncheckedUpdateInput = {
    id_role?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_role?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    role_permission?: Prisma.role_permissionUncheckedUpdateManyWithoutRoleNestedInput;
    utilisateur?: Prisma.utilisateurUncheckedUpdateManyWithoutRoleNestedInput;
};
export type roleCreateManyInput = {
    id_role?: bigint | number;
    nom_role: string;
    description?: string | null;
};
export type roleUpdateManyMutationInput = {
    id_role?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_role?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
};
export type roleUncheckedUpdateManyInput = {
    id_role?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_role?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
};
export type roleCountOrderByAggregateInput = {
    id_role?: Prisma.SortOrder;
    nom_role?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
};
export type roleAvgOrderByAggregateInput = {
    id_role?: Prisma.SortOrder;
};
export type roleMaxOrderByAggregateInput = {
    id_role?: Prisma.SortOrder;
    nom_role?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
};
export type roleMinOrderByAggregateInput = {
    id_role?: Prisma.SortOrder;
    nom_role?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
};
export type roleSumOrderByAggregateInput = {
    id_role?: Prisma.SortOrder;
};
export type RoleScalarRelationFilter = {
    is?: Prisma.roleWhereInput;
    isNot?: Prisma.roleWhereInput;
};
export type roleCreateNestedOneWithoutRole_permissionInput = {
    create?: Prisma.XOR<Prisma.roleCreateWithoutRole_permissionInput, Prisma.roleUncheckedCreateWithoutRole_permissionInput>;
    connectOrCreate?: Prisma.roleCreateOrConnectWithoutRole_permissionInput;
    connect?: Prisma.roleWhereUniqueInput;
};
export type roleUpdateOneRequiredWithoutRole_permissionNestedInput = {
    create?: Prisma.XOR<Prisma.roleCreateWithoutRole_permissionInput, Prisma.roleUncheckedCreateWithoutRole_permissionInput>;
    connectOrCreate?: Prisma.roleCreateOrConnectWithoutRole_permissionInput;
    upsert?: Prisma.roleUpsertWithoutRole_permissionInput;
    connect?: Prisma.roleWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.roleUpdateToOneWithWhereWithoutRole_permissionInput, Prisma.roleUpdateWithoutRole_permissionInput>, Prisma.roleUncheckedUpdateWithoutRole_permissionInput>;
};
export type roleCreateNestedOneWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.roleCreateWithoutUtilisateurInput, Prisma.roleUncheckedCreateWithoutUtilisateurInput>;
    connectOrCreate?: Prisma.roleCreateOrConnectWithoutUtilisateurInput;
    connect?: Prisma.roleWhereUniqueInput;
};
export type roleUpdateOneRequiredWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.roleCreateWithoutUtilisateurInput, Prisma.roleUncheckedCreateWithoutUtilisateurInput>;
    connectOrCreate?: Prisma.roleCreateOrConnectWithoutUtilisateurInput;
    upsert?: Prisma.roleUpsertWithoutUtilisateurInput;
    connect?: Prisma.roleWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.roleUpdateToOneWithWhereWithoutUtilisateurInput, Prisma.roleUpdateWithoutUtilisateurInput>, Prisma.roleUncheckedUpdateWithoutUtilisateurInput>;
};
export type roleCreateWithoutRole_permissionInput = {
    id_role?: bigint | number;
    nom_role: string;
    description?: string | null;
    utilisateur?: Prisma.utilisateurCreateNestedManyWithoutRoleInput;
};
export type roleUncheckedCreateWithoutRole_permissionInput = {
    id_role?: bigint | number;
    nom_role: string;
    description?: string | null;
    utilisateur?: Prisma.utilisateurUncheckedCreateNestedManyWithoutRoleInput;
};
export type roleCreateOrConnectWithoutRole_permissionInput = {
    where: Prisma.roleWhereUniqueInput;
    create: Prisma.XOR<Prisma.roleCreateWithoutRole_permissionInput, Prisma.roleUncheckedCreateWithoutRole_permissionInput>;
};
export type roleUpsertWithoutRole_permissionInput = {
    update: Prisma.XOR<Prisma.roleUpdateWithoutRole_permissionInput, Prisma.roleUncheckedUpdateWithoutRole_permissionInput>;
    create: Prisma.XOR<Prisma.roleCreateWithoutRole_permissionInput, Prisma.roleUncheckedCreateWithoutRole_permissionInput>;
    where?: Prisma.roleWhereInput;
};
export type roleUpdateToOneWithWhereWithoutRole_permissionInput = {
    where?: Prisma.roleWhereInput;
    data: Prisma.XOR<Prisma.roleUpdateWithoutRole_permissionInput, Prisma.roleUncheckedUpdateWithoutRole_permissionInput>;
};
export type roleUpdateWithoutRole_permissionInput = {
    id_role?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_role?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    utilisateur?: Prisma.utilisateurUpdateManyWithoutRoleNestedInput;
};
export type roleUncheckedUpdateWithoutRole_permissionInput = {
    id_role?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_role?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    utilisateur?: Prisma.utilisateurUncheckedUpdateManyWithoutRoleNestedInput;
};
export type roleCreateWithoutUtilisateurInput = {
    id_role?: bigint | number;
    nom_role: string;
    description?: string | null;
    role_permission?: Prisma.role_permissionCreateNestedManyWithoutRoleInput;
};
export type roleUncheckedCreateWithoutUtilisateurInput = {
    id_role?: bigint | number;
    nom_role: string;
    description?: string | null;
    role_permission?: Prisma.role_permissionUncheckedCreateNestedManyWithoutRoleInput;
};
export type roleCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.roleWhereUniqueInput;
    create: Prisma.XOR<Prisma.roleCreateWithoutUtilisateurInput, Prisma.roleUncheckedCreateWithoutUtilisateurInput>;
};
export type roleUpsertWithoutUtilisateurInput = {
    update: Prisma.XOR<Prisma.roleUpdateWithoutUtilisateurInput, Prisma.roleUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.roleCreateWithoutUtilisateurInput, Prisma.roleUncheckedCreateWithoutUtilisateurInput>;
    where?: Prisma.roleWhereInput;
};
export type roleUpdateToOneWithWhereWithoutUtilisateurInput = {
    where?: Prisma.roleWhereInput;
    data: Prisma.XOR<Prisma.roleUpdateWithoutUtilisateurInput, Prisma.roleUncheckedUpdateWithoutUtilisateurInput>;
};
export type roleUpdateWithoutUtilisateurInput = {
    id_role?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_role?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    role_permission?: Prisma.role_permissionUpdateManyWithoutRoleNestedInput;
};
export type roleUncheckedUpdateWithoutUtilisateurInput = {
    id_role?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_role?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    role_permission?: Prisma.role_permissionUncheckedUpdateManyWithoutRoleNestedInput;
};
export type RoleCountOutputType = {
    role_permission: number;
    utilisateur: number;
};
export type RoleCountOutputTypeSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    role_permission?: boolean | RoleCountOutputTypeCountRole_permissionArgs;
    utilisateur?: boolean | RoleCountOutputTypeCountUtilisateurArgs;
};
export type RoleCountOutputTypeDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.RoleCountOutputTypeSelect<ExtArgs> | null;
};
export type RoleCountOutputTypeCountRole_permissionArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.role_permissionWhereInput;
};
export type RoleCountOutputTypeCountUtilisateurArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.utilisateurWhereInput;
};
export type roleSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_role?: boolean;
    nom_role?: boolean;
    description?: boolean;
    role_permission?: boolean | Prisma.role$role_permissionArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.role$utilisateurArgs<ExtArgs>;
    _count?: boolean | Prisma.RoleCountOutputTypeDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["role"]>;
export type roleSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_role?: boolean;
    nom_role?: boolean;
    description?: boolean;
}, ExtArgs["result"]["role"]>;
export type roleSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_role?: boolean;
    nom_role?: boolean;
    description?: boolean;
}, ExtArgs["result"]["role"]>;
export type roleSelectScalar = {
    id_role?: boolean;
    nom_role?: boolean;
    description?: boolean;
};
export type roleOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_role" | "nom_role" | "description", ExtArgs["result"]["role"]>;
export type roleInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    role_permission?: boolean | Prisma.role$role_permissionArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.role$utilisateurArgs<ExtArgs>;
    _count?: boolean | Prisma.RoleCountOutputTypeDefaultArgs<ExtArgs>;
};
export type roleIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {};
export type roleIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {};
export type $rolePayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "role";
    objects: {
        role_permission: Prisma.$role_permissionPayload<ExtArgs>[];
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>[];
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_role: bigint;
        nom_role: string;
        description: string | null;
    }, ExtArgs["result"]["role"]>;
    composites: {};
};
export type roleGetPayload<S extends boolean | null | undefined | roleDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$rolePayload, S>;
export type roleCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<roleFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: RoleCountAggregateInputType | true;
};
export interface roleDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['role'];
        meta: {
            name: 'role';
        };
    };
    findUnique<T extends roleFindUniqueArgs>(args: Prisma.SelectSubset<T, roleFindUniqueArgs<ExtArgs>>): Prisma.Prisma__roleClient<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends roleFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, roleFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__roleClient<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends roleFindFirstArgs>(args?: Prisma.SelectSubset<T, roleFindFirstArgs<ExtArgs>>): Prisma.Prisma__roleClient<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends roleFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, roleFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__roleClient<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends roleFindManyArgs>(args?: Prisma.SelectSubset<T, roleFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends roleCreateArgs>(args: Prisma.SelectSubset<T, roleCreateArgs<ExtArgs>>): Prisma.Prisma__roleClient<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends roleCreateManyArgs>(args?: Prisma.SelectSubset<T, roleCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends roleCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, roleCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends roleDeleteArgs>(args: Prisma.SelectSubset<T, roleDeleteArgs<ExtArgs>>): Prisma.Prisma__roleClient<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends roleUpdateArgs>(args: Prisma.SelectSubset<T, roleUpdateArgs<ExtArgs>>): Prisma.Prisma__roleClient<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends roleDeleteManyArgs>(args?: Prisma.SelectSubset<T, roleDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends roleUpdateManyArgs>(args: Prisma.SelectSubset<T, roleUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends roleUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, roleUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends roleUpsertArgs>(args: Prisma.SelectSubset<T, roleUpsertArgs<ExtArgs>>): Prisma.Prisma__roleClient<runtime.Types.Result.GetResult<Prisma.$rolePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends roleCountArgs>(args?: Prisma.Subset<T, roleCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], RoleCountAggregateOutputType> : number>;
    aggregate<T extends RoleAggregateArgs>(args: Prisma.Subset<T, RoleAggregateArgs>): Prisma.PrismaPromise<GetRoleAggregateType<T>>;
    groupBy<T extends roleGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: roleGroupByArgs['orderBy'];
    } : {
        orderBy?: roleGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, roleGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRoleGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: roleFieldRefs;
}
export interface Prisma__roleClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    role_permission<T extends Prisma.role$role_permissionArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.role$role_permissionArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$role_permissionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    utilisateur<T extends Prisma.role$utilisateurArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.role$utilisateurArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface roleFieldRefs {
    readonly id_role: Prisma.FieldRef<"role", 'BigInt'>;
    readonly nom_role: Prisma.FieldRef<"role", 'String'>;
    readonly description: Prisma.FieldRef<"role", 'String'>;
}
export type roleFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    where: Prisma.roleWhereUniqueInput;
};
export type roleFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    where: Prisma.roleWhereUniqueInput;
};
export type roleFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    where?: Prisma.roleWhereInput;
    orderBy?: Prisma.roleOrderByWithRelationInput | Prisma.roleOrderByWithRelationInput[];
    cursor?: Prisma.roleWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.RoleScalarFieldEnum | Prisma.RoleScalarFieldEnum[];
};
export type roleFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    where?: Prisma.roleWhereInput;
    orderBy?: Prisma.roleOrderByWithRelationInput | Prisma.roleOrderByWithRelationInput[];
    cursor?: Prisma.roleWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.RoleScalarFieldEnum | Prisma.RoleScalarFieldEnum[];
};
export type roleFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    where?: Prisma.roleWhereInput;
    orderBy?: Prisma.roleOrderByWithRelationInput | Prisma.roleOrderByWithRelationInput[];
    cursor?: Prisma.roleWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.RoleScalarFieldEnum | Prisma.RoleScalarFieldEnum[];
};
export type roleCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.roleCreateInput, Prisma.roleUncheckedCreateInput>;
};
export type roleCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.roleCreateManyInput | Prisma.roleCreateManyInput[];
    skipDuplicates?: boolean;
};
export type roleCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    data: Prisma.roleCreateManyInput | Prisma.roleCreateManyInput[];
    skipDuplicates?: boolean;
};
export type roleUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.roleUpdateInput, Prisma.roleUncheckedUpdateInput>;
    where: Prisma.roleWhereUniqueInput;
};
export type roleUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.roleUpdateManyMutationInput, Prisma.roleUncheckedUpdateManyInput>;
    where?: Prisma.roleWhereInput;
    limit?: number;
};
export type roleUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.roleUpdateManyMutationInput, Prisma.roleUncheckedUpdateManyInput>;
    where?: Prisma.roleWhereInput;
    limit?: number;
};
export type roleUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    where: Prisma.roleWhereUniqueInput;
    create: Prisma.XOR<Prisma.roleCreateInput, Prisma.roleUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.roleUpdateInput, Prisma.roleUncheckedUpdateInput>;
};
export type roleDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
    where: Prisma.roleWhereUniqueInput;
};
export type roleDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.roleWhereInput;
    limit?: number;
};
export type role$role_permissionArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.role_permissionSelect<ExtArgs> | null;
    omit?: Prisma.role_permissionOmit<ExtArgs> | null;
    include?: Prisma.role_permissionInclude<ExtArgs> | null;
    where?: Prisma.role_permissionWhereInput;
    orderBy?: Prisma.role_permissionOrderByWithRelationInput | Prisma.role_permissionOrderByWithRelationInput[];
    cursor?: Prisma.role_permissionWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Role_permissionScalarFieldEnum | Prisma.Role_permissionScalarFieldEnum[];
};
export type role$utilisateurArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.utilisateurSelect<ExtArgs> | null;
    omit?: Prisma.utilisateurOmit<ExtArgs> | null;
    include?: Prisma.utilisateurInclude<ExtArgs> | null;
    where?: Prisma.utilisateurWhereInput;
    orderBy?: Prisma.utilisateurOrderByWithRelationInput | Prisma.utilisateurOrderByWithRelationInput[];
    cursor?: Prisma.utilisateurWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.UtilisateurScalarFieldEnum | Prisma.UtilisateurScalarFieldEnum[];
};
export type roleDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.roleSelect<ExtArgs> | null;
    omit?: Prisma.roleOmit<ExtArgs> | null;
    include?: Prisma.roleInclude<ExtArgs> | null;
};
