import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type equipeModel = runtime.Types.Result.DefaultSelection<Prisma.$equipePayload>;
export type AggregateEquipe = {
    _count: EquipeCountAggregateOutputType | null;
    _avg: EquipeAvgAggregateOutputType | null;
    _sum: EquipeSumAggregateOutputType | null;
    _min: EquipeMinAggregateOutputType | null;
    _max: EquipeMaxAggregateOutputType | null;
};
export type EquipeAvgAggregateOutputType = {
    id_equipe: number | null;
};
export type EquipeSumAggregateOutputType = {
    id_equipe: bigint | null;
};
export type EquipeMinAggregateOutputType = {
    id_equipe: bigint | null;
    nom_equipe: string | null;
    description: string | null;
    statut: string | null;
    date_creation: Date | null;
};
export type EquipeMaxAggregateOutputType = {
    id_equipe: bigint | null;
    nom_equipe: string | null;
    description: string | null;
    statut: string | null;
    date_creation: Date | null;
};
export type EquipeCountAggregateOutputType = {
    id_equipe: number;
    nom_equipe: number;
    description: number;
    statut: number;
    date_creation: number;
    _all: number;
};
export type EquipeAvgAggregateInputType = {
    id_equipe?: true;
};
export type EquipeSumAggregateInputType = {
    id_equipe?: true;
};
export type EquipeMinAggregateInputType = {
    id_equipe?: true;
    nom_equipe?: true;
    description?: true;
    statut?: true;
    date_creation?: true;
};
export type EquipeMaxAggregateInputType = {
    id_equipe?: true;
    nom_equipe?: true;
    description?: true;
    statut?: true;
    date_creation?: true;
};
export type EquipeCountAggregateInputType = {
    id_equipe?: true;
    nom_equipe?: true;
    description?: true;
    statut?: true;
    date_creation?: true;
    _all?: true;
};
export type EquipeAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.equipeWhereInput;
    orderBy?: Prisma.equipeOrderByWithRelationInput | Prisma.equipeOrderByWithRelationInput[];
    cursor?: Prisma.equipeWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | EquipeCountAggregateInputType;
    _avg?: EquipeAvgAggregateInputType;
    _sum?: EquipeSumAggregateInputType;
    _min?: EquipeMinAggregateInputType;
    _max?: EquipeMaxAggregateInputType;
};
export type GetEquipeAggregateType<T extends EquipeAggregateArgs> = {
    [P in keyof T & keyof AggregateEquipe]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateEquipe[P]> : Prisma.GetScalarType<T[P], AggregateEquipe[P]>;
};
export type equipeGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.equipeWhereInput;
    orderBy?: Prisma.equipeOrderByWithAggregationInput | Prisma.equipeOrderByWithAggregationInput[];
    by: Prisma.EquipeScalarFieldEnum[] | Prisma.EquipeScalarFieldEnum;
    having?: Prisma.equipeScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: EquipeCountAggregateInputType | true;
    _avg?: EquipeAvgAggregateInputType;
    _sum?: EquipeSumAggregateInputType;
    _min?: EquipeMinAggregateInputType;
    _max?: EquipeMaxAggregateInputType;
};
export type EquipeGroupByOutputType = {
    id_equipe: bigint;
    nom_equipe: string;
    description: string | null;
    statut: string;
    date_creation: Date;
    _count: EquipeCountAggregateOutputType | null;
    _avg: EquipeAvgAggregateOutputType | null;
    _sum: EquipeSumAggregateOutputType | null;
    _min: EquipeMinAggregateOutputType | null;
    _max: EquipeMaxAggregateOutputType | null;
};
export type GetEquipeGroupByPayload<T extends equipeGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<EquipeGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof EquipeGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], EquipeGroupByOutputType[P]> : Prisma.GetScalarType<T[P], EquipeGroupByOutputType[P]>;
}>>;
export type equipeWhereInput = {
    AND?: Prisma.equipeWhereInput | Prisma.equipeWhereInput[];
    OR?: Prisma.equipeWhereInput[];
    NOT?: Prisma.equipeWhereInput | Prisma.equipeWhereInput[];
    id_equipe?: Prisma.BigIntFilter<"equipe"> | bigint | number;
    nom_equipe?: Prisma.StringFilter<"equipe"> | string;
    description?: Prisma.StringNullableFilter<"equipe"> | string | null;
    statut?: Prisma.StringFilter<"equipe"> | string;
    date_creation?: Prisma.DateTimeFilter<"equipe"> | Date | string;
    projet?: Prisma.ProjetListRelationFilter;
    tache?: Prisma.TacheListRelationFilter;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.Transfert_tacheListRelationFilter;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.Transfert_tacheListRelationFilter;
    utilisateur?: Prisma.UtilisateurListRelationFilter;
};
export type equipeOrderByWithRelationInput = {
    id_equipe?: Prisma.SortOrder;
    nom_equipe?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    projet?: Prisma.projetOrderByRelationAggregateInput;
    tache?: Prisma.tacheOrderByRelationAggregateInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheOrderByRelationAggregateInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheOrderByRelationAggregateInput;
    utilisateur?: Prisma.utilisateurOrderByRelationAggregateInput;
};
export type equipeWhereUniqueInput = Prisma.AtLeast<{
    id_equipe?: bigint | number;
    nom_equipe?: string;
    AND?: Prisma.equipeWhereInput | Prisma.equipeWhereInput[];
    OR?: Prisma.equipeWhereInput[];
    NOT?: Prisma.equipeWhereInput | Prisma.equipeWhereInput[];
    description?: Prisma.StringNullableFilter<"equipe"> | string | null;
    statut?: Prisma.StringFilter<"equipe"> | string;
    date_creation?: Prisma.DateTimeFilter<"equipe"> | Date | string;
    projet?: Prisma.ProjetListRelationFilter;
    tache?: Prisma.TacheListRelationFilter;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.Transfert_tacheListRelationFilter;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.Transfert_tacheListRelationFilter;
    utilisateur?: Prisma.UtilisateurListRelationFilter;
}, "id_equipe" | "nom_equipe">;
export type equipeOrderByWithAggregationInput = {
    id_equipe?: Prisma.SortOrder;
    nom_equipe?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    _count?: Prisma.equipeCountOrderByAggregateInput;
    _avg?: Prisma.equipeAvgOrderByAggregateInput;
    _max?: Prisma.equipeMaxOrderByAggregateInput;
    _min?: Prisma.equipeMinOrderByAggregateInput;
    _sum?: Prisma.equipeSumOrderByAggregateInput;
};
export type equipeScalarWhereWithAggregatesInput = {
    AND?: Prisma.equipeScalarWhereWithAggregatesInput | Prisma.equipeScalarWhereWithAggregatesInput[];
    OR?: Prisma.equipeScalarWhereWithAggregatesInput[];
    NOT?: Prisma.equipeScalarWhereWithAggregatesInput | Prisma.equipeScalarWhereWithAggregatesInput[];
    id_equipe?: Prisma.BigIntWithAggregatesFilter<"equipe"> | bigint | number;
    nom_equipe?: Prisma.StringWithAggregatesFilter<"equipe"> | string;
    description?: Prisma.StringNullableWithAggregatesFilter<"equipe"> | string | null;
    statut?: Prisma.StringWithAggregatesFilter<"equipe"> | string;
    date_creation?: Prisma.DateTimeWithAggregatesFilter<"equipe"> | Date | string;
};
export type equipeCreateInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetCreateNestedManyWithoutEquipeInput;
    tache?: Prisma.tacheCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurCreateNestedManyWithoutEquipeInput;
};
export type equipeUncheckedCreateInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetUncheckedCreateNestedManyWithoutEquipeInput;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurUncheckedCreateNestedManyWithoutEquipeInput;
};
export type equipeUpdateInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUpdateManyWithoutEquipeNestedInput;
    tache?: Prisma.tacheUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUpdateManyWithoutEquipeNestedInput;
};
export type equipeUncheckedUpdateInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUncheckedUpdateManyWithoutEquipeNestedInput;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUncheckedUpdateManyWithoutEquipeNestedInput;
};
export type equipeCreateManyInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
};
export type equipeUpdateManyMutationInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type equipeUncheckedUpdateManyInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type equipeCountOrderByAggregateInput = {
    id_equipe?: Prisma.SortOrder;
    nom_equipe?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type equipeAvgOrderByAggregateInput = {
    id_equipe?: Prisma.SortOrder;
};
export type equipeMaxOrderByAggregateInput = {
    id_equipe?: Prisma.SortOrder;
    nom_equipe?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type equipeMinOrderByAggregateInput = {
    id_equipe?: Prisma.SortOrder;
    nom_equipe?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type equipeSumOrderByAggregateInput = {
    id_equipe?: Prisma.SortOrder;
};
export type EquipeScalarRelationFilter = {
    is?: Prisma.equipeWhereInput;
    isNot?: Prisma.equipeWhereInput;
};
export type equipeCreateNestedOneWithoutProjetInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutProjetInput, Prisma.equipeUncheckedCreateWithoutProjetInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutProjetInput;
    connect?: Prisma.equipeWhereUniqueInput;
};
export type equipeUpdateOneRequiredWithoutProjetNestedInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutProjetInput, Prisma.equipeUncheckedCreateWithoutProjetInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutProjetInput;
    upsert?: Prisma.equipeUpsertWithoutProjetInput;
    connect?: Prisma.equipeWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.equipeUpdateToOneWithWhereWithoutProjetInput, Prisma.equipeUpdateWithoutProjetInput>, Prisma.equipeUncheckedUpdateWithoutProjetInput>;
};
export type equipeCreateNestedOneWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutTacheInput, Prisma.equipeUncheckedCreateWithoutTacheInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutTacheInput;
    connect?: Prisma.equipeWhereUniqueInput;
};
export type equipeUpdateOneRequiredWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutTacheInput, Prisma.equipeUncheckedCreateWithoutTacheInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutTacheInput;
    upsert?: Prisma.equipeUpsertWithoutTacheInput;
    connect?: Prisma.equipeWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.equipeUpdateToOneWithWhereWithoutTacheInput, Prisma.equipeUpdateWithoutTacheInput>, Prisma.equipeUncheckedUpdateWithoutTacheInput>;
};
export type equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput, Prisma.equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    connect?: Prisma.equipeWhereUniqueInput;
};
export type equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput, Prisma.equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
    connect?: Prisma.equipeWhereUniqueInput;
};
export type equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeNestedInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput, Prisma.equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    upsert?: Prisma.equipeUpsertWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    connect?: Prisma.equipeWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.equipeUpdateToOneWithWhereWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput, Prisma.equipeUpdateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput>, Prisma.equipeUncheckedUpdateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput>;
};
export type equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeNestedInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput, Prisma.equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
    upsert?: Prisma.equipeUpsertWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
    connect?: Prisma.equipeWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.equipeUpdateToOneWithWhereWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput, Prisma.equipeUpdateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput>, Prisma.equipeUncheckedUpdateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput>;
};
export type equipeCreateNestedOneWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutUtilisateurInput, Prisma.equipeUncheckedCreateWithoutUtilisateurInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutUtilisateurInput;
    connect?: Prisma.equipeWhereUniqueInput;
};
export type equipeUpdateOneRequiredWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.equipeCreateWithoutUtilisateurInput, Prisma.equipeUncheckedCreateWithoutUtilisateurInput>;
    connectOrCreate?: Prisma.equipeCreateOrConnectWithoutUtilisateurInput;
    upsert?: Prisma.equipeUpsertWithoutUtilisateurInput;
    connect?: Prisma.equipeWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.equipeUpdateToOneWithWhereWithoutUtilisateurInput, Prisma.equipeUpdateWithoutUtilisateurInput>, Prisma.equipeUncheckedUpdateWithoutUtilisateurInput>;
};
export type equipeCreateWithoutProjetInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    tache?: Prisma.tacheCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurCreateNestedManyWithoutEquipeInput;
};
export type equipeUncheckedCreateWithoutProjetInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurUncheckedCreateNestedManyWithoutEquipeInput;
};
export type equipeCreateOrConnectWithoutProjetInput = {
    where: Prisma.equipeWhereUniqueInput;
    create: Prisma.XOR<Prisma.equipeCreateWithoutProjetInput, Prisma.equipeUncheckedCreateWithoutProjetInput>;
};
export type equipeUpsertWithoutProjetInput = {
    update: Prisma.XOR<Prisma.equipeUpdateWithoutProjetInput, Prisma.equipeUncheckedUpdateWithoutProjetInput>;
    create: Prisma.XOR<Prisma.equipeCreateWithoutProjetInput, Prisma.equipeUncheckedCreateWithoutProjetInput>;
    where?: Prisma.equipeWhereInput;
};
export type equipeUpdateToOneWithWhereWithoutProjetInput = {
    where?: Prisma.equipeWhereInput;
    data: Prisma.XOR<Prisma.equipeUpdateWithoutProjetInput, Prisma.equipeUncheckedUpdateWithoutProjetInput>;
};
export type equipeUpdateWithoutProjetInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUpdateManyWithoutEquipeNestedInput;
};
export type equipeUncheckedUpdateWithoutProjetInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUncheckedUpdateManyWithoutEquipeNestedInput;
};
export type equipeCreateWithoutTacheInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurCreateNestedManyWithoutEquipeInput;
};
export type equipeUncheckedCreateWithoutTacheInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetUncheckedCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurUncheckedCreateNestedManyWithoutEquipeInput;
};
export type equipeCreateOrConnectWithoutTacheInput = {
    where: Prisma.equipeWhereUniqueInput;
    create: Prisma.XOR<Prisma.equipeCreateWithoutTacheInput, Prisma.equipeUncheckedCreateWithoutTacheInput>;
};
export type equipeUpsertWithoutTacheInput = {
    update: Prisma.XOR<Prisma.equipeUpdateWithoutTacheInput, Prisma.equipeUncheckedUpdateWithoutTacheInput>;
    create: Prisma.XOR<Prisma.equipeCreateWithoutTacheInput, Prisma.equipeUncheckedCreateWithoutTacheInput>;
    where?: Prisma.equipeWhereInput;
};
export type equipeUpdateToOneWithWhereWithoutTacheInput = {
    where?: Prisma.equipeWhereInput;
    data: Prisma.XOR<Prisma.equipeUpdateWithoutTacheInput, Prisma.equipeUncheckedUpdateWithoutTacheInput>;
};
export type equipeUpdateWithoutTacheInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUpdateManyWithoutEquipeNestedInput;
};
export type equipeUncheckedUpdateWithoutTacheInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUncheckedUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUncheckedUpdateManyWithoutEquipeNestedInput;
};
export type equipeCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetCreateNestedManyWithoutEquipeInput;
    tache?: Prisma.tacheCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurCreateNestedManyWithoutEquipeInput;
};
export type equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetUncheckedCreateNestedManyWithoutEquipeInput;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurUncheckedCreateNestedManyWithoutEquipeInput;
};
export type equipeCreateOrConnectWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput = {
    where: Prisma.equipeWhereUniqueInput;
    create: Prisma.XOR<Prisma.equipeCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput, Prisma.equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput>;
};
export type equipeCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetCreateNestedManyWithoutEquipeInput;
    tache?: Prisma.tacheCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurCreateNestedManyWithoutEquipeInput;
};
export type equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetUncheckedCreateNestedManyWithoutEquipeInput;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    utilisateur?: Prisma.utilisateurUncheckedCreateNestedManyWithoutEquipeInput;
};
export type equipeCreateOrConnectWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput = {
    where: Prisma.equipeWhereUniqueInput;
    create: Prisma.XOR<Prisma.equipeCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput, Prisma.equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput>;
};
export type equipeUpsertWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput = {
    update: Prisma.XOR<Prisma.equipeUpdateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput, Prisma.equipeUncheckedUpdateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput>;
    create: Prisma.XOR<Prisma.equipeCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput, Prisma.equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput>;
    where?: Prisma.equipeWhereInput;
};
export type equipeUpdateToOneWithWhereWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput = {
    where?: Prisma.equipeWhereInput;
    data: Prisma.XOR<Prisma.equipeUpdateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput, Prisma.equipeUncheckedUpdateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput>;
};
export type equipeUpdateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUpdateManyWithoutEquipeNestedInput;
    tache?: Prisma.tacheUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUpdateManyWithoutEquipeNestedInput;
};
export type equipeUncheckedUpdateWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUncheckedUpdateManyWithoutEquipeNestedInput;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUncheckedUpdateManyWithoutEquipeNestedInput;
};
export type equipeUpsertWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput = {
    update: Prisma.XOR<Prisma.equipeUpdateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput, Prisma.equipeUncheckedUpdateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput>;
    create: Prisma.XOR<Prisma.equipeCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput, Prisma.equipeUncheckedCreateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput>;
    where?: Prisma.equipeWhereInput;
};
export type equipeUpdateToOneWithWhereWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput = {
    where?: Prisma.equipeWhereInput;
    data: Prisma.XOR<Prisma.equipeUpdateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput, Prisma.equipeUncheckedUpdateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput>;
};
export type equipeUpdateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUpdateManyWithoutEquipeNestedInput;
    tache?: Prisma.tacheUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUpdateManyWithoutEquipeNestedInput;
};
export type equipeUncheckedUpdateWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUncheckedUpdateManyWithoutEquipeNestedInput;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    utilisateur?: Prisma.utilisateurUncheckedUpdateManyWithoutEquipeNestedInput;
};
export type equipeCreateWithoutUtilisateurInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetCreateNestedManyWithoutEquipeInput;
    tache?: Prisma.tacheCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
};
export type equipeUncheckedCreateWithoutUtilisateurInput = {
    id_equipe?: bigint | number;
    nom_equipe: string;
    description?: string | null;
    statut?: string;
    date_creation?: Date | string;
    projet?: Prisma.projetUncheckedCreateNestedManyWithoutEquipeInput;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutEquipeInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput;
};
export type equipeCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.equipeWhereUniqueInput;
    create: Prisma.XOR<Prisma.equipeCreateWithoutUtilisateurInput, Prisma.equipeUncheckedCreateWithoutUtilisateurInput>;
};
export type equipeUpsertWithoutUtilisateurInput = {
    update: Prisma.XOR<Prisma.equipeUpdateWithoutUtilisateurInput, Prisma.equipeUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.equipeCreateWithoutUtilisateurInput, Prisma.equipeUncheckedCreateWithoutUtilisateurInput>;
    where?: Prisma.equipeWhereInput;
};
export type equipeUpdateToOneWithWhereWithoutUtilisateurInput = {
    where?: Prisma.equipeWhereInput;
    data: Prisma.XOR<Prisma.equipeUpdateWithoutUtilisateurInput, Prisma.equipeUncheckedUpdateWithoutUtilisateurInput>;
};
export type equipeUpdateWithoutUtilisateurInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUpdateManyWithoutEquipeNestedInput;
    tache?: Prisma.tacheUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
};
export type equipeUncheckedUpdateWithoutUtilisateurInput = {
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_equipe?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    projet?: Prisma.projetUncheckedUpdateManyWithoutEquipeNestedInput;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutEquipeNestedInput;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput;
};
export type EquipeCountOutputType = {
    projet: number;
    tache: number;
    transfert_tache_transfert_tache_ancienne_equipeToequipe: number;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe: number;
    utilisateur: number;
};
export type EquipeCountOutputTypeSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    projet?: boolean | EquipeCountOutputTypeCountProjetArgs;
    tache?: boolean | EquipeCountOutputTypeCountTacheArgs;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: boolean | EquipeCountOutputTypeCountTransfert_tache_transfert_tache_ancienne_equipeToequipeArgs;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: boolean | EquipeCountOutputTypeCountTransfert_tache_transfert_tache_nouvelle_equipeToequipeArgs;
    utilisateur?: boolean | EquipeCountOutputTypeCountUtilisateurArgs;
};
export type EquipeCountOutputTypeDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.EquipeCountOutputTypeSelect<ExtArgs> | null;
};
export type EquipeCountOutputTypeCountProjetArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.projetWhereInput;
};
export type EquipeCountOutputTypeCountTacheArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.tacheWhereInput;
};
export type EquipeCountOutputTypeCountTransfert_tache_transfert_tache_ancienne_equipeToequipeArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.transfert_tacheWhereInput;
};
export type EquipeCountOutputTypeCountTransfert_tache_transfert_tache_nouvelle_equipeToequipeArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.transfert_tacheWhereInput;
};
export type EquipeCountOutputTypeCountUtilisateurArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.utilisateurWhereInput;
};
export type equipeSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_equipe?: boolean;
    nom_equipe?: boolean;
    description?: boolean;
    statut?: boolean;
    date_creation?: boolean;
    projet?: boolean | Prisma.equipe$projetArgs<ExtArgs>;
    tache?: boolean | Prisma.equipe$tacheArgs<ExtArgs>;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: boolean | Prisma.equipe$transfert_tache_transfert_tache_ancienne_equipeToequipeArgs<ExtArgs>;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: boolean | Prisma.equipe$transfert_tache_transfert_tache_nouvelle_equipeToequipeArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.equipe$utilisateurArgs<ExtArgs>;
    _count?: boolean | Prisma.EquipeCountOutputTypeDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["equipe"]>;
export type equipeSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_equipe?: boolean;
    nom_equipe?: boolean;
    description?: boolean;
    statut?: boolean;
    date_creation?: boolean;
}, ExtArgs["result"]["equipe"]>;
export type equipeSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_equipe?: boolean;
    nom_equipe?: boolean;
    description?: boolean;
    statut?: boolean;
    date_creation?: boolean;
}, ExtArgs["result"]["equipe"]>;
export type equipeSelectScalar = {
    id_equipe?: boolean;
    nom_equipe?: boolean;
    description?: boolean;
    statut?: boolean;
    date_creation?: boolean;
};
export type equipeOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_equipe" | "nom_equipe" | "description" | "statut" | "date_creation", ExtArgs["result"]["equipe"]>;
export type equipeInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    projet?: boolean | Prisma.equipe$projetArgs<ExtArgs>;
    tache?: boolean | Prisma.equipe$tacheArgs<ExtArgs>;
    transfert_tache_transfert_tache_ancienne_equipeToequipe?: boolean | Prisma.equipe$transfert_tache_transfert_tache_ancienne_equipeToequipeArgs<ExtArgs>;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe?: boolean | Prisma.equipe$transfert_tache_transfert_tache_nouvelle_equipeToequipeArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.equipe$utilisateurArgs<ExtArgs>;
    _count?: boolean | Prisma.EquipeCountOutputTypeDefaultArgs<ExtArgs>;
};
export type equipeIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {};
export type equipeIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {};
export type $equipePayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "equipe";
    objects: {
        projet: Prisma.$projetPayload<ExtArgs>[];
        tache: Prisma.$tachePayload<ExtArgs>[];
        transfert_tache_transfert_tache_ancienne_equipeToequipe: Prisma.$transfert_tachePayload<ExtArgs>[];
        transfert_tache_transfert_tache_nouvelle_equipeToequipe: Prisma.$transfert_tachePayload<ExtArgs>[];
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>[];
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_equipe: bigint;
        nom_equipe: string;
        description: string | null;
        statut: string;
        date_creation: Date;
    }, ExtArgs["result"]["equipe"]>;
    composites: {};
};
export type equipeGetPayload<S extends boolean | null | undefined | equipeDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$equipePayload, S>;
export type equipeCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<equipeFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: EquipeCountAggregateInputType | true;
};
export interface equipeDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['equipe'];
        meta: {
            name: 'equipe';
        };
    };
    findUnique<T extends equipeFindUniqueArgs>(args: Prisma.SelectSubset<T, equipeFindUniqueArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends equipeFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, equipeFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends equipeFindFirstArgs>(args?: Prisma.SelectSubset<T, equipeFindFirstArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends equipeFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, equipeFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends equipeFindManyArgs>(args?: Prisma.SelectSubset<T, equipeFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends equipeCreateArgs>(args: Prisma.SelectSubset<T, equipeCreateArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends equipeCreateManyArgs>(args?: Prisma.SelectSubset<T, equipeCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends equipeCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, equipeCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends equipeDeleteArgs>(args: Prisma.SelectSubset<T, equipeDeleteArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends equipeUpdateArgs>(args: Prisma.SelectSubset<T, equipeUpdateArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends equipeDeleteManyArgs>(args?: Prisma.SelectSubset<T, equipeDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends equipeUpdateManyArgs>(args: Prisma.SelectSubset<T, equipeUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends equipeUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, equipeUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends equipeUpsertArgs>(args: Prisma.SelectSubset<T, equipeUpsertArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends equipeCountArgs>(args?: Prisma.Subset<T, equipeCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], EquipeCountAggregateOutputType> : number>;
    aggregate<T extends EquipeAggregateArgs>(args: Prisma.Subset<T, EquipeAggregateArgs>): Prisma.PrismaPromise<GetEquipeAggregateType<T>>;
    groupBy<T extends equipeGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: equipeGroupByArgs['orderBy'];
    } : {
        orderBy?: equipeGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, equipeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEquipeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: equipeFieldRefs;
}
export interface Prisma__equipeClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    projet<T extends Prisma.equipe$projetArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.equipe$projetArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    tache<T extends Prisma.equipe$tacheArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.equipe$tacheArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$tachePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    transfert_tache_transfert_tache_ancienne_equipeToequipe<T extends Prisma.equipe$transfert_tache_transfert_tache_ancienne_equipeToequipeArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.equipe$transfert_tache_transfert_tache_ancienne_equipeToequipeArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    transfert_tache_transfert_tache_nouvelle_equipeToequipe<T extends Prisma.equipe$transfert_tache_transfert_tache_nouvelle_equipeToequipeArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.equipe$transfert_tache_transfert_tache_nouvelle_equipeToequipeArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    utilisateur<T extends Prisma.equipe$utilisateurArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.equipe$utilisateurArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface equipeFieldRefs {
    readonly id_equipe: Prisma.FieldRef<"equipe", 'BigInt'>;
    readonly nom_equipe: Prisma.FieldRef<"equipe", 'String'>;
    readonly description: Prisma.FieldRef<"equipe", 'String'>;
    readonly statut: Prisma.FieldRef<"equipe", 'String'>;
    readonly date_creation: Prisma.FieldRef<"equipe", 'DateTime'>;
}
export type equipeFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    where: Prisma.equipeWhereUniqueInput;
};
export type equipeFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    where: Prisma.equipeWhereUniqueInput;
};
export type equipeFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    where?: Prisma.equipeWhereInput;
    orderBy?: Prisma.equipeOrderByWithRelationInput | Prisma.equipeOrderByWithRelationInput[];
    cursor?: Prisma.equipeWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.EquipeScalarFieldEnum | Prisma.EquipeScalarFieldEnum[];
};
export type equipeFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    where?: Prisma.equipeWhereInput;
    orderBy?: Prisma.equipeOrderByWithRelationInput | Prisma.equipeOrderByWithRelationInput[];
    cursor?: Prisma.equipeWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.EquipeScalarFieldEnum | Prisma.EquipeScalarFieldEnum[];
};
export type equipeFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    where?: Prisma.equipeWhereInput;
    orderBy?: Prisma.equipeOrderByWithRelationInput | Prisma.equipeOrderByWithRelationInput[];
    cursor?: Prisma.equipeWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.EquipeScalarFieldEnum | Prisma.EquipeScalarFieldEnum[];
};
export type equipeCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.equipeCreateInput, Prisma.equipeUncheckedCreateInput>;
};
export type equipeCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.equipeCreateManyInput | Prisma.equipeCreateManyInput[];
    skipDuplicates?: boolean;
};
export type equipeCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    data: Prisma.equipeCreateManyInput | Prisma.equipeCreateManyInput[];
    skipDuplicates?: boolean;
};
export type equipeUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.equipeUpdateInput, Prisma.equipeUncheckedUpdateInput>;
    where: Prisma.equipeWhereUniqueInput;
};
export type equipeUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.equipeUpdateManyMutationInput, Prisma.equipeUncheckedUpdateManyInput>;
    where?: Prisma.equipeWhereInput;
    limit?: number;
};
export type equipeUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.equipeUpdateManyMutationInput, Prisma.equipeUncheckedUpdateManyInput>;
    where?: Prisma.equipeWhereInput;
    limit?: number;
};
export type equipeUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    where: Prisma.equipeWhereUniqueInput;
    create: Prisma.XOR<Prisma.equipeCreateInput, Prisma.equipeUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.equipeUpdateInput, Prisma.equipeUncheckedUpdateInput>;
};
export type equipeDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
    where: Prisma.equipeWhereUniqueInput;
};
export type equipeDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.equipeWhereInput;
    limit?: number;
};
export type equipe$projetArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    where?: Prisma.projetWhereInput;
    orderBy?: Prisma.projetOrderByWithRelationInput | Prisma.projetOrderByWithRelationInput[];
    cursor?: Prisma.projetWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ProjetScalarFieldEnum | Prisma.ProjetScalarFieldEnum[];
};
export type equipe$tacheArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.tacheSelect<ExtArgs> | null;
    omit?: Prisma.tacheOmit<ExtArgs> | null;
    include?: Prisma.tacheInclude<ExtArgs> | null;
    where?: Prisma.tacheWhereInput;
    orderBy?: Prisma.tacheOrderByWithRelationInput | Prisma.tacheOrderByWithRelationInput[];
    cursor?: Prisma.tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.TacheScalarFieldEnum | Prisma.TacheScalarFieldEnum[];
};
export type equipe$transfert_tache_transfert_tache_ancienne_equipeToequipeArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where?: Prisma.transfert_tacheWhereInput;
    orderBy?: Prisma.transfert_tacheOrderByWithRelationInput | Prisma.transfert_tacheOrderByWithRelationInput[];
    cursor?: Prisma.transfert_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Transfert_tacheScalarFieldEnum | Prisma.Transfert_tacheScalarFieldEnum[];
};
export type equipe$transfert_tache_transfert_tache_nouvelle_equipeToequipeArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where?: Prisma.transfert_tacheWhereInput;
    orderBy?: Prisma.transfert_tacheOrderByWithRelationInput | Prisma.transfert_tacheOrderByWithRelationInput[];
    cursor?: Prisma.transfert_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Transfert_tacheScalarFieldEnum | Prisma.Transfert_tacheScalarFieldEnum[];
};
export type equipe$utilisateurArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.utilisateurSelect<ExtArgs> | null;
    omit?: Prisma.utilisateurOmit<ExtArgs> | null;
    include?: Prisma.utilisateurInclude<ExtArgs> | null;
    where?: Prisma.utilisateurWhereInput;
    orderBy?: Prisma.utilisateurOrderByWithRelationInput | Prisma.utilisateurOrderByWithRelationInput[];
    cursor?: Prisma.utilisateurWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.UtilisateurScalarFieldEnum | Prisma.UtilisateurScalarFieldEnum[];
};
export type equipeDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.equipeSelect<ExtArgs> | null;
    omit?: Prisma.equipeOmit<ExtArgs> | null;
    include?: Prisma.equipeInclude<ExtArgs> | null;
};
