import * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "./prismaNamespace.js";
export type LogOptions<ClientOptions extends Prisma.PrismaClientOptions> = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never;
export interface PrismaClientConstructor {
    new <Options extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions, LogOpts extends LogOptions<Options> = LogOptions<Options>, OmitOpts extends Prisma.PrismaClientOptions['omit'] = Options extends {
        omit: infer U;
    } ? U : Prisma.PrismaClientOptions['omit'], ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs>(options: Prisma.PrismaClientConstructorArgs<Options>): PrismaClient<LogOpts, OmitOpts, ExtArgs>;
}
export interface PrismaClient<in LogOpts extends Prisma.LogLevel = never, in out OmitOpts extends Prisma.PrismaClientOptions['omit'] = Prisma.PrismaClientOptions['omit'], in out ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['other'];
    };
    $on<V extends LogOpts>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;
    $connect(): runtime.Types.Utils.JsPromise<void>;
    $disconnect(): runtime.Types.Utils.JsPromise<void>;
    $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;
    $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;
    $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;
    $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;
    $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: {
        maxWait?: number;
        timeout?: number;
        isolationLevel?: Prisma.TransactionIsolationLevel;
    }): runtime.Types.Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>;
    $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => runtime.Types.Utils.JsPromise<R>, options?: {
        maxWait?: number;
        timeout?: number;
        isolationLevel?: Prisma.TransactionIsolationLevel;
    }): runtime.Types.Utils.JsPromise<R>;
    $extends: runtime.Types.Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<OmitOpts>, ExtArgs, runtime.Types.Utils.Call<Prisma.TypeMapCb<OmitOpts>, {
        extArgs: ExtArgs;
    }>>;
    get activite(): Prisma.activiteDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get commentaire(): Prisma.commentaireDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get entreprise(): Prisma.entrepriseDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get equipe(): Prisma.equipeDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get historique_tache(): Prisma.historique_tacheDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get notification(): Prisma.notificationDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get participation_projet(): Prisma.participation_projetDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get permission(): Prisma.permissionDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get piece_jointe(): Prisma.piece_jointeDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get projet(): Prisma.projetDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get rapport(): Prisma.rapportDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get role(): Prisma.roleDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get role_permission(): Prisma.role_permissionDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get session(): Prisma.sessionDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get tache(): Prisma.tacheDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get transfert_tache(): Prisma.transfert_tacheDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
    get utilisateur(): Prisma.utilisateurDelegate<ExtArgs, {
        omit: OmitOpts;
    }>;
}
export declare function getPrismaClientClass(): PrismaClientConstructor;
