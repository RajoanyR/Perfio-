export {};
//# sourceMappingURL=piece_jointe.js.map