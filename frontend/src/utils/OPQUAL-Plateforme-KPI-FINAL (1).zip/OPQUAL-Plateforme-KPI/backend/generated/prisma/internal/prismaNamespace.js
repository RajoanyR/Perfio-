import * as runtime from "@prisma/client/runtime/client";
export const PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError;
export const PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError;
export const PrismaClientRustPanicError = runtime.PrismaClientRustPanicError;
export const PrismaClientInitializationError = runtime.PrismaClientInitializationError;
export const PrismaClientValidationError = runtime.PrismaClientValidationError;
export const sql = runtime.sqltag;
export const empty = runtime.empty;
export const join = runtime.join;
export const raw = runtime.raw;
export const Sql = runtime.Sql;
export const Decimal = runtime.Decimal;
export const getExtensionContext = runtime.Extensions.getExtensionContext;
export const prismaVersion = {
    client: "7.10.0",
    engine: "0edf323efd1d98336f3f0a68684b56f689b900d3"
};
export const NullTypes = {
    DbNull: runtime.NullTypes.DbNull,
    JsonNull: runtime.NullTypes.JsonNull,
    AnyNull: runtime.NullTypes.AnyNull,
};
export const DbNull = runtime.DbNull;
export const JsonNull = runtime.JsonNull;
export const AnyNull = runtime.AnyNull;
export const ModelName = {
    activite: 'activite',
    commentaire: 'commentaire',
    entreprise: 'entreprise',
    equipe: 'equipe',
    historique_tache: 'historique_tache',
    notification: 'notification',
    participation_projet: 'participation_projet',
    permission: 'permission',
    piece_jointe: 'piece_jointe',
    projet: 'projet',
    rapport: 'rapport',
    role: 'role',
    role_permission: 'role_permission',
    session: 'session',
    tache: 'tache',
    transfert_tache: 'transfert_tache',
    utilisateur: 'utilisateur'
};
export const TransactionIsolationLevel = runtime.makeStrictEnum({
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
});
export const ActiviteScalarFieldEnum = {
    id_activite: 'id_activite',
    id_tache: 'id_tache',
    id_utilisateur: 'id_utilisateur',
    description: 'description',
    temps_passe: 'temps_passe',
    date_activite: 'date_activite'
};
export const CommentaireScalarFieldEnum = {
    id_commentaire: 'id_commentaire',
    id_tache: 'id_tache',
    id_utilisateur: 'id_utilisateur',
    contenu: 'contenu',
    date_creation: 'date_creation',
    date_modification: 'date_modification',
    statut: 'statut'
};
export const EntrepriseScalarFieldEnum = {
    id_entreprise: 'id_entreprise',
    nom: 'nom',
    logo: 'logo',
    adresse: 'adresse',
    email: 'email',
    telephone: 'telephone',
    informations_generales: 'informations_generales',
    date_creation: 'date_creation'
};
export const EquipeScalarFieldEnum = {
    id_equipe: 'id_equipe',
    nom_equipe: 'nom_equipe',
    description: 'description',
    statut: 'statut',
    date_creation: 'date_creation'
};
export const Historique_tacheScalarFieldEnum = {
    id_historique: 'id_historique',
    id_tache: 'id_tache',
    id_utilisateur: 'id_utilisateur',
    action: 'action',
    description: 'description',
    date_action: 'date_action'
};
export const NotificationScalarFieldEnum = {
    id_notification: 'id_notification',
    id_utilisateur: 'id_utilisateur',
    type: 'type',
    message: 'message',
    est_lue: 'est_lue',
    date_creation: 'date_creation',
    date_lecture: 'date_lecture'
};
export const Participation_projetScalarFieldEnum = {
    id_projet: 'id_projet',
    id_utilisateur: 'id_utilisateur',
    date_participation: 'date_participation',
    statut: 'statut'
};
export const PermissionScalarFieldEnum = {
    id_permission: 'id_permission',
    code_permission: 'code_permission',
    nom_permission: 'nom_permission',
    description: 'description'
};
export const Piece_jointeScalarFieldEnum = {
    id_piece_jointe: 'id_piece_jointe',
    id_tache: 'id_tache',
    id_commentaire: 'id_commentaire',
    id_utilisateur: 'id_utilisateur',
    nom_fichier: 'nom_fichier',
    chemin_fichier: 'chemin_fichier',
    type_fichier: 'type_fichier',
    taille: 'taille',
    date_ajout: 'date_ajout'
};
export const ProjetScalarFieldEnum = {
    id_projet: 'id_projet',
    id_equipe: 'id_equipe',
    id_chef_projet: 'id_chef_projet',
    nom_projet: 'nom_projet',
    code_projet: 'code_projet',
    description: 'description',
    priorite: 'priorite',
    etat: 'etat',
    date_debut: 'date_debut',
    date_fin_prevue: 'date_fin_prevue',
    date_fin_reelle: 'date_fin_reelle',
    statut: 'statut',
    date_creation: 'date_creation'
};
export const RapportScalarFieldEnum = {
    id_rapport: 'id_rapport',
    id_utilisateur: 'id_utilisateur',
    type: 'type',
    format: 'format',
    periode_debut: 'periode_debut',
    periode_fin: 'periode_fin',
    chemin_fichier: 'chemin_fichier',
    date_generation: 'date_generation'
};
export const RoleScalarFieldEnum = {
    id_role: 'id_role',
    nom_role: 'nom_role',
    description: 'description'
};
export const Role_permissionScalarFieldEnum = {
    id_role: 'id_role',
    id_permission: 'id_permission'
};
export const SessionScalarFieldEnum = {
    id_session: 'id_session',
    id_utilisateur: 'id_utilisateur',
    token_hash: 'token_hash',
    date_connexion: 'date_connexion',
    derniere_activite: 'derniere_activite',
    date_deconnexion: 'date_deconnexion',
    statut: 'statut'
};
export const TacheScalarFieldEnum = {
    id_tache: 'id_tache',
    id_projet: 'id_projet',
    id_responsable: 'id_responsable',
    id_equipe: 'id_equipe',
    titre: 'titre',
    description: 'description',
    priorite: 'priorite',
    etat: 'etat',
    temps_estime: 'temps_estime',
    date_creation: 'date_creation',
    date_debut: 'date_debut',
    date_limite: 'date_limite',
    date_terminaison: 'date_terminaison'
};
export const Transfert_tacheScalarFieldEnum = {
    id_transfert: 'id_transfert',
    id_tache: 'id_tache',
    ancien_responsable: 'ancien_responsable',
    nouveau_responsable: 'nouveau_responsable',
    ancienne_equipe: 'ancienne_equipe',
    nouvelle_equipe: 'nouvelle_equipe',
    utilisateur_transfert: 'utilisateur_transfert',
    motif: 'motif',
    date_transfert: 'date_transfert'
};
export const UtilisateurScalarFieldEnum = {
    id_utilisateur: 'id_utilisateur',
    id_entreprise: 'id_entreprise',
    id_role: 'id_role',
    id_equipe: 'id_equipe',
    nom: 'nom',
    prenom: 'prenom',
    email: 'email',
    mot_de_passe: 'mot_de_passe',
    telephone: 'telephone',
    poste: 'poste',
    theme: 'theme',
    statut: 'statut',
    capacite_hebdomadaire_heures: 'capacite_hebdomadaire_heures',
    tentatives_echec: 'tentatives_echec',
    verrouille_jusqu_a: 'verrouille_jusqu_a',
    date_creation: 'date_creation',
    date_modification: 'date_modification'
};
export const SortOrder = {
    asc: 'asc',
    desc: 'desc'
};
export const QueryMode = {
    default: 'default',
    insensitive: 'insensitive'
};
export const NullsOrder = {
    first: 'first',
    last: 'last'
};
export const defineExtension = runtime.Extensions.defineExtension;
//# sourceMappingURL=prismaNamespace.js.map