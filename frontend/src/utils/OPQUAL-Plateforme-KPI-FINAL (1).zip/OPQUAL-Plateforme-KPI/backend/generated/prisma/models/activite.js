export {};
//# sourceMappingURL=activite.js.map