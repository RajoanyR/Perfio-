import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type participation_projetModel = runtime.Types.Result.DefaultSelection<Prisma.$participation_projetPayload>;
export type AggregateParticipation_projet = {
    _count: Participation_projetCountAggregateOutputType | null;
    _avg: Participation_projetAvgAggregateOutputType | null;
    _sum: Participation_projetSumAggregateOutputType | null;
    _min: Participation_projetMinAggregateOutputType | null;
    _max: Participation_projetMaxAggregateOutputType | null;
};
export type Participation_projetAvgAggregateOutputType = {
    id_projet: number | null;
    id_utilisateur: number | null;
};
export type Participation_projetSumAggregateOutputType = {
    id_projet: bigint | null;
    id_utilisateur: bigint | null;
};
export type Participation_projetMinAggregateOutputType = {
    id_projet: bigint | null;
    id_utilisateur: bigint | null;
    date_participation: Date | null;
    statut: string | null;
};
export type Participation_projetMaxAggregateOutputType = {
    id_projet: bigint | null;
    id_utilisateur: bigint | null;
    date_participation: Date | null;
    statut: string | null;
};
export type Participation_projetCountAggregateOutputType = {
    id_projet: number;
    id_utilisateur: number;
    date_participation: number;
    statut: number;
    _all: number;
};
export type Participation_projetAvgAggregateInputType = {
    id_projet?: true;
    id_utilisateur?: true;
};
export type Participation_projetSumAggregateInputType = {
    id_projet?: true;
    id_utilisateur?: true;
};
export type Participation_projetMinAggregateInputType = {
    id_projet?: true;
    id_utilisateur?: true;
    date_participation?: true;
    statut?: true;
};
export type Participation_projetMaxAggregateInputType = {
    id_projet?: true;
    id_utilisateur?: true;
    date_participation?: true;
    statut?: true;
};
export type Participation_projetCountAggregateInputType = {
    id_projet?: true;
    id_utilisateur?: true;
    date_participation?: true;
    statut?: true;
    _all?: true;
};
export type Participation_projetAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.participation_projetWhereInput;
    orderBy?: Prisma.participation_projetOrderByWithRelationInput | Prisma.participation_projetOrderByWithRelationInput[];
    cursor?: Prisma.participation_projetWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | Participation_projetCountAggregateInputType;
    _avg?: Participation_projetAvgAggregateInputType;
    _sum?: Participation_projetSumAggregateInputType;
    _min?: Participation_projetMinAggregateInputType;
    _max?: Participation_projetMaxAggregateInputType;
};
export type GetParticipation_projetAggregateType<T extends Participation_projetAggregateArgs> = {
    [P in keyof T & keyof AggregateParticipation_projet]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateParticipation_projet[P]> : Prisma.GetScalarType<T[P], AggregateParticipation_projet[P]>;
};
export type participation_projetGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.participation_projetWhereInput;
    orderBy?: Prisma.participation_projetOrderByWithAggregationInput | Prisma.participation_projetOrderByWithAggregationInput[];
    by: Prisma.Participation_projetScalarFieldEnum[] | Prisma.Participation_projetScalarFieldEnum;
    having?: Prisma.participation_projetScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: Participation_projetCountAggregateInputType | true;
    _avg?: Participation_projetAvgAggregateInputType;
    _sum?: Participation_projetSumAggregateInputType;
    _min?: Participation_projetMinAggregateInputType;
    _max?: Participation_projetMaxAggregateInputType;
};
export type Participation_projetGroupByOutputType = {
    id_projet: bigint;
    id_utilisateur: bigint;
    date_participation: Date;
    statut: string;
    _count: Participation_projetCountAggregateOutputType | null;
    _avg: Participation_projetAvgAggregateOutputType | null;
    _sum: Participation_projetSumAggregateOutputType | null;
    _min: Participation_projetMinAggregateOutputType | null;
    _max: Participation_projetMaxAggregateOutputType | null;
};
export type GetParticipation_projetGroupByPayload<T extends participation_projetGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<Participation_projetGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof Participation_projetGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], Participation_projetGroupByOutputType[P]> : Prisma.GetScalarType<T[P], Participation_projetGroupByOutputType[P]>;
}>>;
export type participation_projetWhereInput = {
    AND?: Prisma.participation_projetWhereInput | Prisma.participation_projetWhereInput[];
    OR?: Prisma.participation_projetWhereInput[];
    NOT?: Prisma.participation_projetWhereInput | Prisma.participation_projetWhereInput[];
    id_projet?: Prisma.BigIntFilter<"participation_projet"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"participation_projet"> | bigint | number;
    date_participation?: Prisma.DateTimeFilter<"participation_projet"> | Date | string;
    statut?: Prisma.StringFilter<"participation_projet"> | string;
    projet?: Prisma.XOR<Prisma.ProjetScalarRelationFilter, Prisma.projetWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
};
export type participation_projetOrderByWithRelationInput = {
    id_projet?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    date_participation?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    projet?: Prisma.projetOrderByWithRelationInput;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
};
export type participation_projetWhereUniqueInput = Prisma.AtLeast<{
    id_projet_id_utilisateur?: Prisma.participation_projetId_projetId_utilisateurCompoundUniqueInput;
    AND?: Prisma.participation_projetWhereInput | Prisma.participation_projetWhereInput[];
    OR?: Prisma.participation_projetWhereInput[];
    NOT?: Prisma.participation_projetWhereInput | Prisma.participation_projetWhereInput[];
    id_projet?: Prisma.BigIntFilter<"participation_projet"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"participation_projet"> | bigint | number;
    date_participation?: Prisma.DateTimeFilter<"participation_projet"> | Date | string;
    statut?: Prisma.StringFilter<"participation_projet"> | string;
    projet?: Prisma.XOR<Prisma.ProjetScalarRelationFilter, Prisma.projetWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
}, "id_projet_id_utilisateur">;
export type participation_projetOrderByWithAggregationInput = {
    id_projet?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    date_participation?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    _count?: Prisma.participation_projetCountOrderByAggregateInput;
    _avg?: Prisma.participation_projetAvgOrderByAggregateInput;
    _max?: Prisma.participation_projetMaxOrderByAggregateInput;
    _min?: Prisma.participation_projetMinOrderByAggregateInput;
    _sum?: Prisma.participation_projetSumOrderByAggregateInput;
};
export type participation_projetScalarWhereWithAggregatesInput = {
    AND?: Prisma.participation_projetScalarWhereWithAggregatesInput | Prisma.participation_projetScalarWhereWithAggregatesInput[];
    OR?: Prisma.participation_projetScalarWhereWithAggregatesInput[];
    NOT?: Prisma.participation_projetScalarWhereWithAggregatesInput | Prisma.participation_projetScalarWhereWithAggregatesInput[];
    id_projet?: Prisma.BigIntWithAggregatesFilter<"participation_projet"> | bigint | number;
    id_utilisateur?: Prisma.BigIntWithAggregatesFilter<"participation_projet"> | bigint | number;
    date_participation?: Prisma.DateTimeWithAggregatesFilter<"participation_projet"> | Date | string;
    statut?: Prisma.StringWithAggregatesFilter<"participation_projet"> | string;
};
export type participation_projetCreateInput = {
    date_participation?: Date | string;
    statut?: string;
    projet: Prisma.projetCreateNestedOneWithoutParticipation_projetInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutParticipation_projetInput;
};
export type participation_projetUncheckedCreateInput = {
    id_projet: bigint | number;
    id_utilisateur: bigint | number;
    date_participation?: Date | string;
    statut?: string;
};
export type participation_projetUpdateInput = {
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    projet?: Prisma.projetUpdateOneRequiredWithoutParticipation_projetNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutParticipation_projetNestedInput;
};
export type participation_projetUncheckedUpdateInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type participation_projetCreateManyInput = {
    id_projet: bigint | number;
    id_utilisateur: bigint | number;
    date_participation?: Date | string;
    statut?: string;
};
export type participation_projetUpdateManyMutationInput = {
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type participation_projetUncheckedUpdateManyInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type participation_projetId_projetId_utilisateurCompoundUniqueInput = {
    id_projet: bigint | number;
    id_utilisateur: bigint | number;
};
export type participation_projetCountOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    date_participation?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type participation_projetAvgOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type participation_projetMaxOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    date_participation?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type participation_projetMinOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    date_participation?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type participation_projetSumOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type Participation_projetListRelationFilter = {
    every?: Prisma.participation_projetWhereInput;
    some?: Prisma.participation_projetWhereInput;
    none?: Prisma.participation_projetWhereInput;
};
export type participation_projetOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type participation_projetCreateNestedManyWithoutProjetInput = {
    create?: Prisma.XOR<Prisma.participation_projetCreateWithoutProjetInput, Prisma.participation_projetUncheckedCreateWithoutProjetInput> | Prisma.participation_projetCreateWithoutProjetInput[] | Prisma.participation_projetUncheckedCreateWithoutProjetInput[];
    connectOrCreate?: Prisma.participation_projetCreateOrConnectWithoutProjetInput | Prisma.participation_projetCreateOrConnectWithoutProjetInput[];
    createMany?: Prisma.participation_projetCreateManyProjetInputEnvelope;
    connect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
};
export type participation_projetUncheckedCreateNestedManyWithoutProjetInput = {
    create?: Prisma.XOR<Prisma.participation_projetCreateWithoutProjetInput, Prisma.participation_projetUncheckedCreateWithoutProjetInput> | Prisma.participation_projetCreateWithoutProjetInput[] | Prisma.participation_projetUncheckedCreateWithoutProjetInput[];
    connectOrCreate?: Prisma.participation_projetCreateOrConnectWithoutProjetInput | Prisma.participation_projetCreateOrConnectWithoutProjetInput[];
    createMany?: Prisma.participation_projetCreateManyProjetInputEnvelope;
    connect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
};
export type participation_projetUpdateManyWithoutProjetNestedInput = {
    create?: Prisma.XOR<Prisma.participation_projetCreateWithoutProjetInput, Prisma.participation_projetUncheckedCreateWithoutProjetInput> | Prisma.participation_projetCreateWithoutProjetInput[] | Prisma.participation_projetUncheckedCreateWithoutProjetInput[];
    connectOrCreate?: Prisma.participation_projetCreateOrConnectWithoutProjetInput | Prisma.participation_projetCreateOrConnectWithoutProjetInput[];
    upsert?: Prisma.participation_projetUpsertWithWhereUniqueWithoutProjetInput | Prisma.participation_projetUpsertWithWhereUniqueWithoutProjetInput[];
    createMany?: Prisma.participation_projetCreateManyProjetInputEnvelope;
    set?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    disconnect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    delete?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    connect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    update?: Prisma.participation_projetUpdateWithWhereUniqueWithoutProjetInput | Prisma.participation_projetUpdateWithWhereUniqueWithoutProjetInput[];
    updateMany?: Prisma.participation_projetUpdateManyWithWhereWithoutProjetInput | Prisma.participation_projetUpdateManyWithWhereWithoutProjetInput[];
    deleteMany?: Prisma.participation_projetScalarWhereInput | Prisma.participation_projetScalarWhereInput[];
};
export type participation_projetUncheckedUpdateManyWithoutProjetNestedInput = {
    create?: Prisma.XOR<Prisma.participation_projetCreateWithoutProjetInput, Prisma.participation_projetUncheckedCreateWithoutProjetInput> | Prisma.participation_projetCreateWithoutProjetInput[] | Prisma.participation_projetUncheckedCreateWithoutProjetInput[];
    connectOrCreate?: Prisma.participation_projetCreateOrConnectWithoutProjetInput | Prisma.participation_projetCreateOrConnectWithoutProjetInput[];
    upsert?: Prisma.participation_projetUpsertWithWhereUniqueWithoutProjetInput | Prisma.participation_projetUpsertWithWhereUniqueWithoutProjetInput[];
    createMany?: Prisma.participation_projetCreateManyProjetInputEnvelope;
    set?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    disconnect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    delete?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    connect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    update?: Prisma.participation_projetUpdateWithWhereUniqueWithoutProjetInput | Prisma.participation_projetUpdateWithWhereUniqueWithoutProjetInput[];
    updateMany?: Prisma.participation_projetUpdateManyWithWhereWithoutProjetInput | Prisma.participation_projetUpdateManyWithWhereWithoutProjetInput[];
    deleteMany?: Prisma.participation_projetScalarWhereInput | Prisma.participation_projetScalarWhereInput[];
};
export type participation_projetCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.participation_projetCreateWithoutUtilisateurInput, Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput> | Prisma.participation_projetCreateWithoutUtilisateurInput[] | Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.participation_projetCreateOrConnectWithoutUtilisateurInput | Prisma.participation_projetCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.participation_projetCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
};
export type participation_projetUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.participation_projetCreateWithoutUtilisateurInput, Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput> | Prisma.participation_projetCreateWithoutUtilisateurInput[] | Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.participation_projetCreateOrConnectWithoutUtilisateurInput | Prisma.participation_projetCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.participation_projetCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
};
export type participation_projetUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.participation_projetCreateWithoutUtilisateurInput, Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput> | Prisma.participation_projetCreateWithoutUtilisateurInput[] | Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.participation_projetCreateOrConnectWithoutUtilisateurInput | Prisma.participation_projetCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.participation_projetUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.participation_projetUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.participation_projetCreateManyUtilisateurInputEnvelope;
    set?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    disconnect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    delete?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    connect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    update?: Prisma.participation_projetUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.participation_projetUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.participation_projetUpdateManyWithWhereWithoutUtilisateurInput | Prisma.participation_projetUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.participation_projetScalarWhereInput | Prisma.participation_projetScalarWhereInput[];
};
export type participation_projetUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.participation_projetCreateWithoutUtilisateurInput, Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput> | Prisma.participation_projetCreateWithoutUtilisateurInput[] | Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.participation_projetCreateOrConnectWithoutUtilisateurInput | Prisma.participation_projetCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.participation_projetUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.participation_projetUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.participation_projetCreateManyUtilisateurInputEnvelope;
    set?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    disconnect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    delete?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    connect?: Prisma.participation_projetWhereUniqueInput | Prisma.participation_projetWhereUniqueInput[];
    update?: Prisma.participation_projetUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.participation_projetUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.participation_projetUpdateManyWithWhereWithoutUtilisateurInput | Prisma.participation_projetUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.participation_projetScalarWhereInput | Prisma.participation_projetScalarWhereInput[];
};
export type participation_projetCreateWithoutProjetInput = {
    date_participation?: Date | string;
    statut?: string;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutParticipation_projetInput;
};
export type participation_projetUncheckedCreateWithoutProjetInput = {
    id_utilisateur: bigint | number;
    date_participation?: Date | string;
    statut?: string;
};
export type participation_projetCreateOrConnectWithoutProjetInput = {
    where: Prisma.participation_projetWhereUniqueInput;
    create: Prisma.XOR<Prisma.participation_projetCreateWithoutProjetInput, Prisma.participation_projetUncheckedCreateWithoutProjetInput>;
};
export type participation_projetCreateManyProjetInputEnvelope = {
    data: Prisma.participation_projetCreateManyProjetInput | Prisma.participation_projetCreateManyProjetInput[];
    skipDuplicates?: boolean;
};
export type participation_projetUpsertWithWhereUniqueWithoutProjetInput = {
    where: Prisma.participation_projetWhereUniqueInput;
    update: Prisma.XOR<Prisma.participation_projetUpdateWithoutProjetInput, Prisma.participation_projetUncheckedUpdateWithoutProjetInput>;
    create: Prisma.XOR<Prisma.participation_projetCreateWithoutProjetInput, Prisma.participation_projetUncheckedCreateWithoutProjetInput>;
};
export type participation_projetUpdateWithWhereUniqueWithoutProjetInput = {
    where: Prisma.participation_projetWhereUniqueInput;
    data: Prisma.XOR<Prisma.participation_projetUpdateWithoutProjetInput, Prisma.participation_projetUncheckedUpdateWithoutProjetInput>;
};
export type participation_projetUpdateManyWithWhereWithoutProjetInput = {
    where: Prisma.participation_projetScalarWhereInput;
    data: Prisma.XOR<Prisma.participation_projetUpdateManyMutationInput, Prisma.participation_projetUncheckedUpdateManyWithoutProjetInput>;
};
export type participation_projetScalarWhereInput = {
    AND?: Prisma.participation_projetScalarWhereInput | Prisma.participation_projetScalarWhereInput[];
    OR?: Prisma.participation_projetScalarWhereInput[];
    NOT?: Prisma.participation_projetScalarWhereInput | Prisma.participation_projetScalarWhereInput[];
    id_projet?: Prisma.BigIntFilter<"participation_projet"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"participation_projet"> | bigint | number;
    date_participation?: Prisma.DateTimeFilter<"participation_projet"> | Date | string;
    statut?: Prisma.StringFilter<"participation_projet"> | string;
};
export type participation_projetCreateWithoutUtilisateurInput = {
    date_participation?: Date | string;
    statut?: string;
    projet: Prisma.projetCreateNestedOneWithoutParticipation_projetInput;
};
export type participation_projetUncheckedCreateWithoutUtilisateurInput = {
    id_projet: bigint | number;
    date_participation?: Date | string;
    statut?: string;
};
export type participation_projetCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.participation_projetWhereUniqueInput;
    create: Prisma.XOR<Prisma.participation_projetCreateWithoutUtilisateurInput, Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput>;
};
export type participation_projetCreateManyUtilisateurInputEnvelope = {
    data: Prisma.participation_projetCreateManyUtilisateurInput | Prisma.participation_projetCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type participation_projetUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.participation_projetWhereUniqueInput;
    update: Prisma.XOR<Prisma.participation_projetUpdateWithoutUtilisateurInput, Prisma.participation_projetUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.participation_projetCreateWithoutUtilisateurInput, Prisma.participation_projetUncheckedCreateWithoutUtilisateurInput>;
};
export type participation_projetUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.participation_projetWhereUniqueInput;
    data: Prisma.XOR<Prisma.participation_projetUpdateWithoutUtilisateurInput, Prisma.participation_projetUncheckedUpdateWithoutUtilisateurInput>;
};
export type participation_projetUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.participation_projetScalarWhereInput;
    data: Prisma.XOR<Prisma.participation_projetUpdateManyMutationInput, Prisma.participation_projetUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type participation_projetCreateManyProjetInput = {
    id_utilisateur: bigint | number;
    date_participation?: Date | string;
    statut?: string;
};
export type participation_projetUpdateWithoutProjetInput = {
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutParticipation_projetNestedInput;
};
export type participation_projetUncheckedUpdateWithoutProjetInput = {
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type participation_projetUncheckedUpdateManyWithoutProjetInput = {
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type participation_projetCreateManyUtilisateurInput = {
    id_projet: bigint | number;
    date_participation?: Date | string;
    statut?: string;
};
export type participation_projetUpdateWithoutUtilisateurInput = {
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    projet?: Prisma.projetUpdateOneRequiredWithoutParticipation_projetNestedInput;
};
export type participation_projetUncheckedUpdateWithoutUtilisateurInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type participation_projetUncheckedUpdateManyWithoutUtilisateurInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    date_participation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type participation_projetSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_projet?: boolean;
    id_utilisateur?: boolean;
    date_participation?: boolean;
    statut?: boolean;
    projet?: boolean | Prisma.projetDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["participation_projet"]>;
export type participation_projetSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_projet?: boolean;
    id_utilisateur?: boolean;
    date_participation?: boolean;
    statut?: boolean;
    projet?: boolean | Prisma.projetDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["participation_projet"]>;
export type participation_projetSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_projet?: boolean;
    id_utilisateur?: boolean;
    date_participation?: boolean;
    statut?: boolean;
    projet?: boolean | Prisma.projetDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["participation_projet"]>;
export type participation_projetSelectScalar = {
    id_projet?: boolean;
    id_utilisateur?: boolean;
    date_participation?: boolean;
    statut?: boolean;
};
export type participation_projetOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_projet" | "id_utilisateur" | "date_participation" | "statut", ExtArgs["result"]["participation_projet"]>;
export type participation_projetInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    projet?: boolean | Prisma.projetDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type participation_projetIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    projet?: boolean | Prisma.projetDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type participation_projetIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    projet?: boolean | Prisma.projetDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $participation_projetPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "participation_projet";
    objects: {
        projet: Prisma.$projetPayload<ExtArgs>;
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_projet: bigint;
        id_utilisateur: bigint;
        date_participation: Date;
        statut: string;
    }, ExtArgs["result"]["participation_projet"]>;
    composites: {};
};
export type participation_projetGetPayload<S extends boolean | null | undefined | participation_projetDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$participation_projetPayload, S>;
export type participation_projetCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<participation_projetFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: Participation_projetCountAggregateInputType | true;
};
export interface participation_projetDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['participation_projet'];
        meta: {
            name: 'participation_projet';
        };
    };
    findUnique<T extends participation_projetFindUniqueArgs>(args: Prisma.SelectSubset<T, participation_projetFindUniqueArgs<ExtArgs>>): Prisma.Prisma__participation_projetClient<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends participation_projetFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, participation_projetFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__participation_projetClient<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends participation_projetFindFirstArgs>(args?: Prisma.SelectSubset<T, participation_projetFindFirstArgs<ExtArgs>>): Prisma.Prisma__participation_projetClient<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends participation_projetFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, participation_projetFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__participation_projetClient<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends participation_projetFindManyArgs>(args?: Prisma.SelectSubset<T, participation_projetFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends participation_projetCreateArgs>(args: Prisma.SelectSubset<T, participation_projetCreateArgs<ExtArgs>>): Prisma.Prisma__participation_projetClient<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends participation_projetCreateManyArgs>(args?: Prisma.SelectSubset<T, participation_projetCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends participation_projetCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, participation_projetCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends participation_projetDeleteArgs>(args: Prisma.SelectSubset<T, participation_projetDeleteArgs<ExtArgs>>): Prisma.Prisma__participation_projetClient<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends participation_projetUpdateArgs>(args: Prisma.SelectSubset<T, participation_projetUpdateArgs<ExtArgs>>): Prisma.Prisma__participation_projetClient<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends participation_projetDeleteManyArgs>(args?: Prisma.SelectSubset<T, participation_projetDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends participation_projetUpdateManyArgs>(args: Prisma.SelectSubset<T, participation_projetUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends participation_projetUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, participation_projetUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends participation_projetUpsertArgs>(args: Prisma.SelectSubset<T, participation_projetUpsertArgs<ExtArgs>>): Prisma.Prisma__participation_projetClient<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends participation_projetCountArgs>(args?: Prisma.Subset<T, participation_projetCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], Participation_projetCountAggregateOutputType> : number>;
    aggregate<T extends Participation_projetAggregateArgs>(args: Prisma.Subset<T, Participation_projetAggregateArgs>): Prisma.PrismaPromise<GetParticipation_projetAggregateType<T>>;
    groupBy<T extends participation_projetGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: participation_projetGroupByArgs['orderBy'];
    } : {
        orderBy?: participation_projetGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, participation_projetGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetParticipation_projetGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: participation_projetFieldRefs;
}
export interface Prisma__participation_projetClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    projet<T extends Prisma.projetDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.projetDefaultArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    utilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface participation_projetFieldRefs {
    readonly id_projet: Prisma.FieldRef<"participation_projet", 'BigInt'>;
    readonly id_utilisateur: Prisma.FieldRef<"participation_projet", 'BigInt'>;
    readonly date_participation: Prisma.FieldRef<"participation_projet", 'DateTime'>;
    readonly statut: Prisma.FieldRef<"participation_projet", 'String'>;
}
export type participation_projetFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    where: Prisma.participation_projetWhereUniqueInput;
};
export type participation_projetFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    where: Prisma.participation_projetWhereUniqueInput;
};
export type participation_projetFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    where?: Prisma.participation_projetWhereInput;
    orderBy?: Prisma.participation_projetOrderByWithRelationInput | Prisma.participation_projetOrderByWithRelationInput[];
    cursor?: Prisma.participation_projetWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Participation_projetScalarFieldEnum | Prisma.Participation_projetScalarFieldEnum[];
};
export type participation_projetFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    where?: Prisma.participation_projetWhereInput;
    orderBy?: Prisma.participation_projetOrderByWithRelationInput | Prisma.participation_projetOrderByWithRelationInput[];
    cursor?: Prisma.participation_projetWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Participation_projetScalarFieldEnum | Prisma.Participation_projetScalarFieldEnum[];
};
export type participation_projetFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    where?: Prisma.participation_projetWhereInput;
    orderBy?: Prisma.participation_projetOrderByWithRelationInput | Prisma.participation_projetOrderByWithRelationInput[];
    cursor?: Prisma.participation_projetWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Participation_projetScalarFieldEnum | Prisma.Participation_projetScalarFieldEnum[];
};
export type participation_projetCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.participation_projetCreateInput, Prisma.participation_projetUncheckedCreateInput>;
};
export type participation_projetCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.participation_projetCreateManyInput | Prisma.participation_projetCreateManyInput[];
    skipDuplicates?: boolean;
};
export type participation_projetCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    data: Prisma.participation_projetCreateManyInput | Prisma.participation_projetCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.participation_projetIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type participation_projetUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.participation_projetUpdateInput, Prisma.participation_projetUncheckedUpdateInput>;
    where: Prisma.participation_projetWhereUniqueInput;
};
export type participation_projetUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.participation_projetUpdateManyMutationInput, Prisma.participation_projetUncheckedUpdateManyInput>;
    where?: Prisma.participation_projetWhereInput;
    limit?: number;
};
export type participation_projetUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.participation_projetUpdateManyMutationInput, Prisma.participation_projetUncheckedUpdateManyInput>;
    where?: Prisma.participation_projetWhereInput;
    limit?: number;
    include?: Prisma.participation_projetIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type participation_projetUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    where: Prisma.participation_projetWhereUniqueInput;
    create: Prisma.XOR<Prisma.participation_projetCreateInput, Prisma.participation_projetUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.participation_projetUpdateInput, Prisma.participation_projetUncheckedUpdateInput>;
};
export type participation_projetDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    where: Prisma.participation_projetWhereUniqueInput;
};
export type participation_projetDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.participation_projetWhereInput;
    limit?: number;
};
export type participation_projetDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
};
