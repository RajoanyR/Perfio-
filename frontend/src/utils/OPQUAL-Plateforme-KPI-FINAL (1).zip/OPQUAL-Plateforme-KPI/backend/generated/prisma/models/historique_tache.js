export {};
//# sourceMappingURL=historique_tache.js.map