import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type piece_jointeModel = runtime.Types.Result.DefaultSelection<Prisma.$piece_jointePayload>;
export type AggregatePiece_jointe = {
    _count: Piece_jointeCountAggregateOutputType | null;
    _avg: Piece_jointeAvgAggregateOutputType | null;
    _sum: Piece_jointeSumAggregateOutputType | null;
    _min: Piece_jointeMinAggregateOutputType | null;
    _max: Piece_jointeMaxAggregateOutputType | null;
};
export type Piece_jointeAvgAggregateOutputType = {
    id_piece_jointe: number | null;
    id_tache: number | null;
    id_commentaire: number | null;
    id_utilisateur: number | null;
    taille: number | null;
};
export type Piece_jointeSumAggregateOutputType = {
    id_piece_jointe: bigint | null;
    id_tache: bigint | null;
    id_commentaire: bigint | null;
    id_utilisateur: bigint | null;
    taille: bigint | null;
};
export type Piece_jointeMinAggregateOutputType = {
    id_piece_jointe: bigint | null;
    id_tache: bigint | null;
    id_commentaire: bigint | null;
    id_utilisateur: bigint | null;
    nom_fichier: string | null;
    chemin_fichier: string | null;
    type_fichier: string | null;
    taille: bigint | null;
    date_ajout: Date | null;
};
export type Piece_jointeMaxAggregateOutputType = {
    id_piece_jointe: bigint | null;
    id_tache: bigint | null;
    id_commentaire: bigint | null;
    id_utilisateur: bigint | null;
    nom_fichier: string | null;
    chemin_fichier: string | null;
    type_fichier: string | null;
    taille: bigint | null;
    date_ajout: Date | null;
};
export type Piece_jointeCountAggregateOutputType = {
    id_piece_jointe: number;
    id_tache: number;
    id_commentaire: number;
    id_utilisateur: number;
    nom_fichier: number;
    chemin_fichier: number;
    type_fichier: number;
    taille: number;
    date_ajout: number;
    _all: number;
};
export type Piece_jointeAvgAggregateInputType = {
    id_piece_jointe?: true;
    id_tache?: true;
    id_commentaire?: true;
    id_utilisateur?: true;
    taille?: true;
};
export type Piece_jointeSumAggregateInputType = {
    id_piece_jointe?: true;
    id_tache?: true;
    id_commentaire?: true;
    id_utilisateur?: true;
    taille?: true;
};
export type Piece_jointeMinAggregateInputType = {
    id_piece_jointe?: true;
    id_tache?: true;
    id_commentaire?: true;
    id_utilisateur?: true;
    nom_fichier?: true;
    chemin_fichier?: true;
    type_fichier?: true;
    taille?: true;
    date_ajout?: true;
};
export type Piece_jointeMaxAggregateInputType = {
    id_piece_jointe?: true;
    id_tache?: true;
    id_commentaire?: true;
    id_utilisateur?: true;
    nom_fichier?: true;
    chemin_fichier?: true;
    type_fichier?: true;
    taille?: true;
    date_ajout?: true;
};
export type Piece_jointeCountAggregateInputType = {
    id_piece_jointe?: true;
    id_tache?: true;
    id_commentaire?: true;
    id_utilisateur?: true;
    nom_fichier?: true;
    chemin_fichier?: true;
    type_fichier?: true;
    taille?: true;
    date_ajout?: true;
    _all?: true;
};
export type Piece_jointeAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.piece_jointeWhereInput;
    orderBy?: Prisma.piece_jointeOrderByWithRelationInput | Prisma.piece_jointeOrderByWithRelationInput[];
    cursor?: Prisma.piece_jointeWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | Piece_jointeCountAggregateInputType;
    _avg?: Piece_jointeAvgAggregateInputType;
    _sum?: Piece_jointeSumAggregateInputType;
    _min?: Piece_jointeMinAggregateInputType;
    _max?: Piece_jointeMaxAggregateInputType;
};
export type GetPiece_jointeAggregateType<T extends Piece_jointeAggregateArgs> = {
    [P in keyof T & keyof AggregatePiece_jointe]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregatePiece_jointe[P]> : Prisma.GetScalarType<T[P], AggregatePiece_jointe[P]>;
};
export type piece_jointeGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.piece_jointeWhereInput;
    orderBy?: Prisma.piece_jointeOrderByWithAggregationInput | Prisma.piece_jointeOrderByWithAggregationInput[];
    by: Prisma.Piece_jointeScalarFieldEnum[] | Prisma.Piece_jointeScalarFieldEnum;
    having?: Prisma.piece_jointeScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: Piece_jointeCountAggregateInputType | true;
    _avg?: Piece_jointeAvgAggregateInputType;
    _sum?: Piece_jointeSumAggregateInputType;
    _min?: Piece_jointeMinAggregateInputType;
    _max?: Piece_jointeMaxAggregateInputType;
};
export type Piece_jointeGroupByOutputType = {
    id_piece_jointe: bigint;
    id_tache: bigint | null;
    id_commentaire: bigint | null;
    id_utilisateur: bigint;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier: string | null;
    taille: bigint | null;
    date_ajout: Date;
    _count: Piece_jointeCountAggregateOutputType | null;
    _avg: Piece_jointeAvgAggregateOutputType | null;
    _sum: Piece_jointeSumAggregateOutputType | null;
    _min: Piece_jointeMinAggregateOutputType | null;
    _max: Piece_jointeMaxAggregateOutputType | null;
};
export type GetPiece_jointeGroupByPayload<T extends piece_jointeGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<Piece_jointeGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof Piece_jointeGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], Piece_jointeGroupByOutputType[P]> : Prisma.GetScalarType<T[P], Piece_jointeGroupByOutputType[P]>;
}>>;
export type piece_jointeWhereInput = {
    AND?: Prisma.piece_jointeWhereInput | Prisma.piece_jointeWhereInput[];
    OR?: Prisma.piece_jointeWhereInput[];
    NOT?: Prisma.piece_jointeWhereInput | Prisma.piece_jointeWhereInput[];
    id_piece_jointe?: Prisma.BigIntFilter<"piece_jointe"> | bigint | number;
    id_tache?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    id_commentaire?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFilter<"piece_jointe"> | bigint | number;
    nom_fichier?: Prisma.StringFilter<"piece_jointe"> | string;
    chemin_fichier?: Prisma.StringFilter<"piece_jointe"> | string;
    type_fichier?: Prisma.StringNullableFilter<"piece_jointe"> | string | null;
    taille?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    date_ajout?: Prisma.DateTimeFilter<"piece_jointe"> | Date | string;
    tache?: Prisma.XOR<Prisma.TacheNullableScalarRelationFilter, Prisma.tacheWhereInput> | null;
    commentaire?: Prisma.XOR<Prisma.CommentaireNullableScalarRelationFilter, Prisma.commentaireWhereInput> | null;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
};
export type piece_jointeOrderByWithRelationInput = {
    id_piece_jointe?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrderInput | Prisma.SortOrder;
    id_commentaire?: Prisma.SortOrderInput | Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    nom_fichier?: Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrder;
    type_fichier?: Prisma.SortOrderInput | Prisma.SortOrder;
    taille?: Prisma.SortOrderInput | Prisma.SortOrder;
    date_ajout?: Prisma.SortOrder;
    tache?: Prisma.tacheOrderByWithRelationInput;
    commentaire?: Prisma.commentaireOrderByWithRelationInput;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
};
export type piece_jointeWhereUniqueInput = Prisma.AtLeast<{
    id_piece_jointe?: bigint | number;
    AND?: Prisma.piece_jointeWhereInput | Prisma.piece_jointeWhereInput[];
    OR?: Prisma.piece_jointeWhereInput[];
    NOT?: Prisma.piece_jointeWhereInput | Prisma.piece_jointeWhereInput[];
    id_tache?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    id_commentaire?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFilter<"piece_jointe"> | bigint | number;
    nom_fichier?: Prisma.StringFilter<"piece_jointe"> | string;
    chemin_fichier?: Prisma.StringFilter<"piece_jointe"> | string;
    type_fichier?: Prisma.StringNullableFilter<"piece_jointe"> | string | null;
    taille?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    date_ajout?: Prisma.DateTimeFilter<"piece_jointe"> | Date | string;
    tache?: Prisma.XOR<Prisma.TacheNullableScalarRelationFilter, Prisma.tacheWhereInput> | null;
    commentaire?: Prisma.XOR<Prisma.CommentaireNullableScalarRelationFilter, Prisma.commentaireWhereInput> | null;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
}, "id_piece_jointe">;
export type piece_jointeOrderByWithAggregationInput = {
    id_piece_jointe?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrderInput | Prisma.SortOrder;
    id_commentaire?: Prisma.SortOrderInput | Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    nom_fichier?: Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrder;
    type_fichier?: Prisma.SortOrderInput | Prisma.SortOrder;
    taille?: Prisma.SortOrderInput | Prisma.SortOrder;
    date_ajout?: Prisma.SortOrder;
    _count?: Prisma.piece_jointeCountOrderByAggregateInput;
    _avg?: Prisma.piece_jointeAvgOrderByAggregateInput;
    _max?: Prisma.piece_jointeMaxOrderByAggregateInput;
    _min?: Prisma.piece_jointeMinOrderByAggregateInput;
    _sum?: Prisma.piece_jointeSumOrderByAggregateInput;
};
export type piece_jointeScalarWhereWithAggregatesInput = {
    AND?: Prisma.piece_jointeScalarWhereWithAggregatesInput | Prisma.piece_jointeScalarWhereWithAggregatesInput[];
    OR?: Prisma.piece_jointeScalarWhereWithAggregatesInput[];
    NOT?: Prisma.piece_jointeScalarWhereWithAggregatesInput | Prisma.piece_jointeScalarWhereWithAggregatesInput[];
    id_piece_jointe?: Prisma.BigIntWithAggregatesFilter<"piece_jointe"> | bigint | number;
    id_tache?: Prisma.BigIntNullableWithAggregatesFilter<"piece_jointe"> | bigint | number | null;
    id_commentaire?: Prisma.BigIntNullableWithAggregatesFilter<"piece_jointe"> | bigint | number | null;
    id_utilisateur?: Prisma.BigIntWithAggregatesFilter<"piece_jointe"> | bigint | number;
    nom_fichier?: Prisma.StringWithAggregatesFilter<"piece_jointe"> | string;
    chemin_fichier?: Prisma.StringWithAggregatesFilter<"piece_jointe"> | string;
    type_fichier?: Prisma.StringNullableWithAggregatesFilter<"piece_jointe"> | string | null;
    taille?: Prisma.BigIntNullableWithAggregatesFilter<"piece_jointe"> | bigint | number | null;
    date_ajout?: Prisma.DateTimeWithAggregatesFilter<"piece_jointe"> | Date | string;
};
export type piece_jointeCreateInput = {
    id_piece_jointe?: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
    tache?: Prisma.tacheCreateNestedOneWithoutPiece_jointeInput;
    commentaire?: Prisma.commentaireCreateNestedOneWithoutPiece_jointeInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutPiece_jointeInput;
};
export type piece_jointeUncheckedCreateInput = {
    id_piece_jointe?: bigint | number;
    id_tache?: bigint | number | null;
    id_commentaire?: bigint | number | null;
    id_utilisateur: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
};
export type piece_jointeUpdateInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneWithoutPiece_jointeNestedInput;
    commentaire?: Prisma.commentaireUpdateOneWithoutPiece_jointeNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutPiece_jointeNestedInput;
};
export type piece_jointeUncheckedUpdateInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_commentaire?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type piece_jointeCreateManyInput = {
    id_piece_jointe?: bigint | number;
    id_tache?: bigint | number | null;
    id_commentaire?: bigint | number | null;
    id_utilisateur: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
};
export type piece_jointeUpdateManyMutationInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type piece_jointeUncheckedUpdateManyInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_commentaire?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type Piece_jointeListRelationFilter = {
    every?: Prisma.piece_jointeWhereInput;
    some?: Prisma.piece_jointeWhereInput;
    none?: Prisma.piece_jointeWhereInput;
};
export type piece_jointeOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type piece_jointeCountOrderByAggregateInput = {
    id_piece_jointe?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_commentaire?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    nom_fichier?: Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrder;
    type_fichier?: Prisma.SortOrder;
    taille?: Prisma.SortOrder;
    date_ajout?: Prisma.SortOrder;
};
export type piece_jointeAvgOrderByAggregateInput = {
    id_piece_jointe?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_commentaire?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    taille?: Prisma.SortOrder;
};
export type piece_jointeMaxOrderByAggregateInput = {
    id_piece_jointe?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_commentaire?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    nom_fichier?: Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrder;
    type_fichier?: Prisma.SortOrder;
    taille?: Prisma.SortOrder;
    date_ajout?: Prisma.SortOrder;
};
export type piece_jointeMinOrderByAggregateInput = {
    id_piece_jointe?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_commentaire?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    nom_fichier?: Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrder;
    type_fichier?: Prisma.SortOrder;
    taille?: Prisma.SortOrder;
    date_ajout?: Prisma.SortOrder;
};
export type piece_jointeSumOrderByAggregateInput = {
    id_piece_jointe?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_commentaire?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    taille?: Prisma.SortOrder;
};
export type piece_jointeCreateNestedManyWithoutCommentaireInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutCommentaireInput, Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput> | Prisma.piece_jointeCreateWithoutCommentaireInput[] | Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutCommentaireInput | Prisma.piece_jointeCreateOrConnectWithoutCommentaireInput[];
    createMany?: Prisma.piece_jointeCreateManyCommentaireInputEnvelope;
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
};
export type piece_jointeUncheckedCreateNestedManyWithoutCommentaireInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutCommentaireInput, Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput> | Prisma.piece_jointeCreateWithoutCommentaireInput[] | Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutCommentaireInput | Prisma.piece_jointeCreateOrConnectWithoutCommentaireInput[];
    createMany?: Prisma.piece_jointeCreateManyCommentaireInputEnvelope;
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
};
export type piece_jointeUpdateManyWithoutCommentaireNestedInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutCommentaireInput, Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput> | Prisma.piece_jointeCreateWithoutCommentaireInput[] | Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutCommentaireInput | Prisma.piece_jointeCreateOrConnectWithoutCommentaireInput[];
    upsert?: Prisma.piece_jointeUpsertWithWhereUniqueWithoutCommentaireInput | Prisma.piece_jointeUpsertWithWhereUniqueWithoutCommentaireInput[];
    createMany?: Prisma.piece_jointeCreateManyCommentaireInputEnvelope;
    set?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    disconnect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    delete?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    update?: Prisma.piece_jointeUpdateWithWhereUniqueWithoutCommentaireInput | Prisma.piece_jointeUpdateWithWhereUniqueWithoutCommentaireInput[];
    updateMany?: Prisma.piece_jointeUpdateManyWithWhereWithoutCommentaireInput | Prisma.piece_jointeUpdateManyWithWhereWithoutCommentaireInput[];
    deleteMany?: Prisma.piece_jointeScalarWhereInput | Prisma.piece_jointeScalarWhereInput[];
};
export type piece_jointeUncheckedUpdateManyWithoutCommentaireNestedInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutCommentaireInput, Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput> | Prisma.piece_jointeCreateWithoutCommentaireInput[] | Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutCommentaireInput | Prisma.piece_jointeCreateOrConnectWithoutCommentaireInput[];
    upsert?: Prisma.piece_jointeUpsertWithWhereUniqueWithoutCommentaireInput | Prisma.piece_jointeUpsertWithWhereUniqueWithoutCommentaireInput[];
    createMany?: Prisma.piece_jointeCreateManyCommentaireInputEnvelope;
    set?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    disconnect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    delete?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    update?: Prisma.piece_jointeUpdateWithWhereUniqueWithoutCommentaireInput | Prisma.piece_jointeUpdateWithWhereUniqueWithoutCommentaireInput[];
    updateMany?: Prisma.piece_jointeUpdateManyWithWhereWithoutCommentaireInput | Prisma.piece_jointeUpdateManyWithWhereWithoutCommentaireInput[];
    deleteMany?: Prisma.piece_jointeScalarWhereInput | Prisma.piece_jointeScalarWhereInput[];
};
export type piece_jointeCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutTacheInput, Prisma.piece_jointeUncheckedCreateWithoutTacheInput> | Prisma.piece_jointeCreateWithoutTacheInput[] | Prisma.piece_jointeUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutTacheInput | Prisma.piece_jointeCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.piece_jointeCreateManyTacheInputEnvelope;
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
};
export type piece_jointeUncheckedCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutTacheInput, Prisma.piece_jointeUncheckedCreateWithoutTacheInput> | Prisma.piece_jointeCreateWithoutTacheInput[] | Prisma.piece_jointeUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutTacheInput | Prisma.piece_jointeCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.piece_jointeCreateManyTacheInputEnvelope;
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
};
export type piece_jointeUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutTacheInput, Prisma.piece_jointeUncheckedCreateWithoutTacheInput> | Prisma.piece_jointeCreateWithoutTacheInput[] | Prisma.piece_jointeUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutTacheInput | Prisma.piece_jointeCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.piece_jointeUpsertWithWhereUniqueWithoutTacheInput | Prisma.piece_jointeUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.piece_jointeCreateManyTacheInputEnvelope;
    set?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    disconnect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    delete?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    update?: Prisma.piece_jointeUpdateWithWhereUniqueWithoutTacheInput | Prisma.piece_jointeUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.piece_jointeUpdateManyWithWhereWithoutTacheInput | Prisma.piece_jointeUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.piece_jointeScalarWhereInput | Prisma.piece_jointeScalarWhereInput[];
};
export type piece_jointeUncheckedUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutTacheInput, Prisma.piece_jointeUncheckedCreateWithoutTacheInput> | Prisma.piece_jointeCreateWithoutTacheInput[] | Prisma.piece_jointeUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutTacheInput | Prisma.piece_jointeCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.piece_jointeUpsertWithWhereUniqueWithoutTacheInput | Prisma.piece_jointeUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.piece_jointeCreateManyTacheInputEnvelope;
    set?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    disconnect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    delete?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    update?: Prisma.piece_jointeUpdateWithWhereUniqueWithoutTacheInput | Prisma.piece_jointeUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.piece_jointeUpdateManyWithWhereWithoutTacheInput | Prisma.piece_jointeUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.piece_jointeScalarWhereInput | Prisma.piece_jointeScalarWhereInput[];
};
export type piece_jointeCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutUtilisateurInput, Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput> | Prisma.piece_jointeCreateWithoutUtilisateurInput[] | Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutUtilisateurInput | Prisma.piece_jointeCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.piece_jointeCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
};
export type piece_jointeUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutUtilisateurInput, Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput> | Prisma.piece_jointeCreateWithoutUtilisateurInput[] | Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutUtilisateurInput | Prisma.piece_jointeCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.piece_jointeCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
};
export type piece_jointeUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutUtilisateurInput, Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput> | Prisma.piece_jointeCreateWithoutUtilisateurInput[] | Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutUtilisateurInput | Prisma.piece_jointeCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.piece_jointeUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.piece_jointeUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.piece_jointeCreateManyUtilisateurInputEnvelope;
    set?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    disconnect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    delete?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    update?: Prisma.piece_jointeUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.piece_jointeUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.piece_jointeUpdateManyWithWhereWithoutUtilisateurInput | Prisma.piece_jointeUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.piece_jointeScalarWhereInput | Prisma.piece_jointeScalarWhereInput[];
};
export type piece_jointeUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.piece_jointeCreateWithoutUtilisateurInput, Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput> | Prisma.piece_jointeCreateWithoutUtilisateurInput[] | Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.piece_jointeCreateOrConnectWithoutUtilisateurInput | Prisma.piece_jointeCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.piece_jointeUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.piece_jointeUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.piece_jointeCreateManyUtilisateurInputEnvelope;
    set?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    disconnect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    delete?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    connect?: Prisma.piece_jointeWhereUniqueInput | Prisma.piece_jointeWhereUniqueInput[];
    update?: Prisma.piece_jointeUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.piece_jointeUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.piece_jointeUpdateManyWithWhereWithoutUtilisateurInput | Prisma.piece_jointeUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.piece_jointeScalarWhereInput | Prisma.piece_jointeScalarWhereInput[];
};
export type piece_jointeCreateWithoutCommentaireInput = {
    id_piece_jointe?: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
    tache?: Prisma.tacheCreateNestedOneWithoutPiece_jointeInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutPiece_jointeInput;
};
export type piece_jointeUncheckedCreateWithoutCommentaireInput = {
    id_piece_jointe?: bigint | number;
    id_tache?: bigint | number | null;
    id_utilisateur: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
};
export type piece_jointeCreateOrConnectWithoutCommentaireInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    create: Prisma.XOR<Prisma.piece_jointeCreateWithoutCommentaireInput, Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput>;
};
export type piece_jointeCreateManyCommentaireInputEnvelope = {
    data: Prisma.piece_jointeCreateManyCommentaireInput | Prisma.piece_jointeCreateManyCommentaireInput[];
    skipDuplicates?: boolean;
};
export type piece_jointeUpsertWithWhereUniqueWithoutCommentaireInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    update: Prisma.XOR<Prisma.piece_jointeUpdateWithoutCommentaireInput, Prisma.piece_jointeUncheckedUpdateWithoutCommentaireInput>;
    create: Prisma.XOR<Prisma.piece_jointeCreateWithoutCommentaireInput, Prisma.piece_jointeUncheckedCreateWithoutCommentaireInput>;
};
export type piece_jointeUpdateWithWhereUniqueWithoutCommentaireInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    data: Prisma.XOR<Prisma.piece_jointeUpdateWithoutCommentaireInput, Prisma.piece_jointeUncheckedUpdateWithoutCommentaireInput>;
};
export type piece_jointeUpdateManyWithWhereWithoutCommentaireInput = {
    where: Prisma.piece_jointeScalarWhereInput;
    data: Prisma.XOR<Prisma.piece_jointeUpdateManyMutationInput, Prisma.piece_jointeUncheckedUpdateManyWithoutCommentaireInput>;
};
export type piece_jointeScalarWhereInput = {
    AND?: Prisma.piece_jointeScalarWhereInput | Prisma.piece_jointeScalarWhereInput[];
    OR?: Prisma.piece_jointeScalarWhereInput[];
    NOT?: Prisma.piece_jointeScalarWhereInput | Prisma.piece_jointeScalarWhereInput[];
    id_piece_jointe?: Prisma.BigIntFilter<"piece_jointe"> | bigint | number;
    id_tache?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    id_commentaire?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFilter<"piece_jointe"> | bigint | number;
    nom_fichier?: Prisma.StringFilter<"piece_jointe"> | string;
    chemin_fichier?: Prisma.StringFilter<"piece_jointe"> | string;
    type_fichier?: Prisma.StringNullableFilter<"piece_jointe"> | string | null;
    taille?: Prisma.BigIntNullableFilter<"piece_jointe"> | bigint | number | null;
    date_ajout?: Prisma.DateTimeFilter<"piece_jointe"> | Date | string;
};
export type piece_jointeCreateWithoutTacheInput = {
    id_piece_jointe?: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
    commentaire?: Prisma.commentaireCreateNestedOneWithoutPiece_jointeInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutPiece_jointeInput;
};
export type piece_jointeUncheckedCreateWithoutTacheInput = {
    id_piece_jointe?: bigint | number;
    id_commentaire?: bigint | number | null;
    id_utilisateur: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
};
export type piece_jointeCreateOrConnectWithoutTacheInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    create: Prisma.XOR<Prisma.piece_jointeCreateWithoutTacheInput, Prisma.piece_jointeUncheckedCreateWithoutTacheInput>;
};
export type piece_jointeCreateManyTacheInputEnvelope = {
    data: Prisma.piece_jointeCreateManyTacheInput | Prisma.piece_jointeCreateManyTacheInput[];
    skipDuplicates?: boolean;
};
export type piece_jointeUpsertWithWhereUniqueWithoutTacheInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    update: Prisma.XOR<Prisma.piece_jointeUpdateWithoutTacheInput, Prisma.piece_jointeUncheckedUpdateWithoutTacheInput>;
    create: Prisma.XOR<Prisma.piece_jointeCreateWithoutTacheInput, Prisma.piece_jointeUncheckedCreateWithoutTacheInput>;
};
export type piece_jointeUpdateWithWhereUniqueWithoutTacheInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    data: Prisma.XOR<Prisma.piece_jointeUpdateWithoutTacheInput, Prisma.piece_jointeUncheckedUpdateWithoutTacheInput>;
};
export type piece_jointeUpdateManyWithWhereWithoutTacheInput = {
    where: Prisma.piece_jointeScalarWhereInput;
    data: Prisma.XOR<Prisma.piece_jointeUpdateManyMutationInput, Prisma.piece_jointeUncheckedUpdateManyWithoutTacheInput>;
};
export type piece_jointeCreateWithoutUtilisateurInput = {
    id_piece_jointe?: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
    tache?: Prisma.tacheCreateNestedOneWithoutPiece_jointeInput;
    commentaire?: Prisma.commentaireCreateNestedOneWithoutPiece_jointeInput;
};
export type piece_jointeUncheckedCreateWithoutUtilisateurInput = {
    id_piece_jointe?: bigint | number;
    id_tache?: bigint | number | null;
    id_commentaire?: bigint | number | null;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
};
export type piece_jointeCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    create: Prisma.XOR<Prisma.piece_jointeCreateWithoutUtilisateurInput, Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput>;
};
export type piece_jointeCreateManyUtilisateurInputEnvelope = {
    data: Prisma.piece_jointeCreateManyUtilisateurInput | Prisma.piece_jointeCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type piece_jointeUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    update: Prisma.XOR<Prisma.piece_jointeUpdateWithoutUtilisateurInput, Prisma.piece_jointeUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.piece_jointeCreateWithoutUtilisateurInput, Prisma.piece_jointeUncheckedCreateWithoutUtilisateurInput>;
};
export type piece_jointeUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.piece_jointeWhereUniqueInput;
    data: Prisma.XOR<Prisma.piece_jointeUpdateWithoutUtilisateurInput, Prisma.piece_jointeUncheckedUpdateWithoutUtilisateurInput>;
};
export type piece_jointeUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.piece_jointeScalarWhereInput;
    data: Prisma.XOR<Prisma.piece_jointeUpdateManyMutationInput, Prisma.piece_jointeUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type piece_jointeCreateManyCommentaireInput = {
    id_piece_jointe?: bigint | number;
    id_tache?: bigint | number | null;
    id_utilisateur: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
};
export type piece_jointeUpdateWithoutCommentaireInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneWithoutPiece_jointeNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutPiece_jointeNestedInput;
};
export type piece_jointeUncheckedUpdateWithoutCommentaireInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type piece_jointeUncheckedUpdateManyWithoutCommentaireInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type piece_jointeCreateManyTacheInput = {
    id_piece_jointe?: bigint | number;
    id_commentaire?: bigint | number | null;
    id_utilisateur: bigint | number;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
};
export type piece_jointeUpdateWithoutTacheInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    commentaire?: Prisma.commentaireUpdateOneWithoutPiece_jointeNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutPiece_jointeNestedInput;
};
export type piece_jointeUncheckedUpdateWithoutTacheInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_commentaire?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type piece_jointeUncheckedUpdateManyWithoutTacheInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_commentaire?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type piece_jointeCreateManyUtilisateurInput = {
    id_piece_jointe?: bigint | number;
    id_tache?: bigint | number | null;
    id_commentaire?: bigint | number | null;
    nom_fichier: string;
    chemin_fichier: string;
    type_fichier?: string | null;
    taille?: bigint | number | null;
    date_ajout?: Date | string;
};
export type piece_jointeUpdateWithoutUtilisateurInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneWithoutPiece_jointeNestedInput;
    commentaire?: Prisma.commentaireUpdateOneWithoutPiece_jointeNestedInput;
};
export type piece_jointeUncheckedUpdateWithoutUtilisateurInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_commentaire?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type piece_jointeUncheckedUpdateManyWithoutUtilisateurInput = {
    id_piece_jointe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    id_commentaire?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    nom_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    chemin_fichier?: Prisma.StringFieldUpdateOperationsInput | string;
    type_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    taille?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    date_ajout?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type piece_jointeSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_piece_jointe?: boolean;
    id_tache?: boolean;
    id_commentaire?: boolean;
    id_utilisateur?: boolean;
    nom_fichier?: boolean;
    chemin_fichier?: boolean;
    type_fichier?: boolean;
    taille?: boolean;
    date_ajout?: boolean;
    tache?: boolean | Prisma.piece_jointe$tacheArgs<ExtArgs>;
    commentaire?: boolean | Prisma.piece_jointe$commentaireArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["piece_jointe"]>;
export type piece_jointeSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_piece_jointe?: boolean;
    id_tache?: boolean;
    id_commentaire?: boolean;
    id_utilisateur?: boolean;
    nom_fichier?: boolean;
    chemin_fichier?: boolean;
    type_fichier?: boolean;
    taille?: boolean;
    date_ajout?: boolean;
    tache?: boolean | Prisma.piece_jointe$tacheArgs<ExtArgs>;
    commentaire?: boolean | Prisma.piece_jointe$commentaireArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["piece_jointe"]>;
export type piece_jointeSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_piece_jointe?: boolean;
    id_tache?: boolean;
    id_commentaire?: boolean;
    id_utilisateur?: boolean;
    nom_fichier?: boolean;
    chemin_fichier?: boolean;
    type_fichier?: boolean;
    taille?: boolean;
    date_ajout?: boolean;
    tache?: boolean | Prisma.piece_jointe$tacheArgs<ExtArgs>;
    commentaire?: boolean | Prisma.piece_jointe$commentaireArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["piece_jointe"]>;
export type piece_jointeSelectScalar = {
    id_piece_jointe?: boolean;
    id_tache?: boolean;
    id_commentaire?: boolean;
    id_utilisateur?: boolean;
    nom_fichier?: boolean;
    chemin_fichier?: boolean;
    type_fichier?: boolean;
    taille?: boolean;
    date_ajout?: boolean;
};
export type piece_jointeOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_piece_jointe" | "id_tache" | "id_commentaire" | "id_utilisateur" | "nom_fichier" | "chemin_fichier" | "type_fichier" | "taille" | "date_ajout", ExtArgs["result"]["piece_jointe"]>;
export type piece_jointeInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.piece_jointe$tacheArgs<ExtArgs>;
    commentaire?: boolean | Prisma.piece_jointe$commentaireArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type piece_jointeIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.piece_jointe$tacheArgs<ExtArgs>;
    commentaire?: boolean | Prisma.piece_jointe$commentaireArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type piece_jointeIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.piece_jointe$tacheArgs<ExtArgs>;
    commentaire?: boolean | Prisma.piece_jointe$commentaireArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $piece_jointePayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "piece_jointe";
    objects: {
        tache: Prisma.$tachePayload<ExtArgs> | null;
        commentaire: Prisma.$commentairePayload<ExtArgs> | null;
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_piece_jointe: bigint;
        id_tache: bigint | null;
        id_commentaire: bigint | null;
        id_utilisateur: bigint;
        nom_fichier: string;
        chemin_fichier: string;
        type_fichier: string | null;
        taille: bigint | null;
        date_ajout: Date;
    }, ExtArgs["result"]["piece_jointe"]>;
    composites: {};
};
export type piece_jointeGetPayload<S extends boolean | null | undefined | piece_jointeDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$piece_jointePayload, S>;
export type piece_jointeCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<piece_jointeFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: Piece_jointeCountAggregateInputType | true;
};
export interface piece_jointeDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['piece_jointe'];
        meta: {
            name: 'piece_jointe';
        };
    };
    findUnique<T extends piece_jointeFindUniqueArgs>(args: Prisma.SelectSubset<T, piece_jointeFindUniqueArgs<ExtArgs>>): Prisma.Prisma__piece_jointeClient<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends piece_jointeFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, piece_jointeFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__piece_jointeClient<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends piece_jointeFindFirstArgs>(args?: Prisma.SelectSubset<T, piece_jointeFindFirstArgs<ExtArgs>>): Prisma.Prisma__piece_jointeClient<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends piece_jointeFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, piece_jointeFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__piece_jointeClient<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends piece_jointeFindManyArgs>(args?: Prisma.SelectSubset<T, piece_jointeFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends piece_jointeCreateArgs>(args: Prisma.SelectSubset<T, piece_jointeCreateArgs<ExtArgs>>): Prisma.Prisma__piece_jointeClient<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends piece_jointeCreateManyArgs>(args?: Prisma.SelectSubset<T, piece_jointeCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends piece_jointeCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, piece_jointeCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends piece_jointeDeleteArgs>(args: Prisma.SelectSubset<T, piece_jointeDeleteArgs<ExtArgs>>): Prisma.Prisma__piece_jointeClient<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends piece_jointeUpdateArgs>(args: Prisma.SelectSubset<T, piece_jointeUpdateArgs<ExtArgs>>): Prisma.Prisma__piece_jointeClient<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends piece_jointeDeleteManyArgs>(args?: Prisma.SelectSubset<T, piece_jointeDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends piece_jointeUpdateManyArgs>(args: Prisma.SelectSubset<T, piece_jointeUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends piece_jointeUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, piece_jointeUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends piece_jointeUpsertArgs>(args: Prisma.SelectSubset<T, piece_jointeUpsertArgs<ExtArgs>>): Prisma.Prisma__piece_jointeClient<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends piece_jointeCountArgs>(args?: Prisma.Subset<T, piece_jointeCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], Piece_jointeCountAggregateOutputType> : number>;
    aggregate<T extends Piece_jointeAggregateArgs>(args: Prisma.Subset<T, Piece_jointeAggregateArgs>): Prisma.PrismaPromise<GetPiece_jointeAggregateType<T>>;
    groupBy<T extends piece_jointeGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: piece_jointeGroupByArgs['orderBy'];
    } : {
        orderBy?: piece_jointeGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, piece_jointeGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPiece_jointeGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: piece_jointeFieldRefs;
}
export interface Prisma__piece_jointeClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    tache<T extends Prisma.piece_jointe$tacheArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.piece_jointe$tacheArgs<ExtArgs>>): Prisma.Prisma__tacheClient<runtime.Types.Result.GetResult<Prisma.$tachePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    commentaire<T extends Prisma.piece_jointe$commentaireArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.piece_jointe$commentaireArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    utilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface piece_jointeFieldRefs {
    readonly id_piece_jointe: Prisma.FieldRef<"piece_jointe", 'BigInt'>;
    readonly id_tache: Prisma.FieldRef<"piece_jointe", 'BigInt'>;
    readonly id_commentaire: Prisma.FieldRef<"piece_jointe", 'BigInt'>;
    readonly id_utilisateur: Prisma.FieldRef<"piece_jointe", 'BigInt'>;
    readonly nom_fichier: Prisma.FieldRef<"piece_jointe", 'String'>;
    readonly chemin_fichier: Prisma.FieldRef<"piece_jointe", 'String'>;
    readonly type_fichier: Prisma.FieldRef<"piece_jointe", 'String'>;
    readonly taille: Prisma.FieldRef<"piece_jointe", 'BigInt'>;
    readonly date_ajout: Prisma.FieldRef<"piece_jointe", 'DateTime'>;
}
export type piece_jointeFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    where: Prisma.piece_jointeWhereUniqueInput;
};
export type piece_jointeFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    where: Prisma.piece_jointeWhereUniqueInput;
};
export type piece_jointeFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    where?: Prisma.piece_jointeWhereInput;
    orderBy?: Prisma.piece_jointeOrderByWithRelationInput | Prisma.piece_jointeOrderByWithRelationInput[];
    cursor?: Prisma.piece_jointeWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Piece_jointeScalarFieldEnum | Prisma.Piece_jointeScalarFieldEnum[];
};
export type piece_jointeFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    where?: Prisma.piece_jointeWhereInput;
    orderBy?: Prisma.piece_jointeOrderByWithRelationInput | Prisma.piece_jointeOrderByWithRelationInput[];
    cursor?: Prisma.piece_jointeWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Piece_jointeScalarFieldEnum | Prisma.Piece_jointeScalarFieldEnum[];
};
export type piece_jointeFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    where?: Prisma.piece_jointeWhereInput;
    orderBy?: Prisma.piece_jointeOrderByWithRelationInput | Prisma.piece_jointeOrderByWithRelationInput[];
    cursor?: Prisma.piece_jointeWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Piece_jointeScalarFieldEnum | Prisma.Piece_jointeScalarFieldEnum[];
};
export type piece_jointeCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.piece_jointeCreateInput, Prisma.piece_jointeUncheckedCreateInput>;
};
export type piece_jointeCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.piece_jointeCreateManyInput | Prisma.piece_jointeCreateManyInput[];
    skipDuplicates?: boolean;
};
export type piece_jointeCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    data: Prisma.piece_jointeCreateManyInput | Prisma.piece_jointeCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.piece_jointeIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type piece_jointeUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.piece_jointeUpdateInput, Prisma.piece_jointeUncheckedUpdateInput>;
    where: Prisma.piece_jointeWhereUniqueInput;
};
export type piece_jointeUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.piece_jointeUpdateManyMutationInput, Prisma.piece_jointeUncheckedUpdateManyInput>;
    where?: Prisma.piece_jointeWhereInput;
    limit?: number;
};
export type piece_jointeUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.piece_jointeUpdateManyMutationInput, Prisma.piece_jointeUncheckedUpdateManyInput>;
    where?: Prisma.piece_jointeWhereInput;
    limit?: number;
    include?: Prisma.piece_jointeIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type piece_jointeUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    where: Prisma.piece_jointeWhereUniqueInput;
    create: Prisma.XOR<Prisma.piece_jointeCreateInput, Prisma.piece_jointeUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.piece_jointeUpdateInput, Prisma.piece_jointeUncheckedUpdateInput>;
};
export type piece_jointeDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    where: Prisma.piece_jointeWhereUniqueInput;
};
export type piece_jointeDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.piece_jointeWhereInput;
    limit?: number;
};
export type piece_jointe$tacheArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.tacheSelect<ExtArgs> | null;
    omit?: Prisma.tacheOmit<ExtArgs> | null;
    include?: Prisma.tacheInclude<ExtArgs> | null;
    where?: Prisma.tacheWhereInput;
};
export type piece_jointe$commentaireArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    where?: Prisma.commentaireWhereInput;
};
export type piece_jointeDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
};
