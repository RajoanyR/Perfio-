import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type historique_tacheModel = runtime.Types.Result.DefaultSelection<Prisma.$historique_tachePayload>;
export type AggregateHistorique_tache = {
    _count: Historique_tacheCountAggregateOutputType | null;
    _avg: Historique_tacheAvgAggregateOutputType | null;
    _sum: Historique_tacheSumAggregateOutputType | null;
    _min: Historique_tacheMinAggregateOutputType | null;
    _max: Historique_tacheMaxAggregateOutputType | null;
};
export type Historique_tacheAvgAggregateOutputType = {
    id_historique: number | null;
    id_tache: number | null;
    id_utilisateur: number | null;
};
export type Historique_tacheSumAggregateOutputType = {
    id_historique: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
};
export type Historique_tacheMinAggregateOutputType = {
    id_historique: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
    action: string | null;
    description: string | null;
    date_action: Date | null;
};
export type Historique_tacheMaxAggregateOutputType = {
    id_historique: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
    action: string | null;
    description: string | null;
    date_action: Date | null;
};
export type Historique_tacheCountAggregateOutputType = {
    id_historique: number;
    id_tache: number;
    id_utilisateur: number;
    action: number;
    description: number;
    date_action: number;
    _all: number;
};
export type Historique_tacheAvgAggregateInputType = {
    id_historique?: true;
    id_tache?: true;
    id_utilisateur?: true;
};
export type Historique_tacheSumAggregateInputType = {
    id_historique?: true;
    id_tache?: true;
    id_utilisateur?: true;
};
export type Historique_tacheMinAggregateInputType = {
    id_historique?: true;
    id_tache?: true;
    id_utilisateur?: true;
    action?: true;
    description?: true;
    date_action?: true;
};
export type Historique_tacheMaxAggregateInputType = {
    id_historique?: true;
    id_tache?: true;
    id_utilisateur?: true;
    action?: true;
    description?: true;
    date_action?: true;
};
export type Historique_tacheCountAggregateInputType = {
    id_historique?: true;
    id_tache?: true;
    id_utilisateur?: true;
    action?: true;
    description?: true;
    date_action?: true;
    _all?: true;
};
export type Historique_tacheAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.historique_tacheWhereInput;
    orderBy?: Prisma.historique_tacheOrderByWithRelationInput | Prisma.historique_tacheOrderByWithRelationInput[];
    cursor?: Prisma.historique_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | Historique_tacheCountAggregateInputType;
    _avg?: Historique_tacheAvgAggregateInputType;
    _sum?: Historique_tacheSumAggregateInputType;
    _min?: Historique_tacheMinAggregateInputType;
    _max?: Historique_tacheMaxAggregateInputType;
};
export type GetHistorique_tacheAggregateType<T extends Historique_tacheAggregateArgs> = {
    [P in keyof T & keyof AggregateHistorique_tache]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateHistorique_tache[P]> : Prisma.GetScalarType<T[P], AggregateHistorique_tache[P]>;
};
export type historique_tacheGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.historique_tacheWhereInput;
    orderBy?: Prisma.historique_tacheOrderByWithAggregationInput | Prisma.historique_tacheOrderByWithAggregationInput[];
    by: Prisma.Historique_tacheScalarFieldEnum[] | Prisma.Historique_tacheScalarFieldEnum;
    having?: Prisma.historique_tacheScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: Historique_tacheCountAggregateInputType | true;
    _avg?: Historique_tacheAvgAggregateInputType;
    _sum?: Historique_tacheSumAggregateInputType;
    _min?: Historique_tacheMinAggregateInputType;
    _max?: Historique_tacheMaxAggregateInputType;
};
export type Historique_tacheGroupByOutputType = {
    id_historique: bigint;
    id_tache: bigint;
    id_utilisateur: bigint | null;
    action: string;
    description: string | null;
    date_action: Date;
    _count: Historique_tacheCountAggregateOutputType | null;
    _avg: Historique_tacheAvgAggregateOutputType | null;
    _sum: Historique_tacheSumAggregateOutputType | null;
    _min: Historique_tacheMinAggregateOutputType | null;
    _max: Historique_tacheMaxAggregateOutputType | null;
};
export type GetHistorique_tacheGroupByPayload<T extends historique_tacheGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<Historique_tacheGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof Historique_tacheGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], Historique_tacheGroupByOutputType[P]> : Prisma.GetScalarType<T[P], Historique_tacheGroupByOutputType[P]>;
}>>;
export type historique_tacheWhereInput = {
    AND?: Prisma.historique_tacheWhereInput | Prisma.historique_tacheWhereInput[];
    OR?: Prisma.historique_tacheWhereInput[];
    NOT?: Prisma.historique_tacheWhereInput | Prisma.historique_tacheWhereInput[];
    id_historique?: Prisma.BigIntFilter<"historique_tache"> | bigint | number;
    id_tache?: Prisma.BigIntFilter<"historique_tache"> | bigint | number;
    id_utilisateur?: Prisma.BigIntNullableFilter<"historique_tache"> | bigint | number | null;
    action?: Prisma.StringFilter<"historique_tache"> | string;
    description?: Prisma.StringNullableFilter<"historique_tache"> | string | null;
    date_action?: Prisma.DateTimeFilter<"historique_tache"> | Date | string;
    tache?: Prisma.XOR<Prisma.TacheScalarRelationFilter, Prisma.tacheWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurNullableScalarRelationFilter, Prisma.utilisateurWhereInput> | null;
};
export type historique_tacheOrderByWithRelationInput = {
    id_historique?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrderInput | Prisma.SortOrder;
    action?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    date_action?: Prisma.SortOrder;
    tache?: Prisma.tacheOrderByWithRelationInput;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
};
export type historique_tacheWhereUniqueInput = Prisma.AtLeast<{
    id_historique?: bigint | number;
    AND?: Prisma.historique_tacheWhereInput | Prisma.historique_tacheWhereInput[];
    OR?: Prisma.historique_tacheWhereInput[];
    NOT?: Prisma.historique_tacheWhereInput | Prisma.historique_tacheWhereInput[];
    id_tache?: Prisma.BigIntFilter<"historique_tache"> | bigint | number;
    id_utilisateur?: Prisma.BigIntNullableFilter<"historique_tache"> | bigint | number | null;
    action?: Prisma.StringFilter<"historique_tache"> | string;
    description?: Prisma.StringNullableFilter<"historique_tache"> | string | null;
    date_action?: Prisma.DateTimeFilter<"historique_tache"> | Date | string;
    tache?: Prisma.XOR<Prisma.TacheScalarRelationFilter, Prisma.tacheWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurNullableScalarRelationFilter, Prisma.utilisateurWhereInput> | null;
}, "id_historique">;
export type historique_tacheOrderByWithAggregationInput = {
    id_historique?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrderInput | Prisma.SortOrder;
    action?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    date_action?: Prisma.SortOrder;
    _count?: Prisma.historique_tacheCountOrderByAggregateInput;
    _avg?: Prisma.historique_tacheAvgOrderByAggregateInput;
    _max?: Prisma.historique_tacheMaxOrderByAggregateInput;
    _min?: Prisma.historique_tacheMinOrderByAggregateInput;
    _sum?: Prisma.historique_tacheSumOrderByAggregateInput;
};
export type historique_tacheScalarWhereWithAggregatesInput = {
    AND?: Prisma.historique_tacheScalarWhereWithAggregatesInput | Prisma.historique_tacheScalarWhereWithAggregatesInput[];
    OR?: Prisma.historique_tacheScalarWhereWithAggregatesInput[];
    NOT?: Prisma.historique_tacheScalarWhereWithAggregatesInput | Prisma.historique_tacheScalarWhereWithAggregatesInput[];
    id_historique?: Prisma.BigIntWithAggregatesFilter<"historique_tache"> | bigint | number;
    id_tache?: Prisma.BigIntWithAggregatesFilter<"historique_tache"> | bigint | number;
    id_utilisateur?: Prisma.BigIntNullableWithAggregatesFilter<"historique_tache"> | bigint | number | null;
    action?: Prisma.StringWithAggregatesFilter<"historique_tache"> | string;
    description?: Prisma.StringNullableWithAggregatesFilter<"historique_tache"> | string | null;
    date_action?: Prisma.DateTimeWithAggregatesFilter<"historique_tache"> | Date | string;
};
export type historique_tacheCreateInput = {
    id_historique?: bigint | number;
    action: string;
    description?: string | null;
    date_action?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutHistorique_tacheInput;
    utilisateur?: Prisma.utilisateurCreateNestedOneWithoutHistorique_tacheInput;
};
export type historique_tacheUncheckedCreateInput = {
    id_historique?: bigint | number;
    id_tache: bigint | number;
    id_utilisateur?: bigint | number | null;
    action: string;
    description?: string | null;
    date_action?: Date | string;
};
export type historique_tacheUpdateInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutHistorique_tacheNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneWithoutHistorique_tacheNestedInput;
};
export type historique_tacheUncheckedUpdateInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type historique_tacheCreateManyInput = {
    id_historique?: bigint | number;
    id_tache: bigint | number;
    id_utilisateur?: bigint | number | null;
    action: string;
    description?: string | null;
    date_action?: Date | string;
};
export type historique_tacheUpdateManyMutationInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type historique_tacheUncheckedUpdateManyInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type historique_tacheCountOrderByAggregateInput = {
    id_historique?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    action?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    date_action?: Prisma.SortOrder;
};
export type historique_tacheAvgOrderByAggregateInput = {
    id_historique?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type historique_tacheMaxOrderByAggregateInput = {
    id_historique?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    action?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    date_action?: Prisma.SortOrder;
};
export type historique_tacheMinOrderByAggregateInput = {
    id_historique?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    action?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    date_action?: Prisma.SortOrder;
};
export type historique_tacheSumOrderByAggregateInput = {
    id_historique?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type Historique_tacheListRelationFilter = {
    every?: Prisma.historique_tacheWhereInput;
    some?: Prisma.historique_tacheWhereInput;
    none?: Prisma.historique_tacheWhereInput;
};
export type historique_tacheOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type NullableBigIntFieldUpdateOperationsInput = {
    set?: bigint | number | null;
    increment?: bigint | number;
    decrement?: bigint | number;
    multiply?: bigint | number;
    divide?: bigint | number;
};
export type historique_tacheCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.historique_tacheCreateWithoutTacheInput, Prisma.historique_tacheUncheckedCreateWithoutTacheInput> | Prisma.historique_tacheCreateWithoutTacheInput[] | Prisma.historique_tacheUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.historique_tacheCreateOrConnectWithoutTacheInput | Prisma.historique_tacheCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.historique_tacheCreateManyTacheInputEnvelope;
    connect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
};
export type historique_tacheUncheckedCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.historique_tacheCreateWithoutTacheInput, Prisma.historique_tacheUncheckedCreateWithoutTacheInput> | Prisma.historique_tacheCreateWithoutTacheInput[] | Prisma.historique_tacheUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.historique_tacheCreateOrConnectWithoutTacheInput | Prisma.historique_tacheCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.historique_tacheCreateManyTacheInputEnvelope;
    connect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
};
export type historique_tacheUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.historique_tacheCreateWithoutTacheInput, Prisma.historique_tacheUncheckedCreateWithoutTacheInput> | Prisma.historique_tacheCreateWithoutTacheInput[] | Prisma.historique_tacheUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.historique_tacheCreateOrConnectWithoutTacheInput | Prisma.historique_tacheCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.historique_tacheUpsertWithWhereUniqueWithoutTacheInput | Prisma.historique_tacheUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.historique_tacheCreateManyTacheInputEnvelope;
    set?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    disconnect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    delete?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    connect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    update?: Prisma.historique_tacheUpdateWithWhereUniqueWithoutTacheInput | Prisma.historique_tacheUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.historique_tacheUpdateManyWithWhereWithoutTacheInput | Prisma.historique_tacheUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.historique_tacheScalarWhereInput | Prisma.historique_tacheScalarWhereInput[];
};
export type historique_tacheUncheckedUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.historique_tacheCreateWithoutTacheInput, Prisma.historique_tacheUncheckedCreateWithoutTacheInput> | Prisma.historique_tacheCreateWithoutTacheInput[] | Prisma.historique_tacheUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.historique_tacheCreateOrConnectWithoutTacheInput | Prisma.historique_tacheCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.historique_tacheUpsertWithWhereUniqueWithoutTacheInput | Prisma.historique_tacheUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.historique_tacheCreateManyTacheInputEnvelope;
    set?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    disconnect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    delete?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    connect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    update?: Prisma.historique_tacheUpdateWithWhereUniqueWithoutTacheInput | Prisma.historique_tacheUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.historique_tacheUpdateManyWithWhereWithoutTacheInput | Prisma.historique_tacheUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.historique_tacheScalarWhereInput | Prisma.historique_tacheScalarWhereInput[];
};
export type historique_tacheCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.historique_tacheCreateWithoutUtilisateurInput, Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput> | Prisma.historique_tacheCreateWithoutUtilisateurInput[] | Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.historique_tacheCreateOrConnectWithoutUtilisateurInput | Prisma.historique_tacheCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.historique_tacheCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
};
export type historique_tacheUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.historique_tacheCreateWithoutUtilisateurInput, Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput> | Prisma.historique_tacheCreateWithoutUtilisateurInput[] | Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.historique_tacheCreateOrConnectWithoutUtilisateurInput | Prisma.historique_tacheCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.historique_tacheCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
};
export type historique_tacheUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.historique_tacheCreateWithoutUtilisateurInput, Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput> | Prisma.historique_tacheCreateWithoutUtilisateurInput[] | Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.historique_tacheCreateOrConnectWithoutUtilisateurInput | Prisma.historique_tacheCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.historique_tacheUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.historique_tacheUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.historique_tacheCreateManyUtilisateurInputEnvelope;
    set?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    disconnect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    delete?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    connect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    update?: Prisma.historique_tacheUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.historique_tacheUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.historique_tacheUpdateManyWithWhereWithoutUtilisateurInput | Prisma.historique_tacheUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.historique_tacheScalarWhereInput | Prisma.historique_tacheScalarWhereInput[];
};
export type historique_tacheUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.historique_tacheCreateWithoutUtilisateurInput, Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput> | Prisma.historique_tacheCreateWithoutUtilisateurInput[] | Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.historique_tacheCreateOrConnectWithoutUtilisateurInput | Prisma.historique_tacheCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.historique_tacheUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.historique_tacheUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.historique_tacheCreateManyUtilisateurInputEnvelope;
    set?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    disconnect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    delete?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    connect?: Prisma.historique_tacheWhereUniqueInput | Prisma.historique_tacheWhereUniqueInput[];
    update?: Prisma.historique_tacheUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.historique_tacheUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.historique_tacheUpdateManyWithWhereWithoutUtilisateurInput | Prisma.historique_tacheUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.historique_tacheScalarWhereInput | Prisma.historique_tacheScalarWhereInput[];
};
export type historique_tacheCreateWithoutTacheInput = {
    id_historique?: bigint | number;
    action: string;
    description?: string | null;
    date_action?: Date | string;
    utilisateur?: Prisma.utilisateurCreateNestedOneWithoutHistorique_tacheInput;
};
export type historique_tacheUncheckedCreateWithoutTacheInput = {
    id_historique?: bigint | number;
    id_utilisateur?: bigint | number | null;
    action: string;
    description?: string | null;
    date_action?: Date | string;
};
export type historique_tacheCreateOrConnectWithoutTacheInput = {
    where: Prisma.historique_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.historique_tacheCreateWithoutTacheInput, Prisma.historique_tacheUncheckedCreateWithoutTacheInput>;
};
export type historique_tacheCreateManyTacheInputEnvelope = {
    data: Prisma.historique_tacheCreateManyTacheInput | Prisma.historique_tacheCreateManyTacheInput[];
    skipDuplicates?: boolean;
};
export type historique_tacheUpsertWithWhereUniqueWithoutTacheInput = {
    where: Prisma.historique_tacheWhereUniqueInput;
    update: Prisma.XOR<Prisma.historique_tacheUpdateWithoutTacheInput, Prisma.historique_tacheUncheckedUpdateWithoutTacheInput>;
    create: Prisma.XOR<Prisma.historique_tacheCreateWithoutTacheInput, Prisma.historique_tacheUncheckedCreateWithoutTacheInput>;
};
export type historique_tacheUpdateWithWhereUniqueWithoutTacheInput = {
    where: Prisma.historique_tacheWhereUniqueInput;
    data: Prisma.XOR<Prisma.historique_tacheUpdateWithoutTacheInput, Prisma.historique_tacheUncheckedUpdateWithoutTacheInput>;
};
export type historique_tacheUpdateManyWithWhereWithoutTacheInput = {
    where: Prisma.historique_tacheScalarWhereInput;
    data: Prisma.XOR<Prisma.historique_tacheUpdateManyMutationInput, Prisma.historique_tacheUncheckedUpdateManyWithoutTacheInput>;
};
export type historique_tacheScalarWhereInput = {
    AND?: Prisma.historique_tacheScalarWhereInput | Prisma.historique_tacheScalarWhereInput[];
    OR?: Prisma.historique_tacheScalarWhereInput[];
    NOT?: Prisma.historique_tacheScalarWhereInput | Prisma.historique_tacheScalarWhereInput[];
    id_historique?: Prisma.BigIntFilter<"historique_tache"> | bigint | number;
    id_tache?: Prisma.BigIntFilter<"historique_tache"> | bigint | number;
    id_utilisateur?: Prisma.BigIntNullableFilter<"historique_tache"> | bigint | number | null;
    action?: Prisma.StringFilter<"historique_tache"> | string;
    description?: Prisma.StringNullableFilter<"historique_tache"> | string | null;
    date_action?: Prisma.DateTimeFilter<"historique_tache"> | Date | string;
};
export type historique_tacheCreateWithoutUtilisateurInput = {
    id_historique?: bigint | number;
    action: string;
    description?: string | null;
    date_action?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutHistorique_tacheInput;
};
export type historique_tacheUncheckedCreateWithoutUtilisateurInput = {
    id_historique?: bigint | number;
    id_tache: bigint | number;
    action: string;
    description?: string | null;
    date_action?: Date | string;
};
export type historique_tacheCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.historique_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.historique_tacheCreateWithoutUtilisateurInput, Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput>;
};
export type historique_tacheCreateManyUtilisateurInputEnvelope = {
    data: Prisma.historique_tacheCreateManyUtilisateurInput | Prisma.historique_tacheCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type historique_tacheUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.historique_tacheWhereUniqueInput;
    update: Prisma.XOR<Prisma.historique_tacheUpdateWithoutUtilisateurInput, Prisma.historique_tacheUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.historique_tacheCreateWithoutUtilisateurInput, Prisma.historique_tacheUncheckedCreateWithoutUtilisateurInput>;
};
export type historique_tacheUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.historique_tacheWhereUniqueInput;
    data: Prisma.XOR<Prisma.historique_tacheUpdateWithoutUtilisateurInput, Prisma.historique_tacheUncheckedUpdateWithoutUtilisateurInput>;
};
export type historique_tacheUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.historique_tacheScalarWhereInput;
    data: Prisma.XOR<Prisma.historique_tacheUpdateManyMutationInput, Prisma.historique_tacheUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type historique_tacheCreateManyTacheInput = {
    id_historique?: bigint | number;
    id_utilisateur?: bigint | number | null;
    action: string;
    description?: string | null;
    date_action?: Date | string;
};
export type historique_tacheUpdateWithoutTacheInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    utilisateur?: Prisma.utilisateurUpdateOneWithoutHistorique_tacheNestedInput;
};
export type historique_tacheUncheckedUpdateWithoutTacheInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type historique_tacheUncheckedUpdateManyWithoutTacheInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.NullableBigIntFieldUpdateOperationsInput | bigint | number | null;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type historique_tacheCreateManyUtilisateurInput = {
    id_historique?: bigint | number;
    id_tache: bigint | number;
    action: string;
    description?: string | null;
    date_action?: Date | string;
};
export type historique_tacheUpdateWithoutUtilisateurInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutHistorique_tacheNestedInput;
};
export type historique_tacheUncheckedUpdateWithoutUtilisateurInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type historique_tacheUncheckedUpdateManyWithoutUtilisateurInput = {
    id_historique?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    action?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_action?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type historique_tacheSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_historique?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    action?: boolean;
    description?: boolean;
    date_action?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.historique_tache$utilisateurArgs<ExtArgs>;
}, ExtArgs["result"]["historique_tache"]>;
export type historique_tacheSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_historique?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    action?: boolean;
    description?: boolean;
    date_action?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.historique_tache$utilisateurArgs<ExtArgs>;
}, ExtArgs["result"]["historique_tache"]>;
export type historique_tacheSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_historique?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    action?: boolean;
    description?: boolean;
    date_action?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.historique_tache$utilisateurArgs<ExtArgs>;
}, ExtArgs["result"]["historique_tache"]>;
export type historique_tacheSelectScalar = {
    id_historique?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    action?: boolean;
    description?: boolean;
    date_action?: boolean;
};
export type historique_tacheOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_historique" | "id_tache" | "id_utilisateur" | "action" | "description" | "date_action", ExtArgs["result"]["historique_tache"]>;
export type historique_tacheInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.historique_tache$utilisateurArgs<ExtArgs>;
};
export type historique_tacheIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.historique_tache$utilisateurArgs<ExtArgs>;
};
export type historique_tacheIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.historique_tache$utilisateurArgs<ExtArgs>;
};
export type $historique_tachePayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "historique_tache";
    objects: {
        tache: Prisma.$tachePayload<ExtArgs>;
        utilisateur: Prisma.$utilisateurPayload<ExtArgs> | null;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_historique: bigint;
        id_tache: bigint;
        id_utilisateur: bigint | null;
        action: string;
        description: string | null;
        date_action: Date;
    }, ExtArgs["result"]["historique_tache"]>;
    composites: {};
};
export type historique_tacheGetPayload<S extends boolean | null | undefined | historique_tacheDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$historique_tachePayload, S>;
export type historique_tacheCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<historique_tacheFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: Historique_tacheCountAggregateInputType | true;
};
export interface historique_tacheDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['historique_tache'];
        meta: {
            name: 'historique_tache';
        };
    };
    findUnique<T extends historique_tacheFindUniqueArgs>(args: Prisma.SelectSubset<T, historique_tacheFindUniqueArgs<ExtArgs>>): Prisma.Prisma__historique_tacheClient<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends historique_tacheFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, historique_tacheFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__historique_tacheClient<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends historique_tacheFindFirstArgs>(args?: Prisma.SelectSubset<T, historique_tacheFindFirstArgs<ExtArgs>>): Prisma.Prisma__historique_tacheClient<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends historique_tacheFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, historique_tacheFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__historique_tacheClient<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends historique_tacheFindManyArgs>(args?: Prisma.SelectSubset<T, historique_tacheFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends historique_tacheCreateArgs>(args: Prisma.SelectSubset<T, historique_tacheCreateArgs<ExtArgs>>): Prisma.Prisma__historique_tacheClient<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends historique_tacheCreateManyArgs>(args?: Prisma.SelectSubset<T, historique_tacheCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends historique_tacheCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, historique_tacheCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends historique_tacheDeleteArgs>(args: Prisma.SelectSubset<T, historique_tacheDeleteArgs<ExtArgs>>): Prisma.Prisma__historique_tacheClient<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends historique_tacheUpdateArgs>(args: Prisma.SelectSubset<T, historique_tacheUpdateArgs<ExtArgs>>): Prisma.Prisma__historique_tacheClient<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends historique_tacheDeleteManyArgs>(args?: Prisma.SelectSubset<T, historique_tacheDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends historique_tacheUpdateManyArgs>(args: Prisma.SelectSubset<T, historique_tacheUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends historique_tacheUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, historique_tacheUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends historique_tacheUpsertArgs>(args: Prisma.SelectSubset<T, historique_tacheUpsertArgs<ExtArgs>>): Prisma.Prisma__historique_tacheClient<runtime.Types.Result.GetResult<Prisma.$historique_tachePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends historique_tacheCountArgs>(args?: Prisma.Subset<T, historique_tacheCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], Historique_tacheCountAggregateOutputType> : number>;
    aggregate<T extends Historique_tacheAggregateArgs>(args: Prisma.Subset<T, Historique_tacheAggregateArgs>): Prisma.PrismaPromise<GetHistorique_tacheAggregateType<T>>;
    groupBy<T extends historique_tacheGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: historique_tacheGroupByArgs['orderBy'];
    } : {
        orderBy?: historique_tacheGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, historique_tacheGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetHistorique_tacheGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: historique_tacheFieldRefs;
}
export interface Prisma__historique_tacheClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    tache<T extends Prisma.tacheDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.tacheDefaultArgs<ExtArgs>>): Prisma.Prisma__tacheClient<runtime.Types.Result.GetResult<Prisma.$tachePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    utilisateur<T extends Prisma.historique_tache$utilisateurArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.historique_tache$utilisateurArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface historique_tacheFieldRefs {
    readonly id_historique: Prisma.FieldRef<"historique_tache", 'BigInt'>;
    readonly id_tache: Prisma.FieldRef<"historique_tache", 'BigInt'>;
    readonly id_utilisateur: Prisma.FieldRef<"historique_tache", 'BigInt'>;
    readonly action: Prisma.FieldRef<"historique_tache", 'String'>;
    readonly description: Prisma.FieldRef<"historique_tache", 'String'>;
    readonly date_action: Prisma.FieldRef<"historique_tache", 'DateTime'>;
}
export type historique_tacheFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    where: Prisma.historique_tacheWhereUniqueInput;
};
export type historique_tacheFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    where: Prisma.historique_tacheWhereUniqueInput;
};
export type historique_tacheFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    where?: Prisma.historique_tacheWhereInput;
    orderBy?: Prisma.historique_tacheOrderByWithRelationInput | Prisma.historique_tacheOrderByWithRelationInput[];
    cursor?: Prisma.historique_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Historique_tacheScalarFieldEnum | Prisma.Historique_tacheScalarFieldEnum[];
};
export type historique_tacheFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    where?: Prisma.historique_tacheWhereInput;
    orderBy?: Prisma.historique_tacheOrderByWithRelationInput | Prisma.historique_tacheOrderByWithRelationInput[];
    cursor?: Prisma.historique_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Historique_tacheScalarFieldEnum | Prisma.Historique_tacheScalarFieldEnum[];
};
export type historique_tacheFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    where?: Prisma.historique_tacheWhereInput;
    orderBy?: Prisma.historique_tacheOrderByWithRelationInput | Prisma.historique_tacheOrderByWithRelationInput[];
    cursor?: Prisma.historique_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Historique_tacheScalarFieldEnum | Prisma.Historique_tacheScalarFieldEnum[];
};
export type historique_tacheCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.historique_tacheCreateInput, Prisma.historique_tacheUncheckedCreateInput>;
};
export type historique_tacheCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.historique_tacheCreateManyInput | Prisma.historique_tacheCreateManyInput[];
    skipDuplicates?: boolean;
};
export type historique_tacheCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    data: Prisma.historique_tacheCreateManyInput | Prisma.historique_tacheCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.historique_tacheIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type historique_tacheUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.historique_tacheUpdateInput, Prisma.historique_tacheUncheckedUpdateInput>;
    where: Prisma.historique_tacheWhereUniqueInput;
};
export type historique_tacheUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.historique_tacheUpdateManyMutationInput, Prisma.historique_tacheUncheckedUpdateManyInput>;
    where?: Prisma.historique_tacheWhereInput;
    limit?: number;
};
export type historique_tacheUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.historique_tacheUpdateManyMutationInput, Prisma.historique_tacheUncheckedUpdateManyInput>;
    where?: Prisma.historique_tacheWhereInput;
    limit?: number;
    include?: Prisma.historique_tacheIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type historique_tacheUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    where: Prisma.historique_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.historique_tacheCreateInput, Prisma.historique_tacheUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.historique_tacheUpdateInput, Prisma.historique_tacheUncheckedUpdateInput>;
};
export type historique_tacheDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
    where: Prisma.historique_tacheWhereUniqueInput;
};
export type historique_tacheDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.historique_tacheWhereInput;
    limit?: number;
};
export type historique_tache$utilisateurArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.utilisateurSelect<ExtArgs> | null;
    omit?: Prisma.utilisateurOmit<ExtArgs> | null;
    include?: Prisma.utilisateurInclude<ExtArgs> | null;
    where?: Prisma.utilisateurWhereInput;
};
export type historique_tacheDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.historique_tacheSelect<ExtArgs> | null;
    omit?: Prisma.historique_tacheOmit<ExtArgs> | null;
    include?: Prisma.historique_tacheInclude<ExtArgs> | null;
};
