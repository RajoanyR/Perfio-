import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type rapportModel = runtime.Types.Result.DefaultSelection<Prisma.$rapportPayload>;
export type AggregateRapport = {
    _count: RapportCountAggregateOutputType | null;
    _avg: RapportAvgAggregateOutputType | null;
    _sum: RapportSumAggregateOutputType | null;
    _min: RapportMinAggregateOutputType | null;
    _max: RapportMaxAggregateOutputType | null;
};
export type RapportAvgAggregateOutputType = {
    id_rapport: number | null;
    id_utilisateur: number | null;
};
export type RapportSumAggregateOutputType = {
    id_rapport: bigint | null;
    id_utilisateur: bigint | null;
};
export type RapportMinAggregateOutputType = {
    id_rapport: bigint | null;
    id_utilisateur: bigint | null;
    type: string | null;
    format: string | null;
    periode_debut: Date | null;
    periode_fin: Date | null;
    chemin_fichier: string | null;
    date_generation: Date | null;
};
export type RapportMaxAggregateOutputType = {
    id_rapport: bigint | null;
    id_utilisateur: bigint | null;
    type: string | null;
    format: string | null;
    periode_debut: Date | null;
    periode_fin: Date | null;
    chemin_fichier: string | null;
    date_generation: Date | null;
};
export type RapportCountAggregateOutputType = {
    id_rapport: number;
    id_utilisateur: number;
    type: number;
    format: number;
    periode_debut: number;
    periode_fin: number;
    chemin_fichier: number;
    date_generation: number;
    _all: number;
};
export type RapportAvgAggregateInputType = {
    id_rapport?: true;
    id_utilisateur?: true;
};
export type RapportSumAggregateInputType = {
    id_rapport?: true;
    id_utilisateur?: true;
};
export type RapportMinAggregateInputType = {
    id_rapport?: true;
    id_utilisateur?: true;
    type?: true;
    format?: true;
    periode_debut?: true;
    periode_fin?: true;
    chemin_fichier?: true;
    date_generation?: true;
};
export type RapportMaxAggregateInputType = {
    id_rapport?: true;
    id_utilisateur?: true;
    type?: true;
    format?: true;
    periode_debut?: true;
    periode_fin?: true;
    chemin_fichier?: true;
    date_generation?: true;
};
export type RapportCountAggregateInputType = {
    id_rapport?: true;
    id_utilisateur?: true;
    type?: true;
    format?: true;
    periode_debut?: true;
    periode_fin?: true;
    chemin_fichier?: true;
    date_generation?: true;
    _all?: true;
};
export type RapportAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.rapportWhereInput;
    orderBy?: Prisma.rapportOrderByWithRelationInput | Prisma.rapportOrderByWithRelationInput[];
    cursor?: Prisma.rapportWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | RapportCountAggregateInputType;
    _avg?: RapportAvgAggregateInputType;
    _sum?: RapportSumAggregateInputType;
    _min?: RapportMinAggregateInputType;
    _max?: RapportMaxAggregateInputType;
};
export type GetRapportAggregateType<T extends RapportAggregateArgs> = {
    [P in keyof T & keyof AggregateRapport]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateRapport[P]> : Prisma.GetScalarType<T[P], AggregateRapport[P]>;
};
export type rapportGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.rapportWhereInput;
    orderBy?: Prisma.rapportOrderByWithAggregationInput | Prisma.rapportOrderByWithAggregationInput[];
    by: Prisma.RapportScalarFieldEnum[] | Prisma.RapportScalarFieldEnum;
    having?: Prisma.rapportScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: RapportCountAggregateInputType | true;
    _avg?: RapportAvgAggregateInputType;
    _sum?: RapportSumAggregateInputType;
    _min?: RapportMinAggregateInputType;
    _max?: RapportMaxAggregateInputType;
};
export type RapportGroupByOutputType = {
    id_rapport: bigint;
    id_utilisateur: bigint;
    type: string;
    format: string;
    periode_debut: Date | null;
    periode_fin: Date | null;
    chemin_fichier: string | null;
    date_generation: Date;
    _count: RapportCountAggregateOutputType | null;
    _avg: RapportAvgAggregateOutputType | null;
    _sum: RapportSumAggregateOutputType | null;
    _min: RapportMinAggregateOutputType | null;
    _max: RapportMaxAggregateOutputType | null;
};
export type GetRapportGroupByPayload<T extends rapportGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<RapportGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof RapportGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], RapportGroupByOutputType[P]> : Prisma.GetScalarType<T[P], RapportGroupByOutputType[P]>;
}>>;
export type rapportWhereInput = {
    AND?: Prisma.rapportWhereInput | Prisma.rapportWhereInput[];
    OR?: Prisma.rapportWhereInput[];
    NOT?: Prisma.rapportWhereInput | Prisma.rapportWhereInput[];
    id_rapport?: Prisma.BigIntFilter<"rapport"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"rapport"> | bigint | number;
    type?: Prisma.StringFilter<"rapport"> | string;
    format?: Prisma.StringFilter<"rapport"> | string;
    periode_debut?: Prisma.DateTimeNullableFilter<"rapport"> | Date | string | null;
    periode_fin?: Prisma.DateTimeNullableFilter<"rapport"> | Date | string | null;
    chemin_fichier?: Prisma.StringNullableFilter<"rapport"> | string | null;
    date_generation?: Prisma.DateTimeFilter<"rapport"> | Date | string;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
};
export type rapportOrderByWithRelationInput = {
    id_rapport?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    format?: Prisma.SortOrder;
    periode_debut?: Prisma.SortOrderInput | Prisma.SortOrder;
    periode_fin?: Prisma.SortOrderInput | Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrderInput | Prisma.SortOrder;
    date_generation?: Prisma.SortOrder;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
};
export type rapportWhereUniqueInput = Prisma.AtLeast<{
    id_rapport?: bigint | number;
    AND?: Prisma.rapportWhereInput | Prisma.rapportWhereInput[];
    OR?: Prisma.rapportWhereInput[];
    NOT?: Prisma.rapportWhereInput | Prisma.rapportWhereInput[];
    id_utilisateur?: Prisma.BigIntFilter<"rapport"> | bigint | number;
    type?: Prisma.StringFilter<"rapport"> | string;
    format?: Prisma.StringFilter<"rapport"> | string;
    periode_debut?: Prisma.DateTimeNullableFilter<"rapport"> | Date | string | null;
    periode_fin?: Prisma.DateTimeNullableFilter<"rapport"> | Date | string | null;
    chemin_fichier?: Prisma.StringNullableFilter<"rapport"> | string | null;
    date_generation?: Prisma.DateTimeFilter<"rapport"> | Date | string;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
}, "id_rapport">;
export type rapportOrderByWithAggregationInput = {
    id_rapport?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    format?: Prisma.SortOrder;
    periode_debut?: Prisma.SortOrderInput | Prisma.SortOrder;
    periode_fin?: Prisma.SortOrderInput | Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrderInput | Prisma.SortOrder;
    date_generation?: Prisma.SortOrder;
    _count?: Prisma.rapportCountOrderByAggregateInput;
    _avg?: Prisma.rapportAvgOrderByAggregateInput;
    _max?: Prisma.rapportMaxOrderByAggregateInput;
    _min?: Prisma.rapportMinOrderByAggregateInput;
    _sum?: Prisma.rapportSumOrderByAggregateInput;
};
export type rapportScalarWhereWithAggregatesInput = {
    AND?: Prisma.rapportScalarWhereWithAggregatesInput | Prisma.rapportScalarWhereWithAggregatesInput[];
    OR?: Prisma.rapportScalarWhereWithAggregatesInput[];
    NOT?: Prisma.rapportScalarWhereWithAggregatesInput | Prisma.rapportScalarWhereWithAggregatesInput[];
    id_rapport?: Prisma.BigIntWithAggregatesFilter<"rapport"> | bigint | number;
    id_utilisateur?: Prisma.BigIntWithAggregatesFilter<"rapport"> | bigint | number;
    type?: Prisma.StringWithAggregatesFilter<"rapport"> | string;
    format?: Prisma.StringWithAggregatesFilter<"rapport"> | string;
    periode_debut?: Prisma.DateTimeNullableWithAggregatesFilter<"rapport"> | Date | string | null;
    periode_fin?: Prisma.DateTimeNullableWithAggregatesFilter<"rapport"> | Date | string | null;
    chemin_fichier?: Prisma.StringNullableWithAggregatesFilter<"rapport"> | string | null;
    date_generation?: Prisma.DateTimeWithAggregatesFilter<"rapport"> | Date | string;
};
export type rapportCreateInput = {
    id_rapport?: bigint | number;
    type: string;
    format: string;
    periode_debut?: Date | string | null;
    periode_fin?: Date | string | null;
    chemin_fichier?: string | null;
    date_generation?: Date | string;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutRapportInput;
};
export type rapportUncheckedCreateInput = {
    id_rapport?: bigint | number;
    id_utilisateur: bigint | number;
    type: string;
    format: string;
    periode_debut?: Date | string | null;
    periode_fin?: Date | string | null;
    chemin_fichier?: string | null;
    date_generation?: Date | string;
};
export type rapportUpdateInput = {
    id_rapport?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    format?: Prisma.StringFieldUpdateOperationsInput | string;
    periode_debut?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    periode_fin?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    chemin_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_generation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutRapportNestedInput;
};
export type rapportUncheckedUpdateInput = {
    id_rapport?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    format?: Prisma.StringFieldUpdateOperationsInput | string;
    periode_debut?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    periode_fin?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    chemin_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_generation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type rapportCreateManyInput = {
    id_rapport?: bigint | number;
    id_utilisateur: bigint | number;
    type: string;
    format: string;
    periode_debut?: Date | string | null;
    periode_fin?: Date | string | null;
    chemin_fichier?: string | null;
    date_generation?: Date | string;
};
export type rapportUpdateManyMutationInput = {
    id_rapport?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    format?: Prisma.StringFieldUpdateOperationsInput | string;
    periode_debut?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    periode_fin?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    chemin_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_generation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type rapportUncheckedUpdateManyInput = {
    id_rapport?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    format?: Prisma.StringFieldUpdateOperationsInput | string;
    periode_debut?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    periode_fin?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    chemin_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_generation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type rapportCountOrderByAggregateInput = {
    id_rapport?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    format?: Prisma.SortOrder;
    periode_debut?: Prisma.SortOrder;
    periode_fin?: Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrder;
    date_generation?: Prisma.SortOrder;
};
export type rapportAvgOrderByAggregateInput = {
    id_rapport?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type rapportMaxOrderByAggregateInput = {
    id_rapport?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    format?: Prisma.SortOrder;
    periode_debut?: Prisma.SortOrder;
    periode_fin?: Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrder;
    date_generation?: Prisma.SortOrder;
};
export type rapportMinOrderByAggregateInput = {
    id_rapport?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    format?: Prisma.SortOrder;
    periode_debut?: Prisma.SortOrder;
    periode_fin?: Prisma.SortOrder;
    chemin_fichier?: Prisma.SortOrder;
    date_generation?: Prisma.SortOrder;
};
export type rapportSumOrderByAggregateInput = {
    id_rapport?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type RapportListRelationFilter = {
    every?: Prisma.rapportWhereInput;
    some?: Prisma.rapportWhereInput;
    none?: Prisma.rapportWhereInput;
};
export type rapportOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type rapportCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.rapportCreateWithoutUtilisateurInput, Prisma.rapportUncheckedCreateWithoutUtilisateurInput> | Prisma.rapportCreateWithoutUtilisateurInput[] | Prisma.rapportUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.rapportCreateOrConnectWithoutUtilisateurInput | Prisma.rapportCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.rapportCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
};
export type rapportUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.rapportCreateWithoutUtilisateurInput, Prisma.rapportUncheckedCreateWithoutUtilisateurInput> | Prisma.rapportCreateWithoutUtilisateurInput[] | Prisma.rapportUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.rapportCreateOrConnectWithoutUtilisateurInput | Prisma.rapportCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.rapportCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
};
export type rapportUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.rapportCreateWithoutUtilisateurInput, Prisma.rapportUncheckedCreateWithoutUtilisateurInput> | Prisma.rapportCreateWithoutUtilisateurInput[] | Prisma.rapportUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.rapportCreateOrConnectWithoutUtilisateurInput | Prisma.rapportCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.rapportUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.rapportUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.rapportCreateManyUtilisateurInputEnvelope;
    set?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
    disconnect?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
    delete?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
    connect?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
    update?: Prisma.rapportUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.rapportUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.rapportUpdateManyWithWhereWithoutUtilisateurInput | Prisma.rapportUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.rapportScalarWhereInput | Prisma.rapportScalarWhereInput[];
};
export type rapportUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.rapportCreateWithoutUtilisateurInput, Prisma.rapportUncheckedCreateWithoutUtilisateurInput> | Prisma.rapportCreateWithoutUtilisateurInput[] | Prisma.rapportUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.rapportCreateOrConnectWithoutUtilisateurInput | Prisma.rapportCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.rapportUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.rapportUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.rapportCreateManyUtilisateurInputEnvelope;
    set?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
    disconnect?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
    delete?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
    connect?: Prisma.rapportWhereUniqueInput | Prisma.rapportWhereUniqueInput[];
    update?: Prisma.rapportUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.rapportUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.rapportUpdateManyWithWhereWithoutUtilisateurInput | Prisma.rapportUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.rapportScalarWhereInput | Prisma.rapportScalarWhereInput[];
};
export type rapportCreateWithoutUtilisateurInput = {
    id_rapport?: bigint | number;
    type: string;
    format: string;
    periode_debut?: Date | string | null;
    periode_fin?: Date | string | null;
    chemin_fichier?: string | null;
    date_generation?: Date | string;
};
export type rapportUncheckedCreateWithoutUtilisateurInput = {
    id_rapport?: bigint | number;
    type: string;
    format: string;
    periode_debut?: Date | string | null;
    periode_fin?: Date | string | null;
    chemin_fichier?: string | null;
    date_generation?: Date | string;
};
export type rapportCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.rapportWhereUniqueInput;
    create: Prisma.XOR<Prisma.rapportCreateWithoutUtilisateurInput, Prisma.rapportUncheckedCreateWithoutUtilisateurInput>;
};
export type rapportCreateManyUtilisateurInputEnvelope = {
    data: Prisma.rapportCreateManyUtilisateurInput | Prisma.rapportCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type rapportUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.rapportWhereUniqueInput;
    update: Prisma.XOR<Prisma.rapportUpdateWithoutUtilisateurInput, Prisma.rapportUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.rapportCreateWithoutUtilisateurInput, Prisma.rapportUncheckedCreateWithoutUtilisateurInput>;
};
export type rapportUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.rapportWhereUniqueInput;
    data: Prisma.XOR<Prisma.rapportUpdateWithoutUtilisateurInput, Prisma.rapportUncheckedUpdateWithoutUtilisateurInput>;
};
export type rapportUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.rapportScalarWhereInput;
    data: Prisma.XOR<Prisma.rapportUpdateManyMutationInput, Prisma.rapportUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type rapportScalarWhereInput = {
    AND?: Prisma.rapportScalarWhereInput | Prisma.rapportScalarWhereInput[];
    OR?: Prisma.rapportScalarWhereInput[];
    NOT?: Prisma.rapportScalarWhereInput | Prisma.rapportScalarWhereInput[];
    id_rapport?: Prisma.BigIntFilter<"rapport"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"rapport"> | bigint | number;
    type?: Prisma.StringFilter<"rapport"> | string;
    format?: Prisma.StringFilter<"rapport"> | string;
    periode_debut?: Prisma.DateTimeNullableFilter<"rapport"> | Date | string | null;
    periode_fin?: Prisma.DateTimeNullableFilter<"rapport"> | Date | string | null;
    chemin_fichier?: Prisma.StringNullableFilter<"rapport"> | string | null;
    date_generation?: Prisma.DateTimeFilter<"rapport"> | Date | string;
};
export type rapportCreateManyUtilisateurInput = {
    id_rapport?: bigint | number;
    type: string;
    format: string;
    periode_debut?: Date | string | null;
    periode_fin?: Date | string | null;
    chemin_fichier?: string | null;
    date_generation?: Date | string;
};
export type rapportUpdateWithoutUtilisateurInput = {
    id_rapport?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    format?: Prisma.StringFieldUpdateOperationsInput | string;
    periode_debut?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    periode_fin?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    chemin_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_generation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type rapportUncheckedUpdateWithoutUtilisateurInput = {
    id_rapport?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    format?: Prisma.StringFieldUpdateOperationsInput | string;
    periode_debut?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    periode_fin?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    chemin_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_generation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type rapportUncheckedUpdateManyWithoutUtilisateurInput = {
    id_rapport?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    format?: Prisma.StringFieldUpdateOperationsInput | string;
    periode_debut?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    periode_fin?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    chemin_fichier?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_generation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type rapportSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_rapport?: boolean;
    id_utilisateur?: boolean;
    type?: boolean;
    format?: boolean;
    periode_debut?: boolean;
    periode_fin?: boolean;
    chemin_fichier?: boolean;
    date_generation?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["rapport"]>;
export type rapportSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_rapport?: boolean;
    id_utilisateur?: boolean;
    type?: boolean;
    format?: boolean;
    periode_debut?: boolean;
    periode_fin?: boolean;
    chemin_fichier?: boolean;
    date_generation?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["rapport"]>;
export type rapportSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_rapport?: boolean;
    id_utilisateur?: boolean;
    type?: boolean;
    format?: boolean;
    periode_debut?: boolean;
    periode_fin?: boolean;
    chemin_fichier?: boolean;
    date_generation?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["rapport"]>;
export type rapportSelectScalar = {
    id_rapport?: boolean;
    id_utilisateur?: boolean;
    type?: boolean;
    format?: boolean;
    periode_debut?: boolean;
    periode_fin?: boolean;
    chemin_fichier?: boolean;
    date_generation?: boolean;
};
export type rapportOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_rapport" | "id_utilisateur" | "type" | "format" | "periode_debut" | "periode_fin" | "chemin_fichier" | "date_generation", ExtArgs["result"]["rapport"]>;
export type rapportInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type rapportIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type rapportIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $rapportPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "rapport";
    objects: {
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_rapport: bigint;
        id_utilisateur: bigint;
        type: string;
        format: string;
        periode_debut: Date | null;
        periode_fin: Date | null;
        chemin_fichier: string | null;
        date_generation: Date;
    }, ExtArgs["result"]["rapport"]>;
    composites: {};
};
export type rapportGetPayload<S extends boolean | null | undefined | rapportDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$rapportPayload, S>;
export type rapportCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<rapportFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: RapportCountAggregateInputType | true;
};
export interface rapportDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['rapport'];
        meta: {
            name: 'rapport';
        };
    };
    findUnique<T extends rapportFindUniqueArgs>(args: Prisma.SelectSubset<T, rapportFindUniqueArgs<ExtArgs>>): Prisma.Prisma__rapportClient<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends rapportFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, rapportFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__rapportClient<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends rapportFindFirstArgs>(args?: Prisma.SelectSubset<T, rapportFindFirstArgs<ExtArgs>>): Prisma.Prisma__rapportClient<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends rapportFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, rapportFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__rapportClient<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends rapportFindManyArgs>(args?: Prisma.SelectSubset<T, rapportFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends rapportCreateArgs>(args: Prisma.SelectSubset<T, rapportCreateArgs<ExtArgs>>): Prisma.Prisma__rapportClient<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends rapportCreateManyArgs>(args?: Prisma.SelectSubset<T, rapportCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends rapportCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, rapportCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends rapportDeleteArgs>(args: Prisma.SelectSubset<T, rapportDeleteArgs<ExtArgs>>): Prisma.Prisma__rapportClient<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends rapportUpdateArgs>(args: Prisma.SelectSubset<T, rapportUpdateArgs<ExtArgs>>): Prisma.Prisma__rapportClient<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends rapportDeleteManyArgs>(args?: Prisma.SelectSubset<T, rapportDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends rapportUpdateManyArgs>(args: Prisma.SelectSubset<T, rapportUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends rapportUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, rapportUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends rapportUpsertArgs>(args: Prisma.SelectSubset<T, rapportUpsertArgs<ExtArgs>>): Prisma.Prisma__rapportClient<runtime.Types.Result.GetResult<Prisma.$rapportPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends rapportCountArgs>(args?: Prisma.Subset<T, rapportCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], RapportCountAggregateOutputType> : number>;
    aggregate<T extends RapportAggregateArgs>(args: Prisma.Subset<T, RapportAggregateArgs>): Prisma.PrismaPromise<GetRapportAggregateType<T>>;
    groupBy<T extends rapportGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: rapportGroupByArgs['orderBy'];
    } : {
        orderBy?: rapportGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, rapportGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetRapportGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: rapportFieldRefs;
}
export interface Prisma__rapportClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    utilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface rapportFieldRefs {
    readonly id_rapport: Prisma.FieldRef<"rapport", 'BigInt'>;
    readonly id_utilisateur: Prisma.FieldRef<"rapport", 'BigInt'>;
    readonly type: Prisma.FieldRef<"rapport", 'String'>;
    readonly format: Prisma.FieldRef<"rapport", 'String'>;
    readonly periode_debut: Prisma.FieldRef<"rapport", 'DateTime'>;
    readonly periode_fin: Prisma.FieldRef<"rapport", 'DateTime'>;
    readonly chemin_fichier: Prisma.FieldRef<"rapport", 'String'>;
    readonly date_generation: Prisma.FieldRef<"rapport", 'DateTime'>;
}
export type rapportFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    where: Prisma.rapportWhereUniqueInput;
};
export type rapportFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    where: Prisma.rapportWhereUniqueInput;
};
export type rapportFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    where?: Prisma.rapportWhereInput;
    orderBy?: Prisma.rapportOrderByWithRelationInput | Prisma.rapportOrderByWithRelationInput[];
    cursor?: Prisma.rapportWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.RapportScalarFieldEnum | Prisma.RapportScalarFieldEnum[];
};
export type rapportFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    where?: Prisma.rapportWhereInput;
    orderBy?: Prisma.rapportOrderByWithRelationInput | Prisma.rapportOrderByWithRelationInput[];
    cursor?: Prisma.rapportWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.RapportScalarFieldEnum | Prisma.RapportScalarFieldEnum[];
};
export type rapportFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    where?: Prisma.rapportWhereInput;
    orderBy?: Prisma.rapportOrderByWithRelationInput | Prisma.rapportOrderByWithRelationInput[];
    cursor?: Prisma.rapportWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.RapportScalarFieldEnum | Prisma.RapportScalarFieldEnum[];
};
export type rapportCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.rapportCreateInput, Prisma.rapportUncheckedCreateInput>;
};
export type rapportCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.rapportCreateManyInput | Prisma.rapportCreateManyInput[];
    skipDuplicates?: boolean;
};
export type rapportCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    data: Prisma.rapportCreateManyInput | Prisma.rapportCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.rapportIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type rapportUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.rapportUpdateInput, Prisma.rapportUncheckedUpdateInput>;
    where: Prisma.rapportWhereUniqueInput;
};
export type rapportUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.rapportUpdateManyMutationInput, Prisma.rapportUncheckedUpdateManyInput>;
    where?: Prisma.rapportWhereInput;
    limit?: number;
};
export type rapportUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.rapportUpdateManyMutationInput, Prisma.rapportUncheckedUpdateManyInput>;
    where?: Prisma.rapportWhereInput;
    limit?: number;
    include?: Prisma.rapportIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type rapportUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    where: Prisma.rapportWhereUniqueInput;
    create: Prisma.XOR<Prisma.rapportCreateInput, Prisma.rapportUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.rapportUpdateInput, Prisma.rapportUncheckedUpdateInput>;
};
export type rapportDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
    where: Prisma.rapportWhereUniqueInput;
};
export type rapportDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.rapportWhereInput;
    limit?: number;
};
export type rapportDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.rapportSelect<ExtArgs> | null;
    omit?: Prisma.rapportOmit<ExtArgs> | null;
    include?: Prisma.rapportInclude<ExtArgs> | null;
};
