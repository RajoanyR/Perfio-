import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type commentaireModel = runtime.Types.Result.DefaultSelection<Prisma.$commentairePayload>;
export type AggregateCommentaire = {
    _count: CommentaireCountAggregateOutputType | null;
    _avg: CommentaireAvgAggregateOutputType | null;
    _sum: CommentaireSumAggregateOutputType | null;
    _min: CommentaireMinAggregateOutputType | null;
    _max: CommentaireMaxAggregateOutputType | null;
};
export type CommentaireAvgAggregateOutputType = {
    id_commentaire: number | null;
    id_tache: number | null;
    id_utilisateur: number | null;
};
export type CommentaireSumAggregateOutputType = {
    id_commentaire: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
};
export type CommentaireMinAggregateOutputType = {
    id_commentaire: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
    contenu: string | null;
    date_creation: Date | null;
    date_modification: Date | null;
    statut: string | null;
};
export type CommentaireMaxAggregateOutputType = {
    id_commentaire: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
    contenu: string | null;
    date_creation: Date | null;
    date_modification: Date | null;
    statut: string | null;
};
export type CommentaireCountAggregateOutputType = {
    id_commentaire: number;
    id_tache: number;
    id_utilisateur: number;
    contenu: number;
    date_creation: number;
    date_modification: number;
    statut: number;
    _all: number;
};
export type CommentaireAvgAggregateInputType = {
    id_commentaire?: true;
    id_tache?: true;
    id_utilisateur?: true;
};
export type CommentaireSumAggregateInputType = {
    id_commentaire?: true;
    id_tache?: true;
    id_utilisateur?: true;
};
export type CommentaireMinAggregateInputType = {
    id_commentaire?: true;
    id_tache?: true;
    id_utilisateur?: true;
    contenu?: true;
    date_creation?: true;
    date_modification?: true;
    statut?: true;
};
export type CommentaireMaxAggregateInputType = {
    id_commentaire?: true;
    id_tache?: true;
    id_utilisateur?: true;
    contenu?: true;
    date_creation?: true;
    date_modification?: true;
    statut?: true;
};
export type CommentaireCountAggregateInputType = {
    id_commentaire?: true;
    id_tache?: true;
    id_utilisateur?: true;
    contenu?: true;
    date_creation?: true;
    date_modification?: true;
    statut?: true;
    _all?: true;
};
export type CommentaireAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.commentaireWhereInput;
    orderBy?: Prisma.commentaireOrderByWithRelationInput | Prisma.commentaireOrderByWithRelationInput[];
    cursor?: Prisma.commentaireWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | CommentaireCountAggregateInputType;
    _avg?: CommentaireAvgAggregateInputType;
    _sum?: CommentaireSumAggregateInputType;
    _min?: CommentaireMinAggregateInputType;
    _max?: CommentaireMaxAggregateInputType;
};
export type GetCommentaireAggregateType<T extends CommentaireAggregateArgs> = {
    [P in keyof T & keyof AggregateCommentaire]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateCommentaire[P]> : Prisma.GetScalarType<T[P], AggregateCommentaire[P]>;
};
export type commentaireGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.commentaireWhereInput;
    orderBy?: Prisma.commentaireOrderByWithAggregationInput | Prisma.commentaireOrderByWithAggregationInput[];
    by: Prisma.CommentaireScalarFieldEnum[] | Prisma.CommentaireScalarFieldEnum;
    having?: Prisma.commentaireScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: CommentaireCountAggregateInputType | true;
    _avg?: CommentaireAvgAggregateInputType;
    _sum?: CommentaireSumAggregateInputType;
    _min?: CommentaireMinAggregateInputType;
    _max?: CommentaireMaxAggregateInputType;
};
export type CommentaireGroupByOutputType = {
    id_commentaire: bigint;
    id_tache: bigint;
    id_utilisateur: bigint;
    contenu: string;
    date_creation: Date;
    date_modification: Date | null;
    statut: string;
    _count: CommentaireCountAggregateOutputType | null;
    _avg: CommentaireAvgAggregateOutputType | null;
    _sum: CommentaireSumAggregateOutputType | null;
    _min: CommentaireMinAggregateOutputType | null;
    _max: CommentaireMaxAggregateOutputType | null;
};
export type GetCommentaireGroupByPayload<T extends commentaireGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<CommentaireGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof CommentaireGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], CommentaireGroupByOutputType[P]> : Prisma.GetScalarType<T[P], CommentaireGroupByOutputType[P]>;
}>>;
export type commentaireWhereInput = {
    AND?: Prisma.commentaireWhereInput | Prisma.commentaireWhereInput[];
    OR?: Prisma.commentaireWhereInput[];
    NOT?: Prisma.commentaireWhereInput | Prisma.commentaireWhereInput[];
    id_commentaire?: Prisma.BigIntFilter<"commentaire"> | bigint | number;
    id_tache?: Prisma.BigIntFilter<"commentaire"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"commentaire"> | bigint | number;
    contenu?: Prisma.StringFilter<"commentaire"> | string;
    date_creation?: Prisma.DateTimeFilter<"commentaire"> | Date | string;
    date_modification?: Prisma.DateTimeNullableFilter<"commentaire"> | Date | string | null;
    statut?: Prisma.StringFilter<"commentaire"> | string;
    tache?: Prisma.XOR<Prisma.TacheScalarRelationFilter, Prisma.tacheWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
    piece_jointe?: Prisma.Piece_jointeListRelationFilter;
};
export type commentaireOrderByWithRelationInput = {
    id_commentaire?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    contenu?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_modification?: Prisma.SortOrderInput | Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    tache?: Prisma.tacheOrderByWithRelationInput;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
    piece_jointe?: Prisma.piece_jointeOrderByRelationAggregateInput;
};
export type commentaireWhereUniqueInput = Prisma.AtLeast<{
    id_commentaire?: bigint | number;
    AND?: Prisma.commentaireWhereInput | Prisma.commentaireWhereInput[];
    OR?: Prisma.commentaireWhereInput[];
    NOT?: Prisma.commentaireWhereInput | Prisma.commentaireWhereInput[];
    id_tache?: Prisma.BigIntFilter<"commentaire"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"commentaire"> | bigint | number;
    contenu?: Prisma.StringFilter<"commentaire"> | string;
    date_creation?: Prisma.DateTimeFilter<"commentaire"> | Date | string;
    date_modification?: Prisma.DateTimeNullableFilter<"commentaire"> | Date | string | null;
    statut?: Prisma.StringFilter<"commentaire"> | string;
    tache?: Prisma.XOR<Prisma.TacheScalarRelationFilter, Prisma.tacheWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
    piece_jointe?: Prisma.Piece_jointeListRelationFilter;
}, "id_commentaire">;
export type commentaireOrderByWithAggregationInput = {
    id_commentaire?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    contenu?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_modification?: Prisma.SortOrderInput | Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    _count?: Prisma.commentaireCountOrderByAggregateInput;
    _avg?: Prisma.commentaireAvgOrderByAggregateInput;
    _max?: Prisma.commentaireMaxOrderByAggregateInput;
    _min?: Prisma.commentaireMinOrderByAggregateInput;
    _sum?: Prisma.commentaireSumOrderByAggregateInput;
};
export type commentaireScalarWhereWithAggregatesInput = {
    AND?: Prisma.commentaireScalarWhereWithAggregatesInput | Prisma.commentaireScalarWhereWithAggregatesInput[];
    OR?: Prisma.commentaireScalarWhereWithAggregatesInput[];
    NOT?: Prisma.commentaireScalarWhereWithAggregatesInput | Prisma.commentaireScalarWhereWithAggregatesInput[];
    id_commentaire?: Prisma.BigIntWithAggregatesFilter<"commentaire"> | bigint | number;
    id_tache?: Prisma.BigIntWithAggregatesFilter<"commentaire"> | bigint | number;
    id_utilisateur?: Prisma.BigIntWithAggregatesFilter<"commentaire"> | bigint | number;
    contenu?: Prisma.StringWithAggregatesFilter<"commentaire"> | string;
    date_creation?: Prisma.DateTimeWithAggregatesFilter<"commentaire"> | Date | string;
    date_modification?: Prisma.DateTimeNullableWithAggregatesFilter<"commentaire"> | Date | string | null;
    statut?: Prisma.StringWithAggregatesFilter<"commentaire"> | string;
};
export type commentaireCreateInput = {
    id_commentaire?: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
    tache: Prisma.tacheCreateNestedOneWithoutCommentaireInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutCommentaireInput;
    piece_jointe?: Prisma.piece_jointeCreateNestedManyWithoutCommentaireInput;
};
export type commentaireUncheckedCreateInput = {
    id_commentaire?: bigint | number;
    id_tache: bigint | number;
    id_utilisateur: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
    piece_jointe?: Prisma.piece_jointeUncheckedCreateNestedManyWithoutCommentaireInput;
};
export type commentaireUpdateInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutCommentaireNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutCommentaireNestedInput;
    piece_jointe?: Prisma.piece_jointeUpdateManyWithoutCommentaireNestedInput;
};
export type commentaireUncheckedUpdateInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    piece_jointe?: Prisma.piece_jointeUncheckedUpdateManyWithoutCommentaireNestedInput;
};
export type commentaireCreateManyInput = {
    id_commentaire?: bigint | number;
    id_tache: bigint | number;
    id_utilisateur: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
};
export type commentaireUpdateManyMutationInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type commentaireUncheckedUpdateManyInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type commentaireCountOrderByAggregateInput = {
    id_commentaire?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    contenu?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_modification?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type commentaireAvgOrderByAggregateInput = {
    id_commentaire?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type commentaireMaxOrderByAggregateInput = {
    id_commentaire?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    contenu?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_modification?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type commentaireMinOrderByAggregateInput = {
    id_commentaire?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    contenu?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_modification?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type commentaireSumOrderByAggregateInput = {
    id_commentaire?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type CommentaireNullableScalarRelationFilter = {
    is?: Prisma.commentaireWhereInput | null;
    isNot?: Prisma.commentaireWhereInput | null;
};
export type CommentaireListRelationFilter = {
    every?: Prisma.commentaireWhereInput;
    some?: Prisma.commentaireWhereInput;
    none?: Prisma.commentaireWhereInput;
};
export type commentaireOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type StringFieldUpdateOperationsInput = {
    set?: string;
};
export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null;
};
export type commentaireCreateNestedOneWithoutPiece_jointeInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutPiece_jointeInput, Prisma.commentaireUncheckedCreateWithoutPiece_jointeInput>;
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutPiece_jointeInput;
    connect?: Prisma.commentaireWhereUniqueInput;
};
export type commentaireUpdateOneWithoutPiece_jointeNestedInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutPiece_jointeInput, Prisma.commentaireUncheckedCreateWithoutPiece_jointeInput>;
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutPiece_jointeInput;
    upsert?: Prisma.commentaireUpsertWithoutPiece_jointeInput;
    disconnect?: Prisma.commentaireWhereInput | boolean;
    delete?: Prisma.commentaireWhereInput | boolean;
    connect?: Prisma.commentaireWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.commentaireUpdateToOneWithWhereWithoutPiece_jointeInput, Prisma.commentaireUpdateWithoutPiece_jointeInput>, Prisma.commentaireUncheckedUpdateWithoutPiece_jointeInput>;
};
export type commentaireCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutTacheInput, Prisma.commentaireUncheckedCreateWithoutTacheInput> | Prisma.commentaireCreateWithoutTacheInput[] | Prisma.commentaireUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutTacheInput | Prisma.commentaireCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.commentaireCreateManyTacheInputEnvelope;
    connect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
};
export type commentaireUncheckedCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutTacheInput, Prisma.commentaireUncheckedCreateWithoutTacheInput> | Prisma.commentaireCreateWithoutTacheInput[] | Prisma.commentaireUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutTacheInput | Prisma.commentaireCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.commentaireCreateManyTacheInputEnvelope;
    connect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
};
export type commentaireUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutTacheInput, Prisma.commentaireUncheckedCreateWithoutTacheInput> | Prisma.commentaireCreateWithoutTacheInput[] | Prisma.commentaireUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutTacheInput | Prisma.commentaireCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.commentaireUpsertWithWhereUniqueWithoutTacheInput | Prisma.commentaireUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.commentaireCreateManyTacheInputEnvelope;
    set?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    disconnect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    delete?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    connect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    update?: Prisma.commentaireUpdateWithWhereUniqueWithoutTacheInput | Prisma.commentaireUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.commentaireUpdateManyWithWhereWithoutTacheInput | Prisma.commentaireUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.commentaireScalarWhereInput | Prisma.commentaireScalarWhereInput[];
};
export type commentaireUncheckedUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutTacheInput, Prisma.commentaireUncheckedCreateWithoutTacheInput> | Prisma.commentaireCreateWithoutTacheInput[] | Prisma.commentaireUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutTacheInput | Prisma.commentaireCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.commentaireUpsertWithWhereUniqueWithoutTacheInput | Prisma.commentaireUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.commentaireCreateManyTacheInputEnvelope;
    set?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    disconnect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    delete?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    connect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    update?: Prisma.commentaireUpdateWithWhereUniqueWithoutTacheInput | Prisma.commentaireUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.commentaireUpdateManyWithWhereWithoutTacheInput | Prisma.commentaireUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.commentaireScalarWhereInput | Prisma.commentaireScalarWhereInput[];
};
export type commentaireCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutUtilisateurInput, Prisma.commentaireUncheckedCreateWithoutUtilisateurInput> | Prisma.commentaireCreateWithoutUtilisateurInput[] | Prisma.commentaireUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutUtilisateurInput | Prisma.commentaireCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.commentaireCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
};
export type commentaireUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutUtilisateurInput, Prisma.commentaireUncheckedCreateWithoutUtilisateurInput> | Prisma.commentaireCreateWithoutUtilisateurInput[] | Prisma.commentaireUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutUtilisateurInput | Prisma.commentaireCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.commentaireCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
};
export type commentaireUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutUtilisateurInput, Prisma.commentaireUncheckedCreateWithoutUtilisateurInput> | Prisma.commentaireCreateWithoutUtilisateurInput[] | Prisma.commentaireUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutUtilisateurInput | Prisma.commentaireCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.commentaireUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.commentaireUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.commentaireCreateManyUtilisateurInputEnvelope;
    set?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    disconnect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    delete?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    connect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    update?: Prisma.commentaireUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.commentaireUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.commentaireUpdateManyWithWhereWithoutUtilisateurInput | Prisma.commentaireUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.commentaireScalarWhereInput | Prisma.commentaireScalarWhereInput[];
};
export type commentaireUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.commentaireCreateWithoutUtilisateurInput, Prisma.commentaireUncheckedCreateWithoutUtilisateurInput> | Prisma.commentaireCreateWithoutUtilisateurInput[] | Prisma.commentaireUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.commentaireCreateOrConnectWithoutUtilisateurInput | Prisma.commentaireCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.commentaireUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.commentaireUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.commentaireCreateManyUtilisateurInputEnvelope;
    set?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    disconnect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    delete?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    connect?: Prisma.commentaireWhereUniqueInput | Prisma.commentaireWhereUniqueInput[];
    update?: Prisma.commentaireUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.commentaireUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.commentaireUpdateManyWithWhereWithoutUtilisateurInput | Prisma.commentaireUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.commentaireScalarWhereInput | Prisma.commentaireScalarWhereInput[];
};
export type commentaireCreateWithoutPiece_jointeInput = {
    id_commentaire?: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
    tache: Prisma.tacheCreateNestedOneWithoutCommentaireInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutCommentaireInput;
};
export type commentaireUncheckedCreateWithoutPiece_jointeInput = {
    id_commentaire?: bigint | number;
    id_tache: bigint | number;
    id_utilisateur: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
};
export type commentaireCreateOrConnectWithoutPiece_jointeInput = {
    where: Prisma.commentaireWhereUniqueInput;
    create: Prisma.XOR<Prisma.commentaireCreateWithoutPiece_jointeInput, Prisma.commentaireUncheckedCreateWithoutPiece_jointeInput>;
};
export type commentaireUpsertWithoutPiece_jointeInput = {
    update: Prisma.XOR<Prisma.commentaireUpdateWithoutPiece_jointeInput, Prisma.commentaireUncheckedUpdateWithoutPiece_jointeInput>;
    create: Prisma.XOR<Prisma.commentaireCreateWithoutPiece_jointeInput, Prisma.commentaireUncheckedCreateWithoutPiece_jointeInput>;
    where?: Prisma.commentaireWhereInput;
};
export type commentaireUpdateToOneWithWhereWithoutPiece_jointeInput = {
    where?: Prisma.commentaireWhereInput;
    data: Prisma.XOR<Prisma.commentaireUpdateWithoutPiece_jointeInput, Prisma.commentaireUncheckedUpdateWithoutPiece_jointeInput>;
};
export type commentaireUpdateWithoutPiece_jointeInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutCommentaireNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutCommentaireNestedInput;
};
export type commentaireUncheckedUpdateWithoutPiece_jointeInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type commentaireCreateWithoutTacheInput = {
    id_commentaire?: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutCommentaireInput;
    piece_jointe?: Prisma.piece_jointeCreateNestedManyWithoutCommentaireInput;
};
export type commentaireUncheckedCreateWithoutTacheInput = {
    id_commentaire?: bigint | number;
    id_utilisateur: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
    piece_jointe?: Prisma.piece_jointeUncheckedCreateNestedManyWithoutCommentaireInput;
};
export type commentaireCreateOrConnectWithoutTacheInput = {
    where: Prisma.commentaireWhereUniqueInput;
    create: Prisma.XOR<Prisma.commentaireCreateWithoutTacheInput, Prisma.commentaireUncheckedCreateWithoutTacheInput>;
};
export type commentaireCreateManyTacheInputEnvelope = {
    data: Prisma.commentaireCreateManyTacheInput | Prisma.commentaireCreateManyTacheInput[];
    skipDuplicates?: boolean;
};
export type commentaireUpsertWithWhereUniqueWithoutTacheInput = {
    where: Prisma.commentaireWhereUniqueInput;
    update: Prisma.XOR<Prisma.commentaireUpdateWithoutTacheInput, Prisma.commentaireUncheckedUpdateWithoutTacheInput>;
    create: Prisma.XOR<Prisma.commentaireCreateWithoutTacheInput, Prisma.commentaireUncheckedCreateWithoutTacheInput>;
};
export type commentaireUpdateWithWhereUniqueWithoutTacheInput = {
    where: Prisma.commentaireWhereUniqueInput;
    data: Prisma.XOR<Prisma.commentaireUpdateWithoutTacheInput, Prisma.commentaireUncheckedUpdateWithoutTacheInput>;
};
export type commentaireUpdateManyWithWhereWithoutTacheInput = {
    where: Prisma.commentaireScalarWhereInput;
    data: Prisma.XOR<Prisma.commentaireUpdateManyMutationInput, Prisma.commentaireUncheckedUpdateManyWithoutTacheInput>;
};
export type commentaireScalarWhereInput = {
    AND?: Prisma.commentaireScalarWhereInput | Prisma.commentaireScalarWhereInput[];
    OR?: Prisma.commentaireScalarWhereInput[];
    NOT?: Prisma.commentaireScalarWhereInput | Prisma.commentaireScalarWhereInput[];
    id_commentaire?: Prisma.BigIntFilter<"commentaire"> | bigint | number;
    id_tache?: Prisma.BigIntFilter<"commentaire"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"commentaire"> | bigint | number;
    contenu?: Prisma.StringFilter<"commentaire"> | string;
    date_creation?: Prisma.DateTimeFilter<"commentaire"> | Date | string;
    date_modification?: Prisma.DateTimeNullableFilter<"commentaire"> | Date | string | null;
    statut?: Prisma.StringFilter<"commentaire"> | string;
};
export type commentaireCreateWithoutUtilisateurInput = {
    id_commentaire?: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
    tache: Prisma.tacheCreateNestedOneWithoutCommentaireInput;
    piece_jointe?: Prisma.piece_jointeCreateNestedManyWithoutCommentaireInput;
};
export type commentaireUncheckedCreateWithoutUtilisateurInput = {
    id_commentaire?: bigint | number;
    id_tache: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
    piece_jointe?: Prisma.piece_jointeUncheckedCreateNestedManyWithoutCommentaireInput;
};
export type commentaireCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.commentaireWhereUniqueInput;
    create: Prisma.XOR<Prisma.commentaireCreateWithoutUtilisateurInput, Prisma.commentaireUncheckedCreateWithoutUtilisateurInput>;
};
export type commentaireCreateManyUtilisateurInputEnvelope = {
    data: Prisma.commentaireCreateManyUtilisateurInput | Prisma.commentaireCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type commentaireUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.commentaireWhereUniqueInput;
    update: Prisma.XOR<Prisma.commentaireUpdateWithoutUtilisateurInput, Prisma.commentaireUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.commentaireCreateWithoutUtilisateurInput, Prisma.commentaireUncheckedCreateWithoutUtilisateurInput>;
};
export type commentaireUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.commentaireWhereUniqueInput;
    data: Prisma.XOR<Prisma.commentaireUpdateWithoutUtilisateurInput, Prisma.commentaireUncheckedUpdateWithoutUtilisateurInput>;
};
export type commentaireUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.commentaireScalarWhereInput;
    data: Prisma.XOR<Prisma.commentaireUpdateManyMutationInput, Prisma.commentaireUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type commentaireCreateManyTacheInput = {
    id_commentaire?: bigint | number;
    id_utilisateur: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
};
export type commentaireUpdateWithoutTacheInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutCommentaireNestedInput;
    piece_jointe?: Prisma.piece_jointeUpdateManyWithoutCommentaireNestedInput;
};
export type commentaireUncheckedUpdateWithoutTacheInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    piece_jointe?: Prisma.piece_jointeUncheckedUpdateManyWithoutCommentaireNestedInput;
};
export type commentaireUncheckedUpdateManyWithoutTacheInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type commentaireCreateManyUtilisateurInput = {
    id_commentaire?: bigint | number;
    id_tache: bigint | number;
    contenu: string;
    date_creation?: Date | string;
    date_modification?: Date | string | null;
    statut?: string;
};
export type commentaireUpdateWithoutUtilisateurInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutCommentaireNestedInput;
    piece_jointe?: Prisma.piece_jointeUpdateManyWithoutCommentaireNestedInput;
};
export type commentaireUncheckedUpdateWithoutUtilisateurInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    piece_jointe?: Prisma.piece_jointeUncheckedUpdateManyWithoutCommentaireNestedInput;
};
export type commentaireUncheckedUpdateManyWithoutUtilisateurInput = {
    id_commentaire?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    contenu?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_modification?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type CommentaireCountOutputType = {
    piece_jointe: number;
};
export type CommentaireCountOutputTypeSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    piece_jointe?: boolean | CommentaireCountOutputTypeCountPiece_jointeArgs;
};
export type CommentaireCountOutputTypeDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.CommentaireCountOutputTypeSelect<ExtArgs> | null;
};
export type CommentaireCountOutputTypeCountPiece_jointeArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.piece_jointeWhereInput;
};
export type commentaireSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_commentaire?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    contenu?: boolean;
    date_creation?: boolean;
    date_modification?: boolean;
    statut?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    piece_jointe?: boolean | Prisma.commentaire$piece_jointeArgs<ExtArgs>;
    _count?: boolean | Prisma.CommentaireCountOutputTypeDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["commentaire"]>;
export type commentaireSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_commentaire?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    contenu?: boolean;
    date_creation?: boolean;
    date_modification?: boolean;
    statut?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["commentaire"]>;
export type commentaireSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_commentaire?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    contenu?: boolean;
    date_creation?: boolean;
    date_modification?: boolean;
    statut?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["commentaire"]>;
export type commentaireSelectScalar = {
    id_commentaire?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    contenu?: boolean;
    date_creation?: boolean;
    date_modification?: boolean;
    statut?: boolean;
};
export type commentaireOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_commentaire" | "id_tache" | "id_utilisateur" | "contenu" | "date_creation" | "date_modification" | "statut", ExtArgs["result"]["commentaire"]>;
export type commentaireInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    piece_jointe?: boolean | Prisma.commentaire$piece_jointeArgs<ExtArgs>;
    _count?: boolean | Prisma.CommentaireCountOutputTypeDefaultArgs<ExtArgs>;
};
export type commentaireIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type commentaireIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $commentairePayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "commentaire";
    objects: {
        tache: Prisma.$tachePayload<ExtArgs>;
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>;
        piece_jointe: Prisma.$piece_jointePayload<ExtArgs>[];
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_commentaire: bigint;
        id_tache: bigint;
        id_utilisateur: bigint;
        contenu: string;
        date_creation: Date;
        date_modification: Date | null;
        statut: string;
    }, ExtArgs["result"]["commentaire"]>;
    composites: {};
};
export type commentaireGetPayload<S extends boolean | null | undefined | commentaireDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$commentairePayload, S>;
export type commentaireCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<commentaireFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: CommentaireCountAggregateInputType | true;
};
export interface commentaireDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['commentaire'];
        meta: {
            name: 'commentaire';
        };
    };
    findUnique<T extends commentaireFindUniqueArgs>(args: Prisma.SelectSubset<T, commentaireFindUniqueArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends commentaireFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, commentaireFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends commentaireFindFirstArgs>(args?: Prisma.SelectSubset<T, commentaireFindFirstArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends commentaireFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, commentaireFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends commentaireFindManyArgs>(args?: Prisma.SelectSubset<T, commentaireFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends commentaireCreateArgs>(args: Prisma.SelectSubset<T, commentaireCreateArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends commentaireCreateManyArgs>(args?: Prisma.SelectSubset<T, commentaireCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends commentaireCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, commentaireCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends commentaireDeleteArgs>(args: Prisma.SelectSubset<T, commentaireDeleteArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends commentaireUpdateArgs>(args: Prisma.SelectSubset<T, commentaireUpdateArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends commentaireDeleteManyArgs>(args?: Prisma.SelectSubset<T, commentaireDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends commentaireUpdateManyArgs>(args: Prisma.SelectSubset<T, commentaireUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends commentaireUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, commentaireUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends commentaireUpsertArgs>(args: Prisma.SelectSubset<T, commentaireUpsertArgs<ExtArgs>>): Prisma.Prisma__commentaireClient<runtime.Types.Result.GetResult<Prisma.$commentairePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends commentaireCountArgs>(args?: Prisma.Subset<T, commentaireCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], CommentaireCountAggregateOutputType> : number>;
    aggregate<T extends CommentaireAggregateArgs>(args: Prisma.Subset<T, CommentaireAggregateArgs>): Prisma.PrismaPromise<GetCommentaireAggregateType<T>>;
    groupBy<T extends commentaireGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: commentaireGroupByArgs['orderBy'];
    } : {
        orderBy?: commentaireGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, commentaireGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetCommentaireGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: commentaireFieldRefs;
}
export interface Prisma__commentaireClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    tache<T extends Prisma.tacheDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.tacheDefaultArgs<ExtArgs>>): Prisma.Prisma__tacheClient<runtime.Types.Result.GetResult<Prisma.$tachePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    utilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    piece_jointe<T extends Prisma.commentaire$piece_jointeArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.commentaire$piece_jointeArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$piece_jointePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface commentaireFieldRefs {
    readonly id_commentaire: Prisma.FieldRef<"commentaire", 'BigInt'>;
    readonly id_tache: Prisma.FieldRef<"commentaire", 'BigInt'>;
    readonly id_utilisateur: Prisma.FieldRef<"commentaire", 'BigInt'>;
    readonly contenu: Prisma.FieldRef<"commentaire", 'String'>;
    readonly date_creation: Prisma.FieldRef<"commentaire", 'DateTime'>;
    readonly date_modification: Prisma.FieldRef<"commentaire", 'DateTime'>;
    readonly statut: Prisma.FieldRef<"commentaire", 'String'>;
}
export type commentaireFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    where: Prisma.commentaireWhereUniqueInput;
};
export type commentaireFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    where: Prisma.commentaireWhereUniqueInput;
};
export type commentaireFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    where?: Prisma.commentaireWhereInput;
    orderBy?: Prisma.commentaireOrderByWithRelationInput | Prisma.commentaireOrderByWithRelationInput[];
    cursor?: Prisma.commentaireWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.CommentaireScalarFieldEnum | Prisma.CommentaireScalarFieldEnum[];
};
export type commentaireFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    where?: Prisma.commentaireWhereInput;
    orderBy?: Prisma.commentaireOrderByWithRelationInput | Prisma.commentaireOrderByWithRelationInput[];
    cursor?: Prisma.commentaireWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.CommentaireScalarFieldEnum | Prisma.CommentaireScalarFieldEnum[];
};
export type commentaireFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    where?: Prisma.commentaireWhereInput;
    orderBy?: Prisma.commentaireOrderByWithRelationInput | Prisma.commentaireOrderByWithRelationInput[];
    cursor?: Prisma.commentaireWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.CommentaireScalarFieldEnum | Prisma.CommentaireScalarFieldEnum[];
};
export type commentaireCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.commentaireCreateInput, Prisma.commentaireUncheckedCreateInput>;
};
export type commentaireCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.commentaireCreateManyInput | Prisma.commentaireCreateManyInput[];
    skipDuplicates?: boolean;
};
export type commentaireCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    data: Prisma.commentaireCreateManyInput | Prisma.commentaireCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.commentaireIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type commentaireUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.commentaireUpdateInput, Prisma.commentaireUncheckedUpdateInput>;
    where: Prisma.commentaireWhereUniqueInput;
};
export type commentaireUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.commentaireUpdateManyMutationInput, Prisma.commentaireUncheckedUpdateManyInput>;
    where?: Prisma.commentaireWhereInput;
    limit?: number;
};
export type commentaireUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.commentaireUpdateManyMutationInput, Prisma.commentaireUncheckedUpdateManyInput>;
    where?: Prisma.commentaireWhereInput;
    limit?: number;
    include?: Prisma.commentaireIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type commentaireUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    where: Prisma.commentaireWhereUniqueInput;
    create: Prisma.XOR<Prisma.commentaireCreateInput, Prisma.commentaireUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.commentaireUpdateInput, Prisma.commentaireUncheckedUpdateInput>;
};
export type commentaireDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
    where: Prisma.commentaireWhereUniqueInput;
};
export type commentaireDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.commentaireWhereInput;
    limit?: number;
};
export type commentaire$piece_jointeArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.piece_jointeSelect<ExtArgs> | null;
    omit?: Prisma.piece_jointeOmit<ExtArgs> | null;
    include?: Prisma.piece_jointeInclude<ExtArgs> | null;
    where?: Prisma.piece_jointeWhereInput;
    orderBy?: Prisma.piece_jointeOrderByWithRelationInput | Prisma.piece_jointeOrderByWithRelationInput[];
    cursor?: Prisma.piece_jointeWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Piece_jointeScalarFieldEnum | Prisma.Piece_jointeScalarFieldEnum[];
};
export type commentaireDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.commentaireSelect<ExtArgs> | null;
    omit?: Prisma.commentaireOmit<ExtArgs> | null;
    include?: Prisma.commentaireInclude<ExtArgs> | null;
};
