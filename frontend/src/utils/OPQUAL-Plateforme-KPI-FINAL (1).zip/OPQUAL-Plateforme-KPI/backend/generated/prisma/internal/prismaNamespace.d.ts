import * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../models.js";
import { type PrismaClient } from "./class.js";
export type * from '../models.js';
export type DMMF = typeof runtime.DMMF;
export type PrismaPromise<T> = runtime.Types.Public.PrismaPromise<T>;
export declare const PrismaClientKnownRequestError: typeof runtime.PrismaClientKnownRequestError;
export type PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError;
export declare const PrismaClientUnknownRequestError: typeof runtime.PrismaClientUnknownRequestError;
export type PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError;
export declare const PrismaClientRustPanicError: typeof runtime.PrismaClientRustPanicError;
export type PrismaClientRustPanicError = runtime.PrismaClientRustPanicError;
export declare const PrismaClientInitializationError: typeof runtime.PrismaClientInitializationError;
export type PrismaClientInitializationError = runtime.PrismaClientInitializationError;
export declare const PrismaClientValidationError: typeof runtime.PrismaClientValidationError;
export type PrismaClientValidationError = runtime.PrismaClientValidationError;
export declare const sql: typeof runtime.sqltag;
export declare const empty: runtime.Sql;
export declare const join: typeof runtime.join;
export declare const raw: typeof runtime.raw;
export declare const Sql: typeof runtime.Sql;
export type Sql = runtime.Sql;
export declare const Decimal: typeof runtime.Decimal;
export type Decimal = runtime.Decimal;
export type DecimalJsLike = runtime.DecimalJsLike;
export type Extension = runtime.Types.Extensions.UserArgs;
export declare const getExtensionContext: typeof runtime.Extensions.getExtensionContext;
export type Args<T, F extends runtime.Operation> = runtime.Types.Public.Args<T, F>;
export type Payload<T, F extends runtime.Operation = never> = runtime.Types.Public.Payload<T, F>;
export type Result<T, A, F extends runtime.Operation> = runtime.Types.Public.Result<T, A, F>;
export type Exact<A, W> = runtime.Types.Public.Exact<A, W>;
export type PrismaVersion = {
    client: string;
    engine: string;
};
export declare const prismaVersion: PrismaVersion;
export type Bytes = runtime.Bytes;
export type JsonObject = runtime.JsonObject;
export type JsonArray = runtime.JsonArray;
export type JsonValue = runtime.JsonValue;
export type InputJsonObject = runtime.InputJsonObject;
export type InputJsonArray = runtime.InputJsonArray;
export type InputJsonValue = runtime.InputJsonValue;
export declare const NullTypes: {
    DbNull: (new (secret: never) => typeof runtime.DbNull);
    JsonNull: (new (secret: never) => typeof runtime.JsonNull);
    AnyNull: (new (secret: never) => typeof runtime.AnyNull);
};
export declare const DbNull: runtime.DbNullClass;
export declare const JsonNull: runtime.JsonNullClass;
export declare const AnyNull: runtime.AnyNullClass;
type SelectAndInclude = {
    select: any;
    include: any;
};
type SelectAndOmit = {
    select: any;
    omit: any;
};
type Prisma__Pick<T, K extends keyof T> = {
    [P in K]: T[P];
};
export type Enumerable<T> = T | Array<T>;
export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
};
export type PrismaClientConstructorArgs<Options extends PrismaClientOptions> = [
    PrismaClientOptions
] extends [Options] ? PrismaClientOptions : Subset<Options, PrismaClientOptions>;
export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
} & (T extends SelectAndInclude ? 'Please either choose `select` or `include`.' : T extends SelectAndOmit ? 'Please either choose `select` or `omit`.' : {});
export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
} & K;
type Without<T, U> = {
    [P in Exclude<keyof T, keyof U>]?: never;
};
export type XOR<T, U> = T extends object ? U extends object ? ((Without<T, U> & U) | (Without<U, T> & T)) & object : U : T;
type IsObject<T extends any> = T extends Array<any> ? False : T extends Date ? False : T extends Uint8Array ? False : T extends BigInt ? False : T extends object ? True : False;
export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T;
type __Either<O extends object, K extends Key> = Omit<O, K> & {
    [P in K]: Prisma__Pick<O, P & keyof O>;
}[K];
type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>;
type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>;
type _Either<O extends object, K extends Key, strict extends Boolean> = {
    1: EitherStrict<O, K>;
    0: EitherLoose<O, K>;
}[strict];
export type Either<O extends object, K extends Key, strict extends Boolean = 1> = O extends unknown ? _Either<O, K, strict> : never;
export type Union = any;
export type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K];
} & {};
export type IntersectOf<U extends Union> = (U extends unknown ? (k: U) => void : never) extends (k: infer I) => void ? I : never;
export type Overwrite<O extends object, O1 extends object> = {
    [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
} & {};
type _Merge<U extends object> = IntersectOf<Overwrite<U, {
    [K in keyof U]-?: At<U, K>;
}>>;
type Key = string | number | symbol;
type AtStrict<O extends object, K extends Key> = O[K & keyof O];
type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
    1: AtStrict<O, K>;
    0: AtLoose<O, K>;
}[strict];
export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
} & {};
export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
} & {};
type _Record<K extends keyof any, T> = {
    [P in K]: T;
};
type NoExpand<T> = T extends unknown ? T : never;
export type AtLeast<O extends object, K extends string> = NoExpand<O extends unknown ? (K extends keyof O ? {
    [P in K]: O[P];
} & O : O) | {
    [P in keyof O as P extends K ? P : never]-?: O[P];
} & O : never>;
type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;
export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;
export type Boolean = True | False;
export type True = 1;
export type False = 0;
export type Not<B extends Boolean> = {
    0: 1;
    1: 0;
}[B];
export type Extends<A1 extends any, A2 extends any> = [A1] extends [never] ? 0 : A1 extends A2 ? 1 : 0;
export type Has<U extends Union, U1 extends Union> = Not<Extends<Exclude<U1, U>, U1>>;
export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
        0: 0;
        1: 1;
    };
    1: {
        0: 1;
        1: 1;
    };
}[B1][B2];
export type Keys<U extends Union> = U extends unknown ? keyof U : never;
export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O ? O[P] : never;
} : never;
type FieldPaths<T, U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>> = IsObject<T> extends True ? U : T;
export type GetHavingFields<T> = {
    [K in keyof T]: Or<Or<Extends<'OR', K>, Extends<'AND', K>>, Extends<'NOT', K>> extends True ? T[K] extends infer TK ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never> : never : {} extends FieldPaths<T[K]> ? never : K;
}[keyof T];
type _TupleToUnion<T> = T extends (infer E)[] ? E : never;
type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>;
export type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T;
export type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>;
export type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T;
export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>;
type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>;
export declare const ModelName: {
    readonly activite: "activite";
    readonly commentaire: "commentaire";
    readonly entreprise: "entreprise";
    readonly equipe: "equipe";
    readonly historique_tache: "historique_tache";
    readonly notification: "notification";
    readonly participation_projet: "participation_projet";
    readonly permission: "permission";
    readonly piece_jointe: "piece_jointe";
    readonly projet: "projet";
    readonly rapport: "rapport";
    readonly role: "role";
    readonly role_permission: "role_permission";
    readonly session: "session";
    readonly tache: "tache";
    readonly transfert_tache: "transfert_tache";
    readonly utilisateur: "utilisateur";
};
export type ModelName = (typeof ModelName)[keyof typeof ModelName];
export interface TypeMapCb<GlobalOmitOptions = {}> extends runtime.Types.Utils.Fn<{
    extArgs: runtime.Types.Extensions.InternalArgs;
}, runtime.Types.Utils.Record<string, any>> {
    returns: TypeMap<this['params']['extArgs'], GlobalOmitOptions>;
}
export type TypeMap<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
        omit: GlobalOmitOptions;
    };
    meta: {
        modelProps: "activite" | "commentaire" | "entreprise" | "equipe" | "historique_tache" | "notification" | "participation_projet" | "permission" | "piece_jointe" | "projet" | "rapport" | "role" | "role_permission" | "session" | "tache" | "transfert_tache" | "utilisateur";
        txIsolationLevel: TransactionIsolationLevel;
    };
    model: {
        activite: {
            payload: Prisma.$activitePayload<ExtArgs>;
            fields: Prisma.activiteFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.activiteFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.activiteFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>;
                };
                findFirst: {
                    args: Prisma.activiteFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.activiteFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>;
                };
                findMany: {
                    args: Prisma.activiteFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>[];
                };
                create: {
                    args: Prisma.activiteCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>;
                };
                createMany: {
                    args: Prisma.activiteCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.activiteCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>[];
                };
                delete: {
                    args: Prisma.activiteDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>;
                };
                update: {
                    args: Prisma.activiteUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>;
                };
                deleteMany: {
                    args: Prisma.activiteDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.activiteUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.activiteUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>[];
                };
                upsert: {
                    args: Prisma.activiteUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$activitePayload>;
                };
                aggregate: {
                    args: Prisma.ActiviteAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateActivite>;
                };
                groupBy: {
                    args: Prisma.activiteGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.ActiviteGroupByOutputType>[];
                };
                count: {
                    args: Prisma.activiteCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.ActiviteCountAggregateOutputType> | number;
                };
            };
        };
        commentaire: {
            payload: Prisma.$commentairePayload<ExtArgs>;
            fields: Prisma.commentaireFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.commentaireFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.commentaireFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>;
                };
                findFirst: {
                    args: Prisma.commentaireFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.commentaireFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>;
                };
                findMany: {
                    args: Prisma.commentaireFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>[];
                };
                create: {
                    args: Prisma.commentaireCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>;
                };
                createMany: {
                    args: Prisma.commentaireCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.commentaireCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>[];
                };
                delete: {
                    args: Prisma.commentaireDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>;
                };
                update: {
                    args: Prisma.commentaireUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>;
                };
                deleteMany: {
                    args: Prisma.commentaireDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.commentaireUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.commentaireUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>[];
                };
                upsert: {
                    args: Prisma.commentaireUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$commentairePayload>;
                };
                aggregate: {
                    args: Prisma.CommentaireAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateCommentaire>;
                };
                groupBy: {
                    args: Prisma.commentaireGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.CommentaireGroupByOutputType>[];
                };
                count: {
                    args: Prisma.commentaireCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.CommentaireCountAggregateOutputType> | number;
                };
            };
        };
        entreprise: {
            payload: Prisma.$entreprisePayload<ExtArgs>;
            fields: Prisma.entrepriseFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.entrepriseFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.entrepriseFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>;
                };
                findFirst: {
                    args: Prisma.entrepriseFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.entrepriseFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>;
                };
                findMany: {
                    args: Prisma.entrepriseFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>[];
                };
                create: {
                    args: Prisma.entrepriseCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>;
                };
                createMany: {
                    args: Prisma.entrepriseCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.entrepriseCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>[];
                };
                delete: {
                    args: Prisma.entrepriseDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>;
                };
                update: {
                    args: Prisma.entrepriseUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>;
                };
                deleteMany: {
                    args: Prisma.entrepriseDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.entrepriseUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.entrepriseUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>[];
                };
                upsert: {
                    args: Prisma.entrepriseUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$entreprisePayload>;
                };
                aggregate: {
                    args: Prisma.EntrepriseAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateEntreprise>;
                };
                groupBy: {
                    args: Prisma.entrepriseGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.EntrepriseGroupByOutputType>[];
                };
                count: {
                    args: Prisma.entrepriseCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.EntrepriseCountAggregateOutputType> | number;
                };
            };
        };
        equipe: {
            payload: Prisma.$equipePayload<ExtArgs>;
            fields: Prisma.equipeFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.equipeFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.equipeFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>;
                };
                findFirst: {
                    args: Prisma.equipeFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.equipeFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>;
                };
                findMany: {
                    args: Prisma.equipeFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>[];
                };
                create: {
                    args: Prisma.equipeCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>;
                };
                createMany: {
                    args: Prisma.equipeCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.equipeCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>[];
                };
                delete: {
                    args: Prisma.equipeDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>;
                };
                update: {
                    args: Prisma.equipeUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>;
                };
                deleteMany: {
                    args: Prisma.equipeDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.equipeUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.equipeUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>[];
                };
                upsert: {
                    args: Prisma.equipeUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$equipePayload>;
                };
                aggregate: {
                    args: Prisma.EquipeAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateEquipe>;
                };
                groupBy: {
                    args: Prisma.equipeGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.EquipeGroupByOutputType>[];
                };
                count: {
                    args: Prisma.equipeCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.EquipeCountAggregateOutputType> | number;
                };
            };
        };
        historique_tache: {
            payload: Prisma.$historique_tachePayload<ExtArgs>;
            fields: Prisma.historique_tacheFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.historique_tacheFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.historique_tacheFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>;
                };
                findFirst: {
                    args: Prisma.historique_tacheFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.historique_tacheFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>;
                };
                findMany: {
                    args: Prisma.historique_tacheFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>[];
                };
                create: {
                    args: Prisma.historique_tacheCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>;
                };
                createMany: {
                    args: Prisma.historique_tacheCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.historique_tacheCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>[];
                };
                delete: {
                    args: Prisma.historique_tacheDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>;
                };
                update: {
                    args: Prisma.historique_tacheUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>;
                };
                deleteMany: {
                    args: Prisma.historique_tacheDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.historique_tacheUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.historique_tacheUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>[];
                };
                upsert: {
                    args: Prisma.historique_tacheUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$historique_tachePayload>;
                };
                aggregate: {
                    args: Prisma.Historique_tacheAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateHistorique_tache>;
                };
                groupBy: {
                    args: Prisma.historique_tacheGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Historique_tacheGroupByOutputType>[];
                };
                count: {
                    args: Prisma.historique_tacheCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Historique_tacheCountAggregateOutputType> | number;
                };
            };
        };
        notification: {
            payload: Prisma.$notificationPayload<ExtArgs>;
            fields: Prisma.notificationFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.notificationFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.notificationFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>;
                };
                findFirst: {
                    args: Prisma.notificationFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.notificationFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>;
                };
                findMany: {
                    args: Prisma.notificationFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>[];
                };
                create: {
                    args: Prisma.notificationCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>;
                };
                createMany: {
                    args: Prisma.notificationCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.notificationCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>[];
                };
                delete: {
                    args: Prisma.notificationDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>;
                };
                update: {
                    args: Prisma.notificationUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>;
                };
                deleteMany: {
                    args: Prisma.notificationDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.notificationUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.notificationUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>[];
                };
                upsert: {
                    args: Prisma.notificationUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$notificationPayload>;
                };
                aggregate: {
                    args: Prisma.NotificationAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateNotification>;
                };
                groupBy: {
                    args: Prisma.notificationGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.NotificationGroupByOutputType>[];
                };
                count: {
                    args: Prisma.notificationCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.NotificationCountAggregateOutputType> | number;
                };
            };
        };
        participation_projet: {
            payload: Prisma.$participation_projetPayload<ExtArgs>;
            fields: Prisma.participation_projetFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.participation_projetFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.participation_projetFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>;
                };
                findFirst: {
                    args: Prisma.participation_projetFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.participation_projetFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>;
                };
                findMany: {
                    args: Prisma.participation_projetFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>[];
                };
                create: {
                    args: Prisma.participation_projetCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>;
                };
                createMany: {
                    args: Prisma.participation_projetCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.participation_projetCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>[];
                };
                delete: {
                    args: Prisma.participation_projetDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>;
                };
                update: {
                    args: Prisma.participation_projetUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>;
                };
                deleteMany: {
                    args: Prisma.participation_projetDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.participation_projetUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.participation_projetUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>[];
                };
                upsert: {
                    args: Prisma.participation_projetUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$participation_projetPayload>;
                };
                aggregate: {
                    args: Prisma.Participation_projetAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateParticipation_projet>;
                };
                groupBy: {
                    args: Prisma.participation_projetGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Participation_projetGroupByOutputType>[];
                };
                count: {
                    args: Prisma.participation_projetCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Participation_projetCountAggregateOutputType> | number;
                };
            };
        };
        permission: {
            payload: Prisma.$permissionPayload<ExtArgs>;
            fields: Prisma.permissionFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.permissionFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.permissionFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>;
                };
                findFirst: {
                    args: Prisma.permissionFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.permissionFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>;
                };
                findMany: {
                    args: Prisma.permissionFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>[];
                };
                create: {
                    args: Prisma.permissionCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>;
                };
                createMany: {
                    args: Prisma.permissionCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.permissionCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>[];
                };
                delete: {
                    args: Prisma.permissionDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>;
                };
                update: {
                    args: Prisma.permissionUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>;
                };
                deleteMany: {
                    args: Prisma.permissionDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.permissionUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.permissionUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>[];
                };
                upsert: {
                    args: Prisma.permissionUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$permissionPayload>;
                };
                aggregate: {
                    args: Prisma.PermissionAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregatePermission>;
                };
                groupBy: {
                    args: Prisma.permissionGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.PermissionGroupByOutputType>[];
                };
                count: {
                    args: Prisma.permissionCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.PermissionCountAggregateOutputType> | number;
                };
            };
        };
        piece_jointe: {
            payload: Prisma.$piece_jointePayload<ExtArgs>;
            fields: Prisma.piece_jointeFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.piece_jointeFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.piece_jointeFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>;
                };
                findFirst: {
                    args: Prisma.piece_jointeFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.piece_jointeFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>;
                };
                findMany: {
                    args: Prisma.piece_jointeFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>[];
                };
                create: {
                    args: Prisma.piece_jointeCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>;
                };
                createMany: {
                    args: Prisma.piece_jointeCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.piece_jointeCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>[];
                };
                delete: {
                    args: Prisma.piece_jointeDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>;
                };
                update: {
                    args: Prisma.piece_jointeUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>;
                };
                deleteMany: {
                    args: Prisma.piece_jointeDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.piece_jointeUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.piece_jointeUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>[];
                };
                upsert: {
                    args: Prisma.piece_jointeUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$piece_jointePayload>;
                };
                aggregate: {
                    args: Prisma.Piece_jointeAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregatePiece_jointe>;
                };
                groupBy: {
                    args: Prisma.piece_jointeGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Piece_jointeGroupByOutputType>[];
                };
                count: {
                    args: Prisma.piece_jointeCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Piece_jointeCountAggregateOutputType> | number;
                };
            };
        };
        projet: {
            payload: Prisma.$projetPayload<ExtArgs>;
            fields: Prisma.projetFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.projetFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.projetFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>;
                };
                findFirst: {
                    args: Prisma.projetFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.projetFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>;
                };
                findMany: {
                    args: Prisma.projetFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>[];
                };
                create: {
                    args: Prisma.projetCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>;
                };
                createMany: {
                    args: Prisma.projetCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.projetCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>[];
                };
                delete: {
                    args: Prisma.projetDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>;
                };
                update: {
                    args: Prisma.projetUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>;
                };
                deleteMany: {
                    args: Prisma.projetDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.projetUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.projetUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>[];
                };
                upsert: {
                    args: Prisma.projetUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$projetPayload>;
                };
                aggregate: {
                    args: Prisma.ProjetAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateProjet>;
                };
                groupBy: {
                    args: Prisma.projetGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.ProjetGroupByOutputType>[];
                };
                count: {
                    args: Prisma.projetCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.ProjetCountAggregateOutputType> | number;
                };
            };
        };
        rapport: {
            payload: Prisma.$rapportPayload<ExtArgs>;
            fields: Prisma.rapportFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.rapportFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.rapportFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>;
                };
                findFirst: {
                    args: Prisma.rapportFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.rapportFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>;
                };
                findMany: {
                    args: Prisma.rapportFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>[];
                };
                create: {
                    args: Prisma.rapportCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>;
                };
                createMany: {
                    args: Prisma.rapportCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.rapportCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>[];
                };
                delete: {
                    args: Prisma.rapportDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>;
                };
                update: {
                    args: Prisma.rapportUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>;
                };
                deleteMany: {
                    args: Prisma.rapportDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.rapportUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.rapportUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>[];
                };
                upsert: {
                    args: Prisma.rapportUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rapportPayload>;
                };
                aggregate: {
                    args: Prisma.RapportAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateRapport>;
                };
                groupBy: {
                    args: Prisma.rapportGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.RapportGroupByOutputType>[];
                };
                count: {
                    args: Prisma.rapportCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.RapportCountAggregateOutputType> | number;
                };
            };
        };
        role: {
            payload: Prisma.$rolePayload<ExtArgs>;
            fields: Prisma.roleFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.roleFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.roleFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>;
                };
                findFirst: {
                    args: Prisma.roleFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.roleFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>;
                };
                findMany: {
                    args: Prisma.roleFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>[];
                };
                create: {
                    args: Prisma.roleCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>;
                };
                createMany: {
                    args: Prisma.roleCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.roleCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>[];
                };
                delete: {
                    args: Prisma.roleDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>;
                };
                update: {
                    args: Prisma.roleUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>;
                };
                deleteMany: {
                    args: Prisma.roleDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.roleUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.roleUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>[];
                };
                upsert: {
                    args: Prisma.roleUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$rolePayload>;
                };
                aggregate: {
                    args: Prisma.RoleAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateRole>;
                };
                groupBy: {
                    args: Prisma.roleGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.RoleGroupByOutputType>[];
                };
                count: {
                    args: Prisma.roleCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.RoleCountAggregateOutputType> | number;
                };
            };
        };
        role_permission: {
            payload: Prisma.$role_permissionPayload<ExtArgs>;
            fields: Prisma.role_permissionFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.role_permissionFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.role_permissionFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>;
                };
                findFirst: {
                    args: Prisma.role_permissionFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.role_permissionFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>;
                };
                findMany: {
                    args: Prisma.role_permissionFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>[];
                };
                create: {
                    args: Prisma.role_permissionCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>;
                };
                createMany: {
                    args: Prisma.role_permissionCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.role_permissionCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>[];
                };
                delete: {
                    args: Prisma.role_permissionDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>;
                };
                update: {
                    args: Prisma.role_permissionUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>;
                };
                deleteMany: {
                    args: Prisma.role_permissionDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.role_permissionUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.role_permissionUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>[];
                };
                upsert: {
                    args: Prisma.role_permissionUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$role_permissionPayload>;
                };
                aggregate: {
                    args: Prisma.Role_permissionAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateRole_permission>;
                };
                groupBy: {
                    args: Prisma.role_permissionGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Role_permissionGroupByOutputType>[];
                };
                count: {
                    args: Prisma.role_permissionCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Role_permissionCountAggregateOutputType> | number;
                };
            };
        };
        session: {
            payload: Prisma.$sessionPayload<ExtArgs>;
            fields: Prisma.sessionFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.sessionFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.sessionFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>;
                };
                findFirst: {
                    args: Prisma.sessionFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.sessionFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>;
                };
                findMany: {
                    args: Prisma.sessionFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>[];
                };
                create: {
                    args: Prisma.sessionCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>;
                };
                createMany: {
                    args: Prisma.sessionCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.sessionCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>[];
                };
                delete: {
                    args: Prisma.sessionDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>;
                };
                update: {
                    args: Prisma.sessionUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>;
                };
                deleteMany: {
                    args: Prisma.sessionDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.sessionUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.sessionUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>[];
                };
                upsert: {
                    args: Prisma.sessionUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$sessionPayload>;
                };
                aggregate: {
                    args: Prisma.SessionAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateSession>;
                };
                groupBy: {
                    args: Prisma.sessionGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.SessionGroupByOutputType>[];
                };
                count: {
                    args: Prisma.sessionCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.SessionCountAggregateOutputType> | number;
                };
            };
        };
        tache: {
            payload: Prisma.$tachePayload<ExtArgs>;
            fields: Prisma.tacheFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.tacheFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.tacheFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>;
                };
                findFirst: {
                    args: Prisma.tacheFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.tacheFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>;
                };
                findMany: {
                    args: Prisma.tacheFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>[];
                };
                create: {
                    args: Prisma.tacheCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>;
                };
                createMany: {
                    args: Prisma.tacheCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.tacheCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>[];
                };
                delete: {
                    args: Prisma.tacheDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>;
                };
                update: {
                    args: Prisma.tacheUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>;
                };
                deleteMany: {
                    args: Prisma.tacheDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.tacheUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.tacheUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>[];
                };
                upsert: {
                    args: Prisma.tacheUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$tachePayload>;
                };
                aggregate: {
                    args: Prisma.TacheAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateTache>;
                };
                groupBy: {
                    args: Prisma.tacheGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.TacheGroupByOutputType>[];
                };
                count: {
                    args: Prisma.tacheCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.TacheCountAggregateOutputType> | number;
                };
            };
        };
        transfert_tache: {
            payload: Prisma.$transfert_tachePayload<ExtArgs>;
            fields: Prisma.transfert_tacheFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.transfert_tacheFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.transfert_tacheFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>;
                };
                findFirst: {
                    args: Prisma.transfert_tacheFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.transfert_tacheFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>;
                };
                findMany: {
                    args: Prisma.transfert_tacheFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>[];
                };
                create: {
                    args: Prisma.transfert_tacheCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>;
                };
                createMany: {
                    args: Prisma.transfert_tacheCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.transfert_tacheCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>[];
                };
                delete: {
                    args: Prisma.transfert_tacheDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>;
                };
                update: {
                    args: Prisma.transfert_tacheUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>;
                };
                deleteMany: {
                    args: Prisma.transfert_tacheDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.transfert_tacheUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.transfert_tacheUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>[];
                };
                upsert: {
                    args: Prisma.transfert_tacheUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$transfert_tachePayload>;
                };
                aggregate: {
                    args: Prisma.Transfert_tacheAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateTransfert_tache>;
                };
                groupBy: {
                    args: Prisma.transfert_tacheGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Transfert_tacheGroupByOutputType>[];
                };
                count: {
                    args: Prisma.transfert_tacheCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.Transfert_tacheCountAggregateOutputType> | number;
                };
            };
        };
        utilisateur: {
            payload: Prisma.$utilisateurPayload<ExtArgs>;
            fields: Prisma.utilisateurFieldRefs;
            operations: {
                findUnique: {
                    args: Prisma.utilisateurFindUniqueArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload> | null;
                };
                findUniqueOrThrow: {
                    args: Prisma.utilisateurFindUniqueOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>;
                };
                findFirst: {
                    args: Prisma.utilisateurFindFirstArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload> | null;
                };
                findFirstOrThrow: {
                    args: Prisma.utilisateurFindFirstOrThrowArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>;
                };
                findMany: {
                    args: Prisma.utilisateurFindManyArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>[];
                };
                create: {
                    args: Prisma.utilisateurCreateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>;
                };
                createMany: {
                    args: Prisma.utilisateurCreateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                createManyAndReturn: {
                    args: Prisma.utilisateurCreateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>[];
                };
                delete: {
                    args: Prisma.utilisateurDeleteArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>;
                };
                update: {
                    args: Prisma.utilisateurUpdateArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>;
                };
                deleteMany: {
                    args: Prisma.utilisateurDeleteManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateMany: {
                    args: Prisma.utilisateurUpdateManyArgs<ExtArgs>;
                    result: BatchPayload;
                };
                updateManyAndReturn: {
                    args: Prisma.utilisateurUpdateManyAndReturnArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>[];
                };
                upsert: {
                    args: Prisma.utilisateurUpsertArgs<ExtArgs>;
                    result: runtime.Types.Utils.PayloadToResult<Prisma.$utilisateurPayload>;
                };
                aggregate: {
                    args: Prisma.UtilisateurAggregateArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.AggregateUtilisateur>;
                };
                groupBy: {
                    args: Prisma.utilisateurGroupByArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.UtilisateurGroupByOutputType>[];
                };
                count: {
                    args: Prisma.utilisateurCountArgs<ExtArgs>;
                    result: runtime.Types.Utils.Optional<Prisma.UtilisateurCountAggregateOutputType> | number;
                };
            };
        };
    };
} & {
    other: {
        payload: any;
        operations: {
            $executeRaw: {
                args: [query: TemplateStringsArray | Sql, ...values: any[]];
                result: any;
            };
            $executeRawUnsafe: {
                args: [query: string, ...values: any[]];
                result: any;
            };
            $queryRaw: {
                args: [query: TemplateStringsArray | Sql, ...values: any[]];
                result: any;
            };
            $queryRawUnsafe: {
                args: [query: string, ...values: any[]];
                result: any;
            };
        };
    };
};
export declare const TransactionIsolationLevel: {
    readonly ReadUncommitted: "ReadUncommitted";
    readonly ReadCommitted: "ReadCommitted";
    readonly RepeatableRead: "RepeatableRead";
    readonly Serializable: "Serializable";
};
export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel];
export declare const ActiviteScalarFieldEnum: {
    readonly id_activite: "id_activite";
    readonly id_tache: "id_tache";
    readonly id_utilisateur: "id_utilisateur";
    readonly description: "description";
    readonly temps_passe: "temps_passe";
    readonly date_activite: "date_activite";
};
export type ActiviteScalarFieldEnum = (typeof ActiviteScalarFieldEnum)[keyof typeof ActiviteScalarFieldEnum];
export declare const CommentaireScalarFieldEnum: {
    readonly id_commentaire: "id_commentaire";
    readonly id_tache: "id_tache";
    readonly id_utilisateur: "id_utilisateur";
    readonly contenu: "contenu";
    readonly date_creation: "date_creation";
    readonly date_modification: "date_modification";
    readonly statut: "statut";
};
export type CommentaireScalarFieldEnum = (typeof CommentaireScalarFieldEnum)[keyof typeof CommentaireScalarFieldEnum];
export declare const EntrepriseScalarFieldEnum: {
    readonly id_entreprise: "id_entreprise";
    readonly nom: "nom";
    readonly logo: "logo";
    readonly adresse: "adresse";
    readonly email: "email";
    readonly telephone: "telephone";
    readonly informations_generales: "informations_generales";
    readonly date_creation: "date_creation";
};
export type EntrepriseScalarFieldEnum = (typeof EntrepriseScalarFieldEnum)[keyof typeof EntrepriseScalarFieldEnum];
export declare const EquipeScalarFieldEnum: {
    readonly id_equipe: "id_equipe";
    readonly nom_equipe: "nom_equipe";
    readonly description: "description";
    readonly statut: "statut";
    readonly date_creation: "date_creation";
};
export type EquipeScalarFieldEnum = (typeof EquipeScalarFieldEnum)[keyof typeof EquipeScalarFieldEnum];
export declare const Historique_tacheScalarFieldEnum: {
    readonly id_historique: "id_historique";
    readonly id_tache: "id_tache";
    readonly id_utilisateur: "id_utilisateur";
    readonly action: "action";
    readonly description: "description";
    readonly date_action: "date_action";
};
export type Historique_tacheScalarFieldEnum = (typeof Historique_tacheScalarFieldEnum)[keyof typeof Historique_tacheScalarFieldEnum];
export declare const NotificationScalarFieldEnum: {
    readonly id_notification: "id_notification";
    readonly id_utilisateur: "id_utilisateur";
    readonly type: "type";
    readonly message: "message";
    readonly est_lue: "est_lue";
    readonly date_creation: "date_creation";
    readonly date_lecture: "date_lecture";
};
export type NotificationScalarFieldEnum = (typeof NotificationScalarFieldEnum)[keyof typeof NotificationScalarFieldEnum];
export declare const Participation_projetScalarFieldEnum: {
    readonly id_projet: "id_projet";
    readonly id_utilisateur: "id_utilisateur";
    readonly date_participation: "date_participation";
    readonly statut: "statut";
};
export type Participation_projetScalarFieldEnum = (typeof Participation_projetScalarFieldEnum)[keyof typeof Participation_projetScalarFieldEnum];
export declare const PermissionScalarFieldEnum: {
    readonly id_permission: "id_permission";
    readonly code_permission: "code_permission";
    readonly nom_permission: "nom_permission";
    readonly description: "description";
};
export type PermissionScalarFieldEnum = (typeof PermissionScalarFieldEnum)[keyof typeof PermissionScalarFieldEnum];
export declare const Piece_jointeScalarFieldEnum: {
    readonly id_piece_jointe: "id_piece_jointe";
    readonly id_tache: "id_tache";
    readonly id_commentaire: "id_commentaire";
    readonly id_utilisateur: "id_utilisateur";
    readonly nom_fichier: "nom_fichier";
    readonly chemin_fichier: "chemin_fichier";
    readonly type_fichier: "type_fichier";
    readonly taille: "taille";
    readonly date_ajout: "date_ajout";
};
export type Piece_jointeScalarFieldEnum = (typeof Piece_jointeScalarFieldEnum)[keyof typeof Piece_jointeScalarFieldEnum];
export declare const ProjetScalarFieldEnum: {
    readonly id_projet: "id_projet";
    readonly id_equipe: "id_equipe";
    readonly id_chef_projet: "id_chef_projet";
    readonly nom_projet: "nom_projet";
    readonly code_projet: "code_projet";
    readonly description: "description";
    readonly priorite: "priorite";
    readonly etat: "etat";
    readonly date_debut: "date_debut";
    readonly date_fin_prevue: "date_fin_prevue";
    readonly date_fin_reelle: "date_fin_reelle";
    readonly statut: "statut";
    readonly date_creation: "date_creation";
};
export type ProjetScalarFieldEnum = (typeof ProjetScalarFieldEnum)[keyof typeof ProjetScalarFieldEnum];
export declare const RapportScalarFieldEnum: {
    readonly id_rapport: "id_rapport";
    readonly id_utilisateur: "id_utilisateur";
    readonly type: "type";
    readonly format: "format";
    readonly periode_debut: "periode_debut";
    readonly periode_fin: "periode_fin";
    readonly chemin_fichier: "chemin_fichier";
    readonly date_generation: "date_generation";
};
export type RapportScalarFieldEnum = (typeof RapportScalarFieldEnum)[keyof typeof RapportScalarFieldEnum];
export declare const RoleScalarFieldEnum: {
    readonly id_role: "id_role";
    readonly nom_role: "nom_role";
    readonly description: "description";
};
export type RoleScalarFieldEnum = (typeof RoleScalarFieldEnum)[keyof typeof RoleScalarFieldEnum];
export declare const Role_permissionScalarFieldEnum: {
    readonly id_role: "id_role";
    readonly id_permission: "id_permission";
};
export type Role_permissionScalarFieldEnum = (typeof Role_permissionScalarFieldEnum)[keyof typeof Role_permissionScalarFieldEnum];
export declare const SessionScalarFieldEnum: {
    readonly id_session: "id_session";
    readonly id_utilisateur: "id_utilisateur";
    readonly token_hash: "token_hash";
    readonly date_connexion: "date_connexion";
    readonly derniere_activite: "derniere_activite";
    readonly date_deconnexion: "date_deconnexion";
    readonly statut: "statut";
};
export type SessionScalarFieldEnum = (typeof SessionScalarFieldEnum)[keyof typeof SessionScalarFieldEnum];
export declare const TacheScalarFieldEnum: {
    readonly id_tache: "id_tache";
    readonly id_projet: "id_projet";
    readonly id_responsable: "id_responsable";
    readonly id_equipe: "id_equipe";
    readonly titre: "titre";
    readonly description: "description";
    readonly priorite: "priorite";
    readonly etat: "etat";
    readonly temps_estime: "temps_estime";
    readonly date_creation: "date_creation";
    readonly date_debut: "date_debut";
    readonly date_limite: "date_limite";
    readonly date_terminaison: "date_terminaison";
};
export type TacheScalarFieldEnum = (typeof TacheScalarFieldEnum)[keyof typeof TacheScalarFieldEnum];
export declare const Transfert_tacheScalarFieldEnum: {
    readonly id_transfert: "id_transfert";
    readonly id_tache: "id_tache";
    readonly ancien_responsable: "ancien_responsable";
    readonly nouveau_responsable: "nouveau_responsable";
    readonly ancienne_equipe: "ancienne_equipe";
    readonly nouvelle_equipe: "nouvelle_equipe";
    readonly utilisateur_transfert: "utilisateur_transfert";
    readonly motif: "motif";
    readonly date_transfert: "date_transfert";
};
export type Transfert_tacheScalarFieldEnum = (typeof Transfert_tacheScalarFieldEnum)[keyof typeof Transfert_tacheScalarFieldEnum];
export declare const UtilisateurScalarFieldEnum: {
    readonly id_utilisateur: "id_utilisateur";
    readonly id_entreprise: "id_entreprise";
    readonly id_role: "id_role";
    readonly id_equipe: "id_equipe";
    readonly nom: "nom";
    readonly prenom: "prenom";
    readonly email: "email";
    readonly mot_de_passe: "mot_de_passe";
    readonly telephone: "telephone";
    readonly poste: "poste";
    readonly theme: "theme";
    readonly statut: "statut";
    readonly capacite_hebdomadaire_heures: "capacite_hebdomadaire_heures";
    readonly tentatives_echec: "tentatives_echec";
    readonly verrouille_jusqu_a: "verrouille_jusqu_a";
    readonly date_creation: "date_creation";
    readonly date_modification: "date_modification";
};
export type UtilisateurScalarFieldEnum = (typeof UtilisateurScalarFieldEnum)[keyof typeof UtilisateurScalarFieldEnum];
export declare const SortOrder: {
    readonly asc: "asc";
    readonly desc: "desc";
};
export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder];
export declare const QueryMode: {
    readonly default: "default";
    readonly insensitive: "insensitive";
};
export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode];
export declare const NullsOrder: {
    readonly first: "first";
    readonly last: "last";
};
export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder];
export type BigIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BigInt'>;
export type ListBigIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BigInt[]'>;
export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>;
export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>;
export type DecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal'>;
export type ListDecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal[]'>;
export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>;
export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>;
export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>;
export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>;
export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>;
export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>;
export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>;
export type BatchPayload = {
    count: number;
};
export declare const defineExtension: runtime.Types.Extensions.ExtendsHook<"define", TypeMapCb, runtime.Types.Extensions.DefaultArgs>;
export type DefaultPrismaClient = PrismaClient;
export type ErrorFormat = 'pretty' | 'colorless' | 'minimal';
export interface PrismaClientBaseOptions {
    errorFormat?: ErrorFormat;
    log?: (LogLevel | LogDefinition)[];
    transactionOptions?: {
        maxWait?: number;
        timeout?: number;
        isolationLevel?: TransactionIsolationLevel;
    };
    omit?: GlobalOmitConfig;
    comments?: runtime.SqlCommenterPlugin[];
    queryPlanCacheMaxSize?: number;
}
export interface PrismaClientOptionsWithAccelerateUrl extends PrismaClientBaseOptions {
    accelerateUrl: string;
    adapter?: never;
}
export interface PrismaClientOptionsWithAdapter extends PrismaClientBaseOptions {
    adapter: runtime.SqlDriverAdapterFactory;
    accelerateUrl?: never;
}
export type PrismaClientOptions = PrismaClientOptionsWithAccelerateUrl | PrismaClientOptionsWithAdapter;
export type GlobalOmitConfig = {
    activite?: Prisma.activiteOmit;
    commentaire?: Prisma.commentaireOmit;
    entreprise?: Prisma.entrepriseOmit;
    equipe?: Prisma.equipeOmit;
    historique_tache?: Prisma.historique_tacheOmit;
    notification?: Prisma.notificationOmit;
    participation_projet?: Prisma.participation_projetOmit;
    permission?: Prisma.permissionOmit;
    piece_jointe?: Prisma.piece_jointeOmit;
    projet?: Prisma.projetOmit;
    rapport?: Prisma.rapportOmit;
    role?: Prisma.roleOmit;
    role_permission?: Prisma.role_permissionOmit;
    session?: Prisma.sessionOmit;
    tache?: Prisma.tacheOmit;
    transfert_tache?: Prisma.transfert_tacheOmit;
    utilisateur?: Prisma.utilisateurOmit;
};
export type LogLevel = 'info' | 'query' | 'warn' | 'error';
export type LogDefinition = {
    level: LogLevel;
    emit: 'stdout' | 'event';
};
export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;
export type GetLogType<T> = CheckIsLogLevel<T extends LogDefinition ? T['level'] : T>;
export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition> ? GetLogType<T[number]> : never;
export type QueryEvent = {
    timestamp: Date;
    query: string;
    params: string;
    duration: number;
    target: string;
};
export type LogEvent = {
    timestamp: Date;
    message: string;
    target: string;
};
export type PrismaAction = 'findUnique' | 'findUniqueOrThrow' | 'findMany' | 'findFirst' | 'findFirstOrThrow' | 'create' | 'createMany' | 'createManyAndReturn' | 'update' | 'updateMany' | 'updateManyAndReturn' | 'upsert' | 'delete' | 'deleteMany' | 'executeRaw' | 'queryRaw' | 'aggregate' | 'count' | 'runCommandRaw' | 'findRaw' | 'groupBy';
export type TransactionClient = Omit<DefaultPrismaClient, runtime.ITXClientDenyList>;
