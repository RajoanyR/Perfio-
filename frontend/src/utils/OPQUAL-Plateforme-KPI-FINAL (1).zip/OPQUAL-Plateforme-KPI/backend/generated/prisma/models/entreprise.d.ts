import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type entrepriseModel = runtime.Types.Result.DefaultSelection<Prisma.$entreprisePayload>;
export type AggregateEntreprise = {
    _count: EntrepriseCountAggregateOutputType | null;
    _avg: EntrepriseAvgAggregateOutputType | null;
    _sum: EntrepriseSumAggregateOutputType | null;
    _min: EntrepriseMinAggregateOutputType | null;
    _max: EntrepriseMaxAggregateOutputType | null;
};
export type EntrepriseAvgAggregateOutputType = {
    id_entreprise: number | null;
};
export type EntrepriseSumAggregateOutputType = {
    id_entreprise: bigint | null;
};
export type EntrepriseMinAggregateOutputType = {
    id_entreprise: bigint | null;
    nom: string | null;
    logo: string | null;
    adresse: string | null;
    email: string | null;
    telephone: string | null;
    informations_generales: string | null;
    date_creation: Date | null;
};
export type EntrepriseMaxAggregateOutputType = {
    id_entreprise: bigint | null;
    nom: string | null;
    logo: string | null;
    adresse: string | null;
    email: string | null;
    telephone: string | null;
    informations_generales: string | null;
    date_creation: Date | null;
};
export type EntrepriseCountAggregateOutputType = {
    id_entreprise: number;
    nom: number;
    logo: number;
    adresse: number;
    email: number;
    telephone: number;
    informations_generales: number;
    date_creation: number;
    _all: number;
};
export type EntrepriseAvgAggregateInputType = {
    id_entreprise?: true;
};
export type EntrepriseSumAggregateInputType = {
    id_entreprise?: true;
};
export type EntrepriseMinAggregateInputType = {
    id_entreprise?: true;
    nom?: true;
    logo?: true;
    adresse?: true;
    email?: true;
    telephone?: true;
    informations_generales?: true;
    date_creation?: true;
};
export type EntrepriseMaxAggregateInputType = {
    id_entreprise?: true;
    nom?: true;
    logo?: true;
    adresse?: true;
    email?: true;
    telephone?: true;
    informations_generales?: true;
    date_creation?: true;
};
export type EntrepriseCountAggregateInputType = {
    id_entreprise?: true;
    nom?: true;
    logo?: true;
    adresse?: true;
    email?: true;
    telephone?: true;
    informations_generales?: true;
    date_creation?: true;
    _all?: true;
};
export type EntrepriseAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.entrepriseWhereInput;
    orderBy?: Prisma.entrepriseOrderByWithRelationInput | Prisma.entrepriseOrderByWithRelationInput[];
    cursor?: Prisma.entrepriseWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | EntrepriseCountAggregateInputType;
    _avg?: EntrepriseAvgAggregateInputType;
    _sum?: EntrepriseSumAggregateInputType;
    _min?: EntrepriseMinAggregateInputType;
    _max?: EntrepriseMaxAggregateInputType;
};
export type GetEntrepriseAggregateType<T extends EntrepriseAggregateArgs> = {
    [P in keyof T & keyof AggregateEntreprise]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateEntreprise[P]> : Prisma.GetScalarType<T[P], AggregateEntreprise[P]>;
};
export type entrepriseGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.entrepriseWhereInput;
    orderBy?: Prisma.entrepriseOrderByWithAggregationInput | Prisma.entrepriseOrderByWithAggregationInput[];
    by: Prisma.EntrepriseScalarFieldEnum[] | Prisma.EntrepriseScalarFieldEnum;
    having?: Prisma.entrepriseScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: EntrepriseCountAggregateInputType | true;
    _avg?: EntrepriseAvgAggregateInputType;
    _sum?: EntrepriseSumAggregateInputType;
    _min?: EntrepriseMinAggregateInputType;
    _max?: EntrepriseMaxAggregateInputType;
};
export type EntrepriseGroupByOutputType = {
    id_entreprise: bigint;
    nom: string;
    logo: string | null;
    adresse: string | null;
    email: string | null;
    telephone: string | null;
    informations_generales: string | null;
    date_creation: Date;
    _count: EntrepriseCountAggregateOutputType | null;
    _avg: EntrepriseAvgAggregateOutputType | null;
    _sum: EntrepriseSumAggregateOutputType | null;
    _min: EntrepriseMinAggregateOutputType | null;
    _max: EntrepriseMaxAggregateOutputType | null;
};
export type GetEntrepriseGroupByPayload<T extends entrepriseGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<EntrepriseGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof EntrepriseGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], EntrepriseGroupByOutputType[P]> : Prisma.GetScalarType<T[P], EntrepriseGroupByOutputType[P]>;
}>>;
export type entrepriseWhereInput = {
    AND?: Prisma.entrepriseWhereInput | Prisma.entrepriseWhereInput[];
    OR?: Prisma.entrepriseWhereInput[];
    NOT?: Prisma.entrepriseWhereInput | Prisma.entrepriseWhereInput[];
    id_entreprise?: Prisma.BigIntFilter<"entreprise"> | bigint | number;
    nom?: Prisma.StringFilter<"entreprise"> | string;
    logo?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    adresse?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    email?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    telephone?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    informations_generales?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    date_creation?: Prisma.DateTimeFilter<"entreprise"> | Date | string;
    utilisateur?: Prisma.UtilisateurListRelationFilter;
};
export type entrepriseOrderByWithRelationInput = {
    id_entreprise?: Prisma.SortOrder;
    nom?: Prisma.SortOrder;
    logo?: Prisma.SortOrderInput | Prisma.SortOrder;
    adresse?: Prisma.SortOrderInput | Prisma.SortOrder;
    email?: Prisma.SortOrderInput | Prisma.SortOrder;
    telephone?: Prisma.SortOrderInput | Prisma.SortOrder;
    informations_generales?: Prisma.SortOrderInput | Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    utilisateur?: Prisma.utilisateurOrderByRelationAggregateInput;
};
export type entrepriseWhereUniqueInput = Prisma.AtLeast<{
    id_entreprise?: bigint | number;
    nom?: string;
    AND?: Prisma.entrepriseWhereInput | Prisma.entrepriseWhereInput[];
    OR?: Prisma.entrepriseWhereInput[];
    NOT?: Prisma.entrepriseWhereInput | Prisma.entrepriseWhereInput[];
    logo?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    adresse?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    email?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    telephone?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    informations_generales?: Prisma.StringNullableFilter<"entreprise"> | string | null;
    date_creation?: Prisma.DateTimeFilter<"entreprise"> | Date | string;
    utilisateur?: Prisma.UtilisateurListRelationFilter;
}, "id_entreprise" | "nom">;
export type entrepriseOrderByWithAggregationInput = {
    id_entreprise?: Prisma.SortOrder;
    nom?: Prisma.SortOrder;
    logo?: Prisma.SortOrderInput | Prisma.SortOrder;
    adresse?: Prisma.SortOrderInput | Prisma.SortOrder;
    email?: Prisma.SortOrderInput | Prisma.SortOrder;
    telephone?: Prisma.SortOrderInput | Prisma.SortOrder;
    informations_generales?: Prisma.SortOrderInput | Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    _count?: Prisma.entrepriseCountOrderByAggregateInput;
    _avg?: Prisma.entrepriseAvgOrderByAggregateInput;
    _max?: Prisma.entrepriseMaxOrderByAggregateInput;
    _min?: Prisma.entrepriseMinOrderByAggregateInput;
    _sum?: Prisma.entrepriseSumOrderByAggregateInput;
};
export type entrepriseScalarWhereWithAggregatesInput = {
    AND?: Prisma.entrepriseScalarWhereWithAggregatesInput | Prisma.entrepriseScalarWhereWithAggregatesInput[];
    OR?: Prisma.entrepriseScalarWhereWithAggregatesInput[];
    NOT?: Prisma.entrepriseScalarWhereWithAggregatesInput | Prisma.entrepriseScalarWhereWithAggregatesInput[];
    id_entreprise?: Prisma.BigIntWithAggregatesFilter<"entreprise"> | bigint | number;
    nom?: Prisma.StringWithAggregatesFilter<"entreprise"> | string;
    logo?: Prisma.StringNullableWithAggregatesFilter<"entreprise"> | string | null;
    adresse?: Prisma.StringNullableWithAggregatesFilter<"entreprise"> | string | null;
    email?: Prisma.StringNullableWithAggregatesFilter<"entreprise"> | string | null;
    telephone?: Prisma.StringNullableWithAggregatesFilter<"entreprise"> | string | null;
    informations_generales?: Prisma.StringNullableWithAggregatesFilter<"entreprise"> | string | null;
    date_creation?: Prisma.DateTimeWithAggregatesFilter<"entreprise"> | Date | string;
};
export type entrepriseCreateInput = {
    id_entreprise?: bigint | number;
    nom: string;
    logo?: string | null;
    adresse?: string | null;
    email?: string | null;
    telephone?: string | null;
    informations_generales?: string | null;
    date_creation?: Date | string;
    utilisateur?: Prisma.utilisateurCreateNestedManyWithoutEntrepriseInput;
};
export type entrepriseUncheckedCreateInput = {
    id_entreprise?: bigint | number;
    nom: string;
    logo?: string | null;
    adresse?: string | null;
    email?: string | null;
    telephone?: string | null;
    informations_generales?: string | null;
    date_creation?: Date | string;
    utilisateur?: Prisma.utilisateurUncheckedCreateNestedManyWithoutEntrepriseInput;
};
export type entrepriseUpdateInput = {
    id_entreprise?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom?: Prisma.StringFieldUpdateOperationsInput | string;
    logo?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    adresse?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    email?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    telephone?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    informations_generales?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    utilisateur?: Prisma.utilisateurUpdateManyWithoutEntrepriseNestedInput;
};
export type entrepriseUncheckedUpdateInput = {
    id_entreprise?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom?: Prisma.StringFieldUpdateOperationsInput | string;
    logo?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    adresse?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    email?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    telephone?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    informations_generales?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    utilisateur?: Prisma.utilisateurUncheckedUpdateManyWithoutEntrepriseNestedInput;
};
export type entrepriseCreateManyInput = {
    id_entreprise?: bigint | number;
    nom: string;
    logo?: string | null;
    adresse?: string | null;
    email?: string | null;
    telephone?: string | null;
    informations_generales?: string | null;
    date_creation?: Date | string;
};
export type entrepriseUpdateManyMutationInput = {
    id_entreprise?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom?: Prisma.StringFieldUpdateOperationsInput | string;
    logo?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    adresse?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    email?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    telephone?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    informations_generales?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type entrepriseUncheckedUpdateManyInput = {
    id_entreprise?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom?: Prisma.StringFieldUpdateOperationsInput | string;
    logo?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    adresse?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    email?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    telephone?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    informations_generales?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type entrepriseCountOrderByAggregateInput = {
    id_entreprise?: Prisma.SortOrder;
    nom?: Prisma.SortOrder;
    logo?: Prisma.SortOrder;
    adresse?: Prisma.SortOrder;
    email?: Prisma.SortOrder;
    telephone?: Prisma.SortOrder;
    informations_generales?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type entrepriseAvgOrderByAggregateInput = {
    id_entreprise?: Prisma.SortOrder;
};
export type entrepriseMaxOrderByAggregateInput = {
    id_entreprise?: Prisma.SortOrder;
    nom?: Prisma.SortOrder;
    logo?: Prisma.SortOrder;
    adresse?: Prisma.SortOrder;
    email?: Prisma.SortOrder;
    telephone?: Prisma.SortOrder;
    informations_generales?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type entrepriseMinOrderByAggregateInput = {
    id_entreprise?: Prisma.SortOrder;
    nom?: Prisma.SortOrder;
    logo?: Prisma.SortOrder;
    adresse?: Prisma.SortOrder;
    email?: Prisma.SortOrder;
    telephone?: Prisma.SortOrder;
    informations_generales?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type entrepriseSumOrderByAggregateInput = {
    id_entreprise?: Prisma.SortOrder;
};
export type EntrepriseScalarRelationFilter = {
    is?: Prisma.entrepriseWhereInput;
    isNot?: Prisma.entrepriseWhereInput;
};
export type entrepriseCreateNestedOneWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.entrepriseCreateWithoutUtilisateurInput, Prisma.entrepriseUncheckedCreateWithoutUtilisateurInput>;
    connectOrCreate?: Prisma.entrepriseCreateOrConnectWithoutUtilisateurInput;
    connect?: Prisma.entrepriseWhereUniqueInput;
};
export type entrepriseUpdateOneRequiredWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.entrepriseCreateWithoutUtilisateurInput, Prisma.entrepriseUncheckedCreateWithoutUtilisateurInput>;
    connectOrCreate?: Prisma.entrepriseCreateOrConnectWithoutUtilisateurInput;
    upsert?: Prisma.entrepriseUpsertWithoutUtilisateurInput;
    connect?: Prisma.entrepriseWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.entrepriseUpdateToOneWithWhereWithoutUtilisateurInput, Prisma.entrepriseUpdateWithoutUtilisateurInput>, Prisma.entrepriseUncheckedUpdateWithoutUtilisateurInput>;
};
export type entrepriseCreateWithoutUtilisateurInput = {
    id_entreprise?: bigint | number;
    nom: string;
    logo?: string | null;
    adresse?: string | null;
    email?: string | null;
    telephone?: string | null;
    informations_generales?: string | null;
    date_creation?: Date | string;
};
export type entrepriseUncheckedCreateWithoutUtilisateurInput = {
    id_entreprise?: bigint | number;
    nom: string;
    logo?: string | null;
    adresse?: string | null;
    email?: string | null;
    telephone?: string | null;
    informations_generales?: string | null;
    date_creation?: Date | string;
};
export type entrepriseCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.entrepriseWhereUniqueInput;
    create: Prisma.XOR<Prisma.entrepriseCreateWithoutUtilisateurInput, Prisma.entrepriseUncheckedCreateWithoutUtilisateurInput>;
};
export type entrepriseUpsertWithoutUtilisateurInput = {
    update: Prisma.XOR<Prisma.entrepriseUpdateWithoutUtilisateurInput, Prisma.entrepriseUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.entrepriseCreateWithoutUtilisateurInput, Prisma.entrepriseUncheckedCreateWithoutUtilisateurInput>;
    where?: Prisma.entrepriseWhereInput;
};
export type entrepriseUpdateToOneWithWhereWithoutUtilisateurInput = {
    where?: Prisma.entrepriseWhereInput;
    data: Prisma.XOR<Prisma.entrepriseUpdateWithoutUtilisateurInput, Prisma.entrepriseUncheckedUpdateWithoutUtilisateurInput>;
};
export type entrepriseUpdateWithoutUtilisateurInput = {
    id_entreprise?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom?: Prisma.StringFieldUpdateOperationsInput | string;
    logo?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    adresse?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    email?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    telephone?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    informations_generales?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type entrepriseUncheckedUpdateWithoutUtilisateurInput = {
    id_entreprise?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom?: Prisma.StringFieldUpdateOperationsInput | string;
    logo?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    adresse?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    email?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    telephone?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    informations_generales?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type EntrepriseCountOutputType = {
    utilisateur: number;
};
export type EntrepriseCountOutputTypeSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | EntrepriseCountOutputTypeCountUtilisateurArgs;
};
export type EntrepriseCountOutputTypeDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.EntrepriseCountOutputTypeSelect<ExtArgs> | null;
};
export type EntrepriseCountOutputTypeCountUtilisateurArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.utilisateurWhereInput;
};
export type entrepriseSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_entreprise?: boolean;
    nom?: boolean;
    logo?: boolean;
    adresse?: boolean;
    email?: boolean;
    telephone?: boolean;
    informations_generales?: boolean;
    date_creation?: boolean;
    utilisateur?: boolean | Prisma.entreprise$utilisateurArgs<ExtArgs>;
    _count?: boolean | Prisma.EntrepriseCountOutputTypeDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["entreprise"]>;
export type entrepriseSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_entreprise?: boolean;
    nom?: boolean;
    logo?: boolean;
    adresse?: boolean;
    email?: boolean;
    telephone?: boolean;
    informations_generales?: boolean;
    date_creation?: boolean;
}, ExtArgs["result"]["entreprise"]>;
export type entrepriseSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_entreprise?: boolean;
    nom?: boolean;
    logo?: boolean;
    adresse?: boolean;
    email?: boolean;
    telephone?: boolean;
    informations_generales?: boolean;
    date_creation?: boolean;
}, ExtArgs["result"]["entreprise"]>;
export type entrepriseSelectScalar = {
    id_entreprise?: boolean;
    nom?: boolean;
    logo?: boolean;
    adresse?: boolean;
    email?: boolean;
    telephone?: boolean;
    informations_generales?: boolean;
    date_creation?: boolean;
};
export type entrepriseOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_entreprise" | "nom" | "logo" | "adresse" | "email" | "telephone" | "informations_generales" | "date_creation", ExtArgs["result"]["entreprise"]>;
export type entrepriseInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.entreprise$utilisateurArgs<ExtArgs>;
    _count?: boolean | Prisma.EntrepriseCountOutputTypeDefaultArgs<ExtArgs>;
};
export type entrepriseIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {};
export type entrepriseIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {};
export type $entreprisePayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "entreprise";
    objects: {
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>[];
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_entreprise: bigint;
        nom: string;
        logo: string | null;
        adresse: string | null;
        email: string | null;
        telephone: string | null;
        informations_generales: string | null;
        date_creation: Date;
    }, ExtArgs["result"]["entreprise"]>;
    composites: {};
};
export type entrepriseGetPayload<S extends boolean | null | undefined | entrepriseDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$entreprisePayload, S>;
export type entrepriseCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<entrepriseFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: EntrepriseCountAggregateInputType | true;
};
export interface entrepriseDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['entreprise'];
        meta: {
            name: 'entreprise';
        };
    };
    findUnique<T extends entrepriseFindUniqueArgs>(args: Prisma.SelectSubset<T, entrepriseFindUniqueArgs<ExtArgs>>): Prisma.Prisma__entrepriseClient<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends entrepriseFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, entrepriseFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__entrepriseClient<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends entrepriseFindFirstArgs>(args?: Prisma.SelectSubset<T, entrepriseFindFirstArgs<ExtArgs>>): Prisma.Prisma__entrepriseClient<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends entrepriseFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, entrepriseFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__entrepriseClient<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends entrepriseFindManyArgs>(args?: Prisma.SelectSubset<T, entrepriseFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends entrepriseCreateArgs>(args: Prisma.SelectSubset<T, entrepriseCreateArgs<ExtArgs>>): Prisma.Prisma__entrepriseClient<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends entrepriseCreateManyArgs>(args?: Prisma.SelectSubset<T, entrepriseCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends entrepriseCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, entrepriseCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends entrepriseDeleteArgs>(args: Prisma.SelectSubset<T, entrepriseDeleteArgs<ExtArgs>>): Prisma.Prisma__entrepriseClient<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends entrepriseUpdateArgs>(args: Prisma.SelectSubset<T, entrepriseUpdateArgs<ExtArgs>>): Prisma.Prisma__entrepriseClient<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends entrepriseDeleteManyArgs>(args?: Prisma.SelectSubset<T, entrepriseDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends entrepriseUpdateManyArgs>(args: Prisma.SelectSubset<T, entrepriseUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends entrepriseUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, entrepriseUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends entrepriseUpsertArgs>(args: Prisma.SelectSubset<T, entrepriseUpsertArgs<ExtArgs>>): Prisma.Prisma__entrepriseClient<runtime.Types.Result.GetResult<Prisma.$entreprisePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends entrepriseCountArgs>(args?: Prisma.Subset<T, entrepriseCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], EntrepriseCountAggregateOutputType> : number>;
    aggregate<T extends EntrepriseAggregateArgs>(args: Prisma.Subset<T, EntrepriseAggregateArgs>): Prisma.PrismaPromise<GetEntrepriseAggregateType<T>>;
    groupBy<T extends entrepriseGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: entrepriseGroupByArgs['orderBy'];
    } : {
        orderBy?: entrepriseGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, entrepriseGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetEntrepriseGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: entrepriseFieldRefs;
}
export interface Prisma__entrepriseClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    utilisateur<T extends Prisma.entreprise$utilisateurArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.entreprise$utilisateurArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface entrepriseFieldRefs {
    readonly id_entreprise: Prisma.FieldRef<"entreprise", 'BigInt'>;
    readonly nom: Prisma.FieldRef<"entreprise", 'String'>;
    readonly logo: Prisma.FieldRef<"entreprise", 'String'>;
    readonly adresse: Prisma.FieldRef<"entreprise", 'String'>;
    readonly email: Prisma.FieldRef<"entreprise", 'String'>;
    readonly telephone: Prisma.FieldRef<"entreprise", 'String'>;
    readonly informations_generales: Prisma.FieldRef<"entreprise", 'String'>;
    readonly date_creation: Prisma.FieldRef<"entreprise", 'DateTime'>;
}
export type entrepriseFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    where: Prisma.entrepriseWhereUniqueInput;
};
export type entrepriseFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    where: Prisma.entrepriseWhereUniqueInput;
};
export type entrepriseFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    where?: Prisma.entrepriseWhereInput;
    orderBy?: Prisma.entrepriseOrderByWithRelationInput | Prisma.entrepriseOrderByWithRelationInput[];
    cursor?: Prisma.entrepriseWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.EntrepriseScalarFieldEnum | Prisma.EntrepriseScalarFieldEnum[];
};
export type entrepriseFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    where?: Prisma.entrepriseWhereInput;
    orderBy?: Prisma.entrepriseOrderByWithRelationInput | Prisma.entrepriseOrderByWithRelationInput[];
    cursor?: Prisma.entrepriseWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.EntrepriseScalarFieldEnum | Prisma.EntrepriseScalarFieldEnum[];
};
export type entrepriseFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    where?: Prisma.entrepriseWhereInput;
    orderBy?: Prisma.entrepriseOrderByWithRelationInput | Prisma.entrepriseOrderByWithRelationInput[];
    cursor?: Prisma.entrepriseWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.EntrepriseScalarFieldEnum | Prisma.EntrepriseScalarFieldEnum[];
};
export type entrepriseCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.entrepriseCreateInput, Prisma.entrepriseUncheckedCreateInput>;
};
export type entrepriseCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.entrepriseCreateManyInput | Prisma.entrepriseCreateManyInput[];
    skipDuplicates?: boolean;
};
export type entrepriseCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    data: Prisma.entrepriseCreateManyInput | Prisma.entrepriseCreateManyInput[];
    skipDuplicates?: boolean;
};
export type entrepriseUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.entrepriseUpdateInput, Prisma.entrepriseUncheckedUpdateInput>;
    where: Prisma.entrepriseWhereUniqueInput;
};
export type entrepriseUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.entrepriseUpdateManyMutationInput, Prisma.entrepriseUncheckedUpdateManyInput>;
    where?: Prisma.entrepriseWhereInput;
    limit?: number;
};
export type entrepriseUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.entrepriseUpdateManyMutationInput, Prisma.entrepriseUncheckedUpdateManyInput>;
    where?: Prisma.entrepriseWhereInput;
    limit?: number;
};
export type entrepriseUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    where: Prisma.entrepriseWhereUniqueInput;
    create: Prisma.XOR<Prisma.entrepriseCreateInput, Prisma.entrepriseUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.entrepriseUpdateInput, Prisma.entrepriseUncheckedUpdateInput>;
};
export type entrepriseDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
    where: Prisma.entrepriseWhereUniqueInput;
};
export type entrepriseDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.entrepriseWhereInput;
    limit?: number;
};
export type entreprise$utilisateurArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.utilisateurSelect<ExtArgs> | null;
    omit?: Prisma.utilisateurOmit<ExtArgs> | null;
    include?: Prisma.utilisateurInclude<ExtArgs> | null;
    where?: Prisma.utilisateurWhereInput;
    orderBy?: Prisma.utilisateurOrderByWithRelationInput | Prisma.utilisateurOrderByWithRelationInput[];
    cursor?: Prisma.utilisateurWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.UtilisateurScalarFieldEnum | Prisma.UtilisateurScalarFieldEnum[];
};
export type entrepriseDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.entrepriseSelect<ExtArgs> | null;
    omit?: Prisma.entrepriseOmit<ExtArgs> | null;
    include?: Prisma.entrepriseInclude<ExtArgs> | null;
};
