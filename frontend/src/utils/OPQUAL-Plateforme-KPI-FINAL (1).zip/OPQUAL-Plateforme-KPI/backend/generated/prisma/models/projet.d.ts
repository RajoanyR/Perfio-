import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type projetModel = runtime.Types.Result.DefaultSelection<Prisma.$projetPayload>;
export type AggregateProjet = {
    _count: ProjetCountAggregateOutputType | null;
    _avg: ProjetAvgAggregateOutputType | null;
    _sum: ProjetSumAggregateOutputType | null;
    _min: ProjetMinAggregateOutputType | null;
    _max: ProjetMaxAggregateOutputType | null;
};
export type ProjetAvgAggregateOutputType = {
    id_projet: number | null;
    id_equipe: number | null;
    id_chef_projet: number | null;
};
export type ProjetSumAggregateOutputType = {
    id_projet: bigint | null;
    id_equipe: bigint | null;
    id_chef_projet: bigint | null;
};
export type ProjetMinAggregateOutputType = {
    id_projet: bigint | null;
    id_equipe: bigint | null;
    id_chef_projet: bigint | null;
    nom_projet: string | null;
    code_projet: string | null;
    description: string | null;
    priorite: string | null;
    etat: string | null;
    date_debut: Date | null;
    date_fin_prevue: Date | null;
    date_fin_reelle: Date | null;
    statut: string | null;
    date_creation: Date | null;
};
export type ProjetMaxAggregateOutputType = {
    id_projet: bigint | null;
    id_equipe: bigint | null;
    id_chef_projet: bigint | null;
    nom_projet: string | null;
    code_projet: string | null;
    description: string | null;
    priorite: string | null;
    etat: string | null;
    date_debut: Date | null;
    date_fin_prevue: Date | null;
    date_fin_reelle: Date | null;
    statut: string | null;
    date_creation: Date | null;
};
export type ProjetCountAggregateOutputType = {
    id_projet: number;
    id_equipe: number;
    id_chef_projet: number;
    nom_projet: number;
    code_projet: number;
    description: number;
    priorite: number;
    etat: number;
    date_debut: number;
    date_fin_prevue: number;
    date_fin_reelle: number;
    statut: number;
    date_creation: number;
    _all: number;
};
export type ProjetAvgAggregateInputType = {
    id_projet?: true;
    id_equipe?: true;
    id_chef_projet?: true;
};
export type ProjetSumAggregateInputType = {
    id_projet?: true;
    id_equipe?: true;
    id_chef_projet?: true;
};
export type ProjetMinAggregateInputType = {
    id_projet?: true;
    id_equipe?: true;
    id_chef_projet?: true;
    nom_projet?: true;
    code_projet?: true;
    description?: true;
    priorite?: true;
    etat?: true;
    date_debut?: true;
    date_fin_prevue?: true;
    date_fin_reelle?: true;
    statut?: true;
    date_creation?: true;
};
export type ProjetMaxAggregateInputType = {
    id_projet?: true;
    id_equipe?: true;
    id_chef_projet?: true;
    nom_projet?: true;
    code_projet?: true;
    description?: true;
    priorite?: true;
    etat?: true;
    date_debut?: true;
    date_fin_prevue?: true;
    date_fin_reelle?: true;
    statut?: true;
    date_creation?: true;
};
export type ProjetCountAggregateInputType = {
    id_projet?: true;
    id_equipe?: true;
    id_chef_projet?: true;
    nom_projet?: true;
    code_projet?: true;
    description?: true;
    priorite?: true;
    etat?: true;
    date_debut?: true;
    date_fin_prevue?: true;
    date_fin_reelle?: true;
    statut?: true;
    date_creation?: true;
    _all?: true;
};
export type ProjetAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.projetWhereInput;
    orderBy?: Prisma.projetOrderByWithRelationInput | Prisma.projetOrderByWithRelationInput[];
    cursor?: Prisma.projetWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | ProjetCountAggregateInputType;
    _avg?: ProjetAvgAggregateInputType;
    _sum?: ProjetSumAggregateInputType;
    _min?: ProjetMinAggregateInputType;
    _max?: ProjetMaxAggregateInputType;
};
export type GetProjetAggregateType<T extends ProjetAggregateArgs> = {
    [P in keyof T & keyof AggregateProjet]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateProjet[P]> : Prisma.GetScalarType<T[P], AggregateProjet[P]>;
};
export type projetGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.projetWhereInput;
    orderBy?: Prisma.projetOrderByWithAggregationInput | Prisma.projetOrderByWithAggregationInput[];
    by: Prisma.ProjetScalarFieldEnum[] | Prisma.ProjetScalarFieldEnum;
    having?: Prisma.projetScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: ProjetCountAggregateInputType | true;
    _avg?: ProjetAvgAggregateInputType;
    _sum?: ProjetSumAggregateInputType;
    _min?: ProjetMinAggregateInputType;
    _max?: ProjetMaxAggregateInputType;
};
export type ProjetGroupByOutputType = {
    id_projet: bigint;
    id_equipe: bigint;
    id_chef_projet: bigint;
    nom_projet: string;
    code_projet: string;
    description: string | null;
    priorite: string;
    etat: string;
    date_debut: Date;
    date_fin_prevue: Date;
    date_fin_reelle: Date | null;
    statut: string;
    date_creation: Date;
    _count: ProjetCountAggregateOutputType | null;
    _avg: ProjetAvgAggregateOutputType | null;
    _sum: ProjetSumAggregateOutputType | null;
    _min: ProjetMinAggregateOutputType | null;
    _max: ProjetMaxAggregateOutputType | null;
};
export type GetProjetGroupByPayload<T extends projetGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<ProjetGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof ProjetGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], ProjetGroupByOutputType[P]> : Prisma.GetScalarType<T[P], ProjetGroupByOutputType[P]>;
}>>;
export type projetWhereInput = {
    AND?: Prisma.projetWhereInput | Prisma.projetWhereInput[];
    OR?: Prisma.projetWhereInput[];
    NOT?: Prisma.projetWhereInput | Prisma.projetWhereInput[];
    id_projet?: Prisma.BigIntFilter<"projet"> | bigint | number;
    id_equipe?: Prisma.BigIntFilter<"projet"> | bigint | number;
    id_chef_projet?: Prisma.BigIntFilter<"projet"> | bigint | number;
    nom_projet?: Prisma.StringFilter<"projet"> | string;
    code_projet?: Prisma.StringFilter<"projet"> | string;
    description?: Prisma.StringNullableFilter<"projet"> | string | null;
    priorite?: Prisma.StringFilter<"projet"> | string;
    etat?: Prisma.StringFilter<"projet"> | string;
    date_debut?: Prisma.DateTimeFilter<"projet"> | Date | string;
    date_fin_prevue?: Prisma.DateTimeFilter<"projet"> | Date | string;
    date_fin_reelle?: Prisma.DateTimeNullableFilter<"projet"> | Date | string | null;
    statut?: Prisma.StringFilter<"projet"> | string;
    date_creation?: Prisma.DateTimeFilter<"projet"> | Date | string;
    participation_projet?: Prisma.Participation_projetListRelationFilter;
    equipe?: Prisma.XOR<Prisma.EquipeScalarRelationFilter, Prisma.equipeWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
    tache?: Prisma.TacheListRelationFilter;
};
export type projetOrderByWithRelationInput = {
    id_projet?: Prisma.SortOrder;
    id_equipe?: Prisma.SortOrder;
    id_chef_projet?: Prisma.SortOrder;
    nom_projet?: Prisma.SortOrder;
    code_projet?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    priorite?: Prisma.SortOrder;
    etat?: Prisma.SortOrder;
    date_debut?: Prisma.SortOrder;
    date_fin_prevue?: Prisma.SortOrder;
    date_fin_reelle?: Prisma.SortOrderInput | Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    participation_projet?: Prisma.participation_projetOrderByRelationAggregateInput;
    equipe?: Prisma.equipeOrderByWithRelationInput;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
    tache?: Prisma.tacheOrderByRelationAggregateInput;
};
export type projetWhereUniqueInput = Prisma.AtLeast<{
    id_projet?: bigint | number;
    code_projet?: string;
    AND?: Prisma.projetWhereInput | Prisma.projetWhereInput[];
    OR?: Prisma.projetWhereInput[];
    NOT?: Prisma.projetWhereInput | Prisma.projetWhereInput[];
    id_equipe?: Prisma.BigIntFilter<"projet"> | bigint | number;
    id_chef_projet?: Prisma.BigIntFilter<"projet"> | bigint | number;
    nom_projet?: Prisma.StringFilter<"projet"> | string;
    description?: Prisma.StringNullableFilter<"projet"> | string | null;
    priorite?: Prisma.StringFilter<"projet"> | string;
    etat?: Prisma.StringFilter<"projet"> | string;
    date_debut?: Prisma.DateTimeFilter<"projet"> | Date | string;
    date_fin_prevue?: Prisma.DateTimeFilter<"projet"> | Date | string;
    date_fin_reelle?: Prisma.DateTimeNullableFilter<"projet"> | Date | string | null;
    statut?: Prisma.StringFilter<"projet"> | string;
    date_creation?: Prisma.DateTimeFilter<"projet"> | Date | string;
    participation_projet?: Prisma.Participation_projetListRelationFilter;
    equipe?: Prisma.XOR<Prisma.EquipeScalarRelationFilter, Prisma.equipeWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
    tache?: Prisma.TacheListRelationFilter;
}, "id_projet" | "code_projet">;
export type projetOrderByWithAggregationInput = {
    id_projet?: Prisma.SortOrder;
    id_equipe?: Prisma.SortOrder;
    id_chef_projet?: Prisma.SortOrder;
    nom_projet?: Prisma.SortOrder;
    code_projet?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    priorite?: Prisma.SortOrder;
    etat?: Prisma.SortOrder;
    date_debut?: Prisma.SortOrder;
    date_fin_prevue?: Prisma.SortOrder;
    date_fin_reelle?: Prisma.SortOrderInput | Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    _count?: Prisma.projetCountOrderByAggregateInput;
    _avg?: Prisma.projetAvgOrderByAggregateInput;
    _max?: Prisma.projetMaxOrderByAggregateInput;
    _min?: Prisma.projetMinOrderByAggregateInput;
    _sum?: Prisma.projetSumOrderByAggregateInput;
};
export type projetScalarWhereWithAggregatesInput = {
    AND?: Prisma.projetScalarWhereWithAggregatesInput | Prisma.projetScalarWhereWithAggregatesInput[];
    OR?: Prisma.projetScalarWhereWithAggregatesInput[];
    NOT?: Prisma.projetScalarWhereWithAggregatesInput | Prisma.projetScalarWhereWithAggregatesInput[];
    id_projet?: Prisma.BigIntWithAggregatesFilter<"projet"> | bigint | number;
    id_equipe?: Prisma.BigIntWithAggregatesFilter<"projet"> | bigint | number;
    id_chef_projet?: Prisma.BigIntWithAggregatesFilter<"projet"> | bigint | number;
    nom_projet?: Prisma.StringWithAggregatesFilter<"projet"> | string;
    code_projet?: Prisma.StringWithAggregatesFilter<"projet"> | string;
    description?: Prisma.StringNullableWithAggregatesFilter<"projet"> | string | null;
    priorite?: Prisma.StringWithAggregatesFilter<"projet"> | string;
    etat?: Prisma.StringWithAggregatesFilter<"projet"> | string;
    date_debut?: Prisma.DateTimeWithAggregatesFilter<"projet"> | Date | string;
    date_fin_prevue?: Prisma.DateTimeWithAggregatesFilter<"projet"> | Date | string;
    date_fin_reelle?: Prisma.DateTimeNullableWithAggregatesFilter<"projet"> | Date | string | null;
    statut?: Prisma.StringWithAggregatesFilter<"projet"> | string;
    date_creation?: Prisma.DateTimeWithAggregatesFilter<"projet"> | Date | string;
};
export type projetCreateInput = {
    id_projet?: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    participation_projet?: Prisma.participation_projetCreateNestedManyWithoutProjetInput;
    equipe: Prisma.equipeCreateNestedOneWithoutProjetInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutProjetInput;
    tache?: Prisma.tacheCreateNestedManyWithoutProjetInput;
};
export type projetUncheckedCreateInput = {
    id_projet?: bigint | number;
    id_equipe: bigint | number;
    id_chef_projet: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    participation_projet?: Prisma.participation_projetUncheckedCreateNestedManyWithoutProjetInput;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutProjetInput;
};
export type projetUpdateInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    participation_projet?: Prisma.participation_projetUpdateManyWithoutProjetNestedInput;
    equipe?: Prisma.equipeUpdateOneRequiredWithoutProjetNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutProjetNestedInput;
    tache?: Prisma.tacheUpdateManyWithoutProjetNestedInput;
};
export type projetUncheckedUpdateInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_chef_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    participation_projet?: Prisma.participation_projetUncheckedUpdateManyWithoutProjetNestedInput;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutProjetNestedInput;
};
export type projetCreateManyInput = {
    id_projet?: bigint | number;
    id_equipe: bigint | number;
    id_chef_projet: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
};
export type projetUpdateManyMutationInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type projetUncheckedUpdateManyInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_chef_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type ProjetListRelationFilter = {
    every?: Prisma.projetWhereInput;
    some?: Prisma.projetWhereInput;
    none?: Prisma.projetWhereInput;
};
export type projetOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type ProjetScalarRelationFilter = {
    is?: Prisma.projetWhereInput;
    isNot?: Prisma.projetWhereInput;
};
export type projetCountOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_equipe?: Prisma.SortOrder;
    id_chef_projet?: Prisma.SortOrder;
    nom_projet?: Prisma.SortOrder;
    code_projet?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    priorite?: Prisma.SortOrder;
    etat?: Prisma.SortOrder;
    date_debut?: Prisma.SortOrder;
    date_fin_prevue?: Prisma.SortOrder;
    date_fin_reelle?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type projetAvgOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_equipe?: Prisma.SortOrder;
    id_chef_projet?: Prisma.SortOrder;
};
export type projetMaxOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_equipe?: Prisma.SortOrder;
    id_chef_projet?: Prisma.SortOrder;
    nom_projet?: Prisma.SortOrder;
    code_projet?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    priorite?: Prisma.SortOrder;
    etat?: Prisma.SortOrder;
    date_debut?: Prisma.SortOrder;
    date_fin_prevue?: Prisma.SortOrder;
    date_fin_reelle?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type projetMinOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_equipe?: Prisma.SortOrder;
    id_chef_projet?: Prisma.SortOrder;
    nom_projet?: Prisma.SortOrder;
    code_projet?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    priorite?: Prisma.SortOrder;
    etat?: Prisma.SortOrder;
    date_debut?: Prisma.SortOrder;
    date_fin_prevue?: Prisma.SortOrder;
    date_fin_reelle?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
};
export type projetSumOrderByAggregateInput = {
    id_projet?: Prisma.SortOrder;
    id_equipe?: Prisma.SortOrder;
    id_chef_projet?: Prisma.SortOrder;
};
export type projetCreateNestedManyWithoutEquipeInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutEquipeInput, Prisma.projetUncheckedCreateWithoutEquipeInput> | Prisma.projetCreateWithoutEquipeInput[] | Prisma.projetUncheckedCreateWithoutEquipeInput[];
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutEquipeInput | Prisma.projetCreateOrConnectWithoutEquipeInput[];
    createMany?: Prisma.projetCreateManyEquipeInputEnvelope;
    connect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
};
export type projetUncheckedCreateNestedManyWithoutEquipeInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutEquipeInput, Prisma.projetUncheckedCreateWithoutEquipeInput> | Prisma.projetCreateWithoutEquipeInput[] | Prisma.projetUncheckedCreateWithoutEquipeInput[];
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutEquipeInput | Prisma.projetCreateOrConnectWithoutEquipeInput[];
    createMany?: Prisma.projetCreateManyEquipeInputEnvelope;
    connect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
};
export type projetUpdateManyWithoutEquipeNestedInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutEquipeInput, Prisma.projetUncheckedCreateWithoutEquipeInput> | Prisma.projetCreateWithoutEquipeInput[] | Prisma.projetUncheckedCreateWithoutEquipeInput[];
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutEquipeInput | Prisma.projetCreateOrConnectWithoutEquipeInput[];
    upsert?: Prisma.projetUpsertWithWhereUniqueWithoutEquipeInput | Prisma.projetUpsertWithWhereUniqueWithoutEquipeInput[];
    createMany?: Prisma.projetCreateManyEquipeInputEnvelope;
    set?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    disconnect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    delete?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    connect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    update?: Prisma.projetUpdateWithWhereUniqueWithoutEquipeInput | Prisma.projetUpdateWithWhereUniqueWithoutEquipeInput[];
    updateMany?: Prisma.projetUpdateManyWithWhereWithoutEquipeInput | Prisma.projetUpdateManyWithWhereWithoutEquipeInput[];
    deleteMany?: Prisma.projetScalarWhereInput | Prisma.projetScalarWhereInput[];
};
export type projetUncheckedUpdateManyWithoutEquipeNestedInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutEquipeInput, Prisma.projetUncheckedCreateWithoutEquipeInput> | Prisma.projetCreateWithoutEquipeInput[] | Prisma.projetUncheckedCreateWithoutEquipeInput[];
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutEquipeInput | Prisma.projetCreateOrConnectWithoutEquipeInput[];
    upsert?: Prisma.projetUpsertWithWhereUniqueWithoutEquipeInput | Prisma.projetUpsertWithWhereUniqueWithoutEquipeInput[];
    createMany?: Prisma.projetCreateManyEquipeInputEnvelope;
    set?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    disconnect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    delete?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    connect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    update?: Prisma.projetUpdateWithWhereUniqueWithoutEquipeInput | Prisma.projetUpdateWithWhereUniqueWithoutEquipeInput[];
    updateMany?: Prisma.projetUpdateManyWithWhereWithoutEquipeInput | Prisma.projetUpdateManyWithWhereWithoutEquipeInput[];
    deleteMany?: Prisma.projetScalarWhereInput | Prisma.projetScalarWhereInput[];
};
export type projetCreateNestedOneWithoutParticipation_projetInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutParticipation_projetInput, Prisma.projetUncheckedCreateWithoutParticipation_projetInput>;
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutParticipation_projetInput;
    connect?: Prisma.projetWhereUniqueInput;
};
export type projetUpdateOneRequiredWithoutParticipation_projetNestedInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutParticipation_projetInput, Prisma.projetUncheckedCreateWithoutParticipation_projetInput>;
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutParticipation_projetInput;
    upsert?: Prisma.projetUpsertWithoutParticipation_projetInput;
    connect?: Prisma.projetWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.projetUpdateToOneWithWhereWithoutParticipation_projetInput, Prisma.projetUpdateWithoutParticipation_projetInput>, Prisma.projetUncheckedUpdateWithoutParticipation_projetInput>;
};
export type projetCreateNestedOneWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutTacheInput, Prisma.projetUncheckedCreateWithoutTacheInput>;
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutTacheInput;
    connect?: Prisma.projetWhereUniqueInput;
};
export type projetUpdateOneRequiredWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutTacheInput, Prisma.projetUncheckedCreateWithoutTacheInput>;
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutTacheInput;
    upsert?: Prisma.projetUpsertWithoutTacheInput;
    connect?: Prisma.projetWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.projetUpdateToOneWithWhereWithoutTacheInput, Prisma.projetUpdateWithoutTacheInput>, Prisma.projetUncheckedUpdateWithoutTacheInput>;
};
export type projetCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutUtilisateurInput, Prisma.projetUncheckedCreateWithoutUtilisateurInput> | Prisma.projetCreateWithoutUtilisateurInput[] | Prisma.projetUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutUtilisateurInput | Prisma.projetCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.projetCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
};
export type projetUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutUtilisateurInput, Prisma.projetUncheckedCreateWithoutUtilisateurInput> | Prisma.projetCreateWithoutUtilisateurInput[] | Prisma.projetUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutUtilisateurInput | Prisma.projetCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.projetCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
};
export type projetUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutUtilisateurInput, Prisma.projetUncheckedCreateWithoutUtilisateurInput> | Prisma.projetCreateWithoutUtilisateurInput[] | Prisma.projetUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutUtilisateurInput | Prisma.projetCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.projetUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.projetUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.projetCreateManyUtilisateurInputEnvelope;
    set?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    disconnect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    delete?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    connect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    update?: Prisma.projetUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.projetUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.projetUpdateManyWithWhereWithoutUtilisateurInput | Prisma.projetUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.projetScalarWhereInput | Prisma.projetScalarWhereInput[];
};
export type projetUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.projetCreateWithoutUtilisateurInput, Prisma.projetUncheckedCreateWithoutUtilisateurInput> | Prisma.projetCreateWithoutUtilisateurInput[] | Prisma.projetUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.projetCreateOrConnectWithoutUtilisateurInput | Prisma.projetCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.projetUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.projetUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.projetCreateManyUtilisateurInputEnvelope;
    set?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    disconnect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    delete?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    connect?: Prisma.projetWhereUniqueInput | Prisma.projetWhereUniqueInput[];
    update?: Prisma.projetUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.projetUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.projetUpdateManyWithWhereWithoutUtilisateurInput | Prisma.projetUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.projetScalarWhereInput | Prisma.projetScalarWhereInput[];
};
export type projetCreateWithoutEquipeInput = {
    id_projet?: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    participation_projet?: Prisma.participation_projetCreateNestedManyWithoutProjetInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutProjetInput;
    tache?: Prisma.tacheCreateNestedManyWithoutProjetInput;
};
export type projetUncheckedCreateWithoutEquipeInput = {
    id_projet?: bigint | number;
    id_chef_projet: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    participation_projet?: Prisma.participation_projetUncheckedCreateNestedManyWithoutProjetInput;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutProjetInput;
};
export type projetCreateOrConnectWithoutEquipeInput = {
    where: Prisma.projetWhereUniqueInput;
    create: Prisma.XOR<Prisma.projetCreateWithoutEquipeInput, Prisma.projetUncheckedCreateWithoutEquipeInput>;
};
export type projetCreateManyEquipeInputEnvelope = {
    data: Prisma.projetCreateManyEquipeInput | Prisma.projetCreateManyEquipeInput[];
    skipDuplicates?: boolean;
};
export type projetUpsertWithWhereUniqueWithoutEquipeInput = {
    where: Prisma.projetWhereUniqueInput;
    update: Prisma.XOR<Prisma.projetUpdateWithoutEquipeInput, Prisma.projetUncheckedUpdateWithoutEquipeInput>;
    create: Prisma.XOR<Prisma.projetCreateWithoutEquipeInput, Prisma.projetUncheckedCreateWithoutEquipeInput>;
};
export type projetUpdateWithWhereUniqueWithoutEquipeInput = {
    where: Prisma.projetWhereUniqueInput;
    data: Prisma.XOR<Prisma.projetUpdateWithoutEquipeInput, Prisma.projetUncheckedUpdateWithoutEquipeInput>;
};
export type projetUpdateManyWithWhereWithoutEquipeInput = {
    where: Prisma.projetScalarWhereInput;
    data: Prisma.XOR<Prisma.projetUpdateManyMutationInput, Prisma.projetUncheckedUpdateManyWithoutEquipeInput>;
};
export type projetScalarWhereInput = {
    AND?: Prisma.projetScalarWhereInput | Prisma.projetScalarWhereInput[];
    OR?: Prisma.projetScalarWhereInput[];
    NOT?: Prisma.projetScalarWhereInput | Prisma.projetScalarWhereInput[];
    id_projet?: Prisma.BigIntFilter<"projet"> | bigint | number;
    id_equipe?: Prisma.BigIntFilter<"projet"> | bigint | number;
    id_chef_projet?: Prisma.BigIntFilter<"projet"> | bigint | number;
    nom_projet?: Prisma.StringFilter<"projet"> | string;
    code_projet?: Prisma.StringFilter<"projet"> | string;
    description?: Prisma.StringNullableFilter<"projet"> | string | null;
    priorite?: Prisma.StringFilter<"projet"> | string;
    etat?: Prisma.StringFilter<"projet"> | string;
    date_debut?: Prisma.DateTimeFilter<"projet"> | Date | string;
    date_fin_prevue?: Prisma.DateTimeFilter<"projet"> | Date | string;
    date_fin_reelle?: Prisma.DateTimeNullableFilter<"projet"> | Date | string | null;
    statut?: Prisma.StringFilter<"projet"> | string;
    date_creation?: Prisma.DateTimeFilter<"projet"> | Date | string;
};
export type projetCreateWithoutParticipation_projetInput = {
    id_projet?: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    equipe: Prisma.equipeCreateNestedOneWithoutProjetInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutProjetInput;
    tache?: Prisma.tacheCreateNestedManyWithoutProjetInput;
};
export type projetUncheckedCreateWithoutParticipation_projetInput = {
    id_projet?: bigint | number;
    id_equipe: bigint | number;
    id_chef_projet: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutProjetInput;
};
export type projetCreateOrConnectWithoutParticipation_projetInput = {
    where: Prisma.projetWhereUniqueInput;
    create: Prisma.XOR<Prisma.projetCreateWithoutParticipation_projetInput, Prisma.projetUncheckedCreateWithoutParticipation_projetInput>;
};
export type projetUpsertWithoutParticipation_projetInput = {
    update: Prisma.XOR<Prisma.projetUpdateWithoutParticipation_projetInput, Prisma.projetUncheckedUpdateWithoutParticipation_projetInput>;
    create: Prisma.XOR<Prisma.projetCreateWithoutParticipation_projetInput, Prisma.projetUncheckedCreateWithoutParticipation_projetInput>;
    where?: Prisma.projetWhereInput;
};
export type projetUpdateToOneWithWhereWithoutParticipation_projetInput = {
    where?: Prisma.projetWhereInput;
    data: Prisma.XOR<Prisma.projetUpdateWithoutParticipation_projetInput, Prisma.projetUncheckedUpdateWithoutParticipation_projetInput>;
};
export type projetUpdateWithoutParticipation_projetInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    equipe?: Prisma.equipeUpdateOneRequiredWithoutProjetNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutProjetNestedInput;
    tache?: Prisma.tacheUpdateManyWithoutProjetNestedInput;
};
export type projetUncheckedUpdateWithoutParticipation_projetInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_chef_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutProjetNestedInput;
};
export type projetCreateWithoutTacheInput = {
    id_projet?: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    participation_projet?: Prisma.participation_projetCreateNestedManyWithoutProjetInput;
    equipe: Prisma.equipeCreateNestedOneWithoutProjetInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutProjetInput;
};
export type projetUncheckedCreateWithoutTacheInput = {
    id_projet?: bigint | number;
    id_equipe: bigint | number;
    id_chef_projet: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    participation_projet?: Prisma.participation_projetUncheckedCreateNestedManyWithoutProjetInput;
};
export type projetCreateOrConnectWithoutTacheInput = {
    where: Prisma.projetWhereUniqueInput;
    create: Prisma.XOR<Prisma.projetCreateWithoutTacheInput, Prisma.projetUncheckedCreateWithoutTacheInput>;
};
export type projetUpsertWithoutTacheInput = {
    update: Prisma.XOR<Prisma.projetUpdateWithoutTacheInput, Prisma.projetUncheckedUpdateWithoutTacheInput>;
    create: Prisma.XOR<Prisma.projetCreateWithoutTacheInput, Prisma.projetUncheckedCreateWithoutTacheInput>;
    where?: Prisma.projetWhereInput;
};
export type projetUpdateToOneWithWhereWithoutTacheInput = {
    where?: Prisma.projetWhereInput;
    data: Prisma.XOR<Prisma.projetUpdateWithoutTacheInput, Prisma.projetUncheckedUpdateWithoutTacheInput>;
};
export type projetUpdateWithoutTacheInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    participation_projet?: Prisma.participation_projetUpdateManyWithoutProjetNestedInput;
    equipe?: Prisma.equipeUpdateOneRequiredWithoutProjetNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutProjetNestedInput;
};
export type projetUncheckedUpdateWithoutTacheInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_chef_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    participation_projet?: Prisma.participation_projetUncheckedUpdateManyWithoutProjetNestedInput;
};
export type projetCreateWithoutUtilisateurInput = {
    id_projet?: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    participation_projet?: Prisma.participation_projetCreateNestedManyWithoutProjetInput;
    equipe: Prisma.equipeCreateNestedOneWithoutProjetInput;
    tache?: Prisma.tacheCreateNestedManyWithoutProjetInput;
};
export type projetUncheckedCreateWithoutUtilisateurInput = {
    id_projet?: bigint | number;
    id_equipe: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
    participation_projet?: Prisma.participation_projetUncheckedCreateNestedManyWithoutProjetInput;
    tache?: Prisma.tacheUncheckedCreateNestedManyWithoutProjetInput;
};
export type projetCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.projetWhereUniqueInput;
    create: Prisma.XOR<Prisma.projetCreateWithoutUtilisateurInput, Prisma.projetUncheckedCreateWithoutUtilisateurInput>;
};
export type projetCreateManyUtilisateurInputEnvelope = {
    data: Prisma.projetCreateManyUtilisateurInput | Prisma.projetCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type projetUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.projetWhereUniqueInput;
    update: Prisma.XOR<Prisma.projetUpdateWithoutUtilisateurInput, Prisma.projetUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.projetCreateWithoutUtilisateurInput, Prisma.projetUncheckedCreateWithoutUtilisateurInput>;
};
export type projetUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.projetWhereUniqueInput;
    data: Prisma.XOR<Prisma.projetUpdateWithoutUtilisateurInput, Prisma.projetUncheckedUpdateWithoutUtilisateurInput>;
};
export type projetUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.projetScalarWhereInput;
    data: Prisma.XOR<Prisma.projetUpdateManyMutationInput, Prisma.projetUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type projetCreateManyEquipeInput = {
    id_projet?: bigint | number;
    id_chef_projet: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
};
export type projetUpdateWithoutEquipeInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    participation_projet?: Prisma.participation_projetUpdateManyWithoutProjetNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutProjetNestedInput;
    tache?: Prisma.tacheUpdateManyWithoutProjetNestedInput;
};
export type projetUncheckedUpdateWithoutEquipeInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_chef_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    participation_projet?: Prisma.participation_projetUncheckedUpdateManyWithoutProjetNestedInput;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutProjetNestedInput;
};
export type projetUncheckedUpdateManyWithoutEquipeInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_chef_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type projetCreateManyUtilisateurInput = {
    id_projet?: bigint | number;
    id_equipe: bigint | number;
    nom_projet: string;
    code_projet: string;
    description?: string | null;
    priorite?: string;
    etat?: string;
    date_debut: Date | string;
    date_fin_prevue: Date | string;
    date_fin_reelle?: Date | string | null;
    statut?: string;
    date_creation?: Date | string;
};
export type projetUpdateWithoutUtilisateurInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    participation_projet?: Prisma.participation_projetUpdateManyWithoutProjetNestedInput;
    equipe?: Prisma.equipeUpdateOneRequiredWithoutProjetNestedInput;
    tache?: Prisma.tacheUpdateManyWithoutProjetNestedInput;
};
export type projetUncheckedUpdateWithoutUtilisateurInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    participation_projet?: Prisma.participation_projetUncheckedUpdateManyWithoutProjetNestedInput;
    tache?: Prisma.tacheUncheckedUpdateManyWithoutProjetNestedInput;
};
export type projetUncheckedUpdateManyWithoutUtilisateurInput = {
    id_projet?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nom_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    code_projet?: Prisma.StringFieldUpdateOperationsInput | string;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    priorite?: Prisma.StringFieldUpdateOperationsInput | string;
    etat?: Prisma.StringFieldUpdateOperationsInput | string;
    date_debut?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_prevue?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_fin_reelle?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type ProjetCountOutputType = {
    participation_projet: number;
    tache: number;
};
export type ProjetCountOutputTypeSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    participation_projet?: boolean | ProjetCountOutputTypeCountParticipation_projetArgs;
    tache?: boolean | ProjetCountOutputTypeCountTacheArgs;
};
export type ProjetCountOutputTypeDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.ProjetCountOutputTypeSelect<ExtArgs> | null;
};
export type ProjetCountOutputTypeCountParticipation_projetArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.participation_projetWhereInput;
};
export type ProjetCountOutputTypeCountTacheArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.tacheWhereInput;
};
export type projetSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_projet?: boolean;
    id_equipe?: boolean;
    id_chef_projet?: boolean;
    nom_projet?: boolean;
    code_projet?: boolean;
    description?: boolean;
    priorite?: boolean;
    etat?: boolean;
    date_debut?: boolean;
    date_fin_prevue?: boolean;
    date_fin_reelle?: boolean;
    statut?: boolean;
    date_creation?: boolean;
    participation_projet?: boolean | Prisma.projet$participation_projetArgs<ExtArgs>;
    equipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    tache?: boolean | Prisma.projet$tacheArgs<ExtArgs>;
    _count?: boolean | Prisma.ProjetCountOutputTypeDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["projet"]>;
export type projetSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_projet?: boolean;
    id_equipe?: boolean;
    id_chef_projet?: boolean;
    nom_projet?: boolean;
    code_projet?: boolean;
    description?: boolean;
    priorite?: boolean;
    etat?: boolean;
    date_debut?: boolean;
    date_fin_prevue?: boolean;
    date_fin_reelle?: boolean;
    statut?: boolean;
    date_creation?: boolean;
    equipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["projet"]>;
export type projetSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_projet?: boolean;
    id_equipe?: boolean;
    id_chef_projet?: boolean;
    nom_projet?: boolean;
    code_projet?: boolean;
    description?: boolean;
    priorite?: boolean;
    etat?: boolean;
    date_debut?: boolean;
    date_fin_prevue?: boolean;
    date_fin_reelle?: boolean;
    statut?: boolean;
    date_creation?: boolean;
    equipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["projet"]>;
export type projetSelectScalar = {
    id_projet?: boolean;
    id_equipe?: boolean;
    id_chef_projet?: boolean;
    nom_projet?: boolean;
    code_projet?: boolean;
    description?: boolean;
    priorite?: boolean;
    etat?: boolean;
    date_debut?: boolean;
    date_fin_prevue?: boolean;
    date_fin_reelle?: boolean;
    statut?: boolean;
    date_creation?: boolean;
};
export type projetOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_projet" | "id_equipe" | "id_chef_projet" | "nom_projet" | "code_projet" | "description" | "priorite" | "etat" | "date_debut" | "date_fin_prevue" | "date_fin_reelle" | "statut" | "date_creation", ExtArgs["result"]["projet"]>;
export type projetInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    participation_projet?: boolean | Prisma.projet$participation_projetArgs<ExtArgs>;
    equipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    tache?: boolean | Prisma.projet$tacheArgs<ExtArgs>;
    _count?: boolean | Prisma.ProjetCountOutputTypeDefaultArgs<ExtArgs>;
};
export type projetIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    equipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type projetIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    equipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $projetPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "projet";
    objects: {
        participation_projet: Prisma.$participation_projetPayload<ExtArgs>[];
        equipe: Prisma.$equipePayload<ExtArgs>;
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>;
        tache: Prisma.$tachePayload<ExtArgs>[];
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_projet: bigint;
        id_equipe: bigint;
        id_chef_projet: bigint;
        nom_projet: string;
        code_projet: string;
        description: string | null;
        priorite: string;
        etat: string;
        date_debut: Date;
        date_fin_prevue: Date;
        date_fin_reelle: Date | null;
        statut: string;
        date_creation: Date;
    }, ExtArgs["result"]["projet"]>;
    composites: {};
};
export type projetGetPayload<S extends boolean | null | undefined | projetDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$projetPayload, S>;
export type projetCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<projetFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: ProjetCountAggregateInputType | true;
};
export interface projetDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['projet'];
        meta: {
            name: 'projet';
        };
    };
    findUnique<T extends projetFindUniqueArgs>(args: Prisma.SelectSubset<T, projetFindUniqueArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends projetFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, projetFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends projetFindFirstArgs>(args?: Prisma.SelectSubset<T, projetFindFirstArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends projetFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, projetFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends projetFindManyArgs>(args?: Prisma.SelectSubset<T, projetFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends projetCreateArgs>(args: Prisma.SelectSubset<T, projetCreateArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends projetCreateManyArgs>(args?: Prisma.SelectSubset<T, projetCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends projetCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, projetCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends projetDeleteArgs>(args: Prisma.SelectSubset<T, projetDeleteArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends projetUpdateArgs>(args: Prisma.SelectSubset<T, projetUpdateArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends projetDeleteManyArgs>(args?: Prisma.SelectSubset<T, projetDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends projetUpdateManyArgs>(args: Prisma.SelectSubset<T, projetUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends projetUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, projetUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends projetUpsertArgs>(args: Prisma.SelectSubset<T, projetUpsertArgs<ExtArgs>>): Prisma.Prisma__projetClient<runtime.Types.Result.GetResult<Prisma.$projetPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends projetCountArgs>(args?: Prisma.Subset<T, projetCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], ProjetCountAggregateOutputType> : number>;
    aggregate<T extends ProjetAggregateArgs>(args: Prisma.Subset<T, ProjetAggregateArgs>): Prisma.PrismaPromise<GetProjetAggregateType<T>>;
    groupBy<T extends projetGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: projetGroupByArgs['orderBy'];
    } : {
        orderBy?: projetGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, projetGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetProjetGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: projetFieldRefs;
}
export interface Prisma__projetClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    participation_projet<T extends Prisma.projet$participation_projetArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.projet$participation_projetArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$participation_projetPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    equipe<T extends Prisma.equipeDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.equipeDefaultArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    utilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    tache<T extends Prisma.projet$tacheArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.projet$tacheArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$tachePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface projetFieldRefs {
    readonly id_projet: Prisma.FieldRef<"projet", 'BigInt'>;
    readonly id_equipe: Prisma.FieldRef<"projet", 'BigInt'>;
    readonly id_chef_projet: Prisma.FieldRef<"projet", 'BigInt'>;
    readonly nom_projet: Prisma.FieldRef<"projet", 'String'>;
    readonly code_projet: Prisma.FieldRef<"projet", 'String'>;
    readonly description: Prisma.FieldRef<"projet", 'String'>;
    readonly priorite: Prisma.FieldRef<"projet", 'String'>;
    readonly etat: Prisma.FieldRef<"projet", 'String'>;
    readonly date_debut: Prisma.FieldRef<"projet", 'DateTime'>;
    readonly date_fin_prevue: Prisma.FieldRef<"projet", 'DateTime'>;
    readonly date_fin_reelle: Prisma.FieldRef<"projet", 'DateTime'>;
    readonly statut: Prisma.FieldRef<"projet", 'String'>;
    readonly date_creation: Prisma.FieldRef<"projet", 'DateTime'>;
}
export type projetFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    where: Prisma.projetWhereUniqueInput;
};
export type projetFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    where: Prisma.projetWhereUniqueInput;
};
export type projetFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    where?: Prisma.projetWhereInput;
    orderBy?: Prisma.projetOrderByWithRelationInput | Prisma.projetOrderByWithRelationInput[];
    cursor?: Prisma.projetWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ProjetScalarFieldEnum | Prisma.ProjetScalarFieldEnum[];
};
export type projetFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    where?: Prisma.projetWhereInput;
    orderBy?: Prisma.projetOrderByWithRelationInput | Prisma.projetOrderByWithRelationInput[];
    cursor?: Prisma.projetWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ProjetScalarFieldEnum | Prisma.ProjetScalarFieldEnum[];
};
export type projetFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    where?: Prisma.projetWhereInput;
    orderBy?: Prisma.projetOrderByWithRelationInput | Prisma.projetOrderByWithRelationInput[];
    cursor?: Prisma.projetWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ProjetScalarFieldEnum | Prisma.ProjetScalarFieldEnum[];
};
export type projetCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.projetCreateInput, Prisma.projetUncheckedCreateInput>;
};
export type projetCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.projetCreateManyInput | Prisma.projetCreateManyInput[];
    skipDuplicates?: boolean;
};
export type projetCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    data: Prisma.projetCreateManyInput | Prisma.projetCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.projetIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type projetUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.projetUpdateInput, Prisma.projetUncheckedUpdateInput>;
    where: Prisma.projetWhereUniqueInput;
};
export type projetUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.projetUpdateManyMutationInput, Prisma.projetUncheckedUpdateManyInput>;
    where?: Prisma.projetWhereInput;
    limit?: number;
};
export type projetUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.projetUpdateManyMutationInput, Prisma.projetUncheckedUpdateManyInput>;
    where?: Prisma.projetWhereInput;
    limit?: number;
    include?: Prisma.projetIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type projetUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    where: Prisma.projetWhereUniqueInput;
    create: Prisma.XOR<Prisma.projetCreateInput, Prisma.projetUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.projetUpdateInput, Prisma.projetUncheckedUpdateInput>;
};
export type projetDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
    where: Prisma.projetWhereUniqueInput;
};
export type projetDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.projetWhereInput;
    limit?: number;
};
export type projet$participation_projetArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.participation_projetSelect<ExtArgs> | null;
    omit?: Prisma.participation_projetOmit<ExtArgs> | null;
    include?: Prisma.participation_projetInclude<ExtArgs> | null;
    where?: Prisma.participation_projetWhereInput;
    orderBy?: Prisma.participation_projetOrderByWithRelationInput | Prisma.participation_projetOrderByWithRelationInput[];
    cursor?: Prisma.participation_projetWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Participation_projetScalarFieldEnum | Prisma.Participation_projetScalarFieldEnum[];
};
export type projet$tacheArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.tacheSelect<ExtArgs> | null;
    omit?: Prisma.tacheOmit<ExtArgs> | null;
    include?: Prisma.tacheInclude<ExtArgs> | null;
    where?: Prisma.tacheWhereInput;
    orderBy?: Prisma.tacheOrderByWithRelationInput | Prisma.tacheOrderByWithRelationInput[];
    cursor?: Prisma.tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.TacheScalarFieldEnum | Prisma.TacheScalarFieldEnum[];
};
export type projetDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.projetSelect<ExtArgs> | null;
    omit?: Prisma.projetOmit<ExtArgs> | null;
    include?: Prisma.projetInclude<ExtArgs> | null;
};
