export {};
//# sourceMappingURL=tache.js.map