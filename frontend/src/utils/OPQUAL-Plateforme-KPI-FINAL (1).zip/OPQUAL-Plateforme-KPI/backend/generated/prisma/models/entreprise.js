export {};
//# sourceMappingURL=entreprise.js.map