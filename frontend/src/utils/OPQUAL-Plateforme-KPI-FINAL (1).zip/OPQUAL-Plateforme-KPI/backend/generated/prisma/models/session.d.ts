import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type sessionModel = runtime.Types.Result.DefaultSelection<Prisma.$sessionPayload>;
export type AggregateSession = {
    _count: SessionCountAggregateOutputType | null;
    _avg: SessionAvgAggregateOutputType | null;
    _sum: SessionSumAggregateOutputType | null;
    _min: SessionMinAggregateOutputType | null;
    _max: SessionMaxAggregateOutputType | null;
};
export type SessionAvgAggregateOutputType = {
    id_session: number | null;
    id_utilisateur: number | null;
};
export type SessionSumAggregateOutputType = {
    id_session: bigint | null;
    id_utilisateur: bigint | null;
};
export type SessionMinAggregateOutputType = {
    id_session: bigint | null;
    id_utilisateur: bigint | null;
    token_hash: string | null;
    date_connexion: Date | null;
    derniere_activite: Date | null;
    date_deconnexion: Date | null;
    statut: string | null;
};
export type SessionMaxAggregateOutputType = {
    id_session: bigint | null;
    id_utilisateur: bigint | null;
    token_hash: string | null;
    date_connexion: Date | null;
    derniere_activite: Date | null;
    date_deconnexion: Date | null;
    statut: string | null;
};
export type SessionCountAggregateOutputType = {
    id_session: number;
    id_utilisateur: number;
    token_hash: number;
    date_connexion: number;
    derniere_activite: number;
    date_deconnexion: number;
    statut: number;
    _all: number;
};
export type SessionAvgAggregateInputType = {
    id_session?: true;
    id_utilisateur?: true;
};
export type SessionSumAggregateInputType = {
    id_session?: true;
    id_utilisateur?: true;
};
export type SessionMinAggregateInputType = {
    id_session?: true;
    id_utilisateur?: true;
    token_hash?: true;
    date_connexion?: true;
    derniere_activite?: true;
    date_deconnexion?: true;
    statut?: true;
};
export type SessionMaxAggregateInputType = {
    id_session?: true;
    id_utilisateur?: true;
    token_hash?: true;
    date_connexion?: true;
    derniere_activite?: true;
    date_deconnexion?: true;
    statut?: true;
};
export type SessionCountAggregateInputType = {
    id_session?: true;
    id_utilisateur?: true;
    token_hash?: true;
    date_connexion?: true;
    derniere_activite?: true;
    date_deconnexion?: true;
    statut?: true;
    _all?: true;
};
export type SessionAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.sessionWhereInput;
    orderBy?: Prisma.sessionOrderByWithRelationInput | Prisma.sessionOrderByWithRelationInput[];
    cursor?: Prisma.sessionWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | SessionCountAggregateInputType;
    _avg?: SessionAvgAggregateInputType;
    _sum?: SessionSumAggregateInputType;
    _min?: SessionMinAggregateInputType;
    _max?: SessionMaxAggregateInputType;
};
export type GetSessionAggregateType<T extends SessionAggregateArgs> = {
    [P in keyof T & keyof AggregateSession]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateSession[P]> : Prisma.GetScalarType<T[P], AggregateSession[P]>;
};
export type sessionGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.sessionWhereInput;
    orderBy?: Prisma.sessionOrderByWithAggregationInput | Prisma.sessionOrderByWithAggregationInput[];
    by: Prisma.SessionScalarFieldEnum[] | Prisma.SessionScalarFieldEnum;
    having?: Prisma.sessionScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: SessionCountAggregateInputType | true;
    _avg?: SessionAvgAggregateInputType;
    _sum?: SessionSumAggregateInputType;
    _min?: SessionMinAggregateInputType;
    _max?: SessionMaxAggregateInputType;
};
export type SessionGroupByOutputType = {
    id_session: bigint;
    id_utilisateur: bigint;
    token_hash: string;
    date_connexion: Date;
    derniere_activite: Date;
    date_deconnexion: Date | null;
    statut: string;
    _count: SessionCountAggregateOutputType | null;
    _avg: SessionAvgAggregateOutputType | null;
    _sum: SessionSumAggregateOutputType | null;
    _min: SessionMinAggregateOutputType | null;
    _max: SessionMaxAggregateOutputType | null;
};
export type GetSessionGroupByPayload<T extends sessionGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<SessionGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof SessionGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], SessionGroupByOutputType[P]> : Prisma.GetScalarType<T[P], SessionGroupByOutputType[P]>;
}>>;
export type sessionWhereInput = {
    AND?: Prisma.sessionWhereInput | Prisma.sessionWhereInput[];
    OR?: Prisma.sessionWhereInput[];
    NOT?: Prisma.sessionWhereInput | Prisma.sessionWhereInput[];
    id_session?: Prisma.BigIntFilter<"session"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"session"> | bigint | number;
    token_hash?: Prisma.StringFilter<"session"> | string;
    date_connexion?: Prisma.DateTimeFilter<"session"> | Date | string;
    derniere_activite?: Prisma.DateTimeFilter<"session"> | Date | string;
    date_deconnexion?: Prisma.DateTimeNullableFilter<"session"> | Date | string | null;
    statut?: Prisma.StringFilter<"session"> | string;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
};
export type sessionOrderByWithRelationInput = {
    id_session?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    token_hash?: Prisma.SortOrder;
    date_connexion?: Prisma.SortOrder;
    derniere_activite?: Prisma.SortOrder;
    date_deconnexion?: Prisma.SortOrderInput | Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
};
export type sessionWhereUniqueInput = Prisma.AtLeast<{
    id_session?: bigint | number;
    token_hash?: string;
    AND?: Prisma.sessionWhereInput | Prisma.sessionWhereInput[];
    OR?: Prisma.sessionWhereInput[];
    NOT?: Prisma.sessionWhereInput | Prisma.sessionWhereInput[];
    id_utilisateur?: Prisma.BigIntFilter<"session"> | bigint | number;
    date_connexion?: Prisma.DateTimeFilter<"session"> | Date | string;
    derniere_activite?: Prisma.DateTimeFilter<"session"> | Date | string;
    date_deconnexion?: Prisma.DateTimeNullableFilter<"session"> | Date | string | null;
    statut?: Prisma.StringFilter<"session"> | string;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
}, "id_session" | "token_hash">;
export type sessionOrderByWithAggregationInput = {
    id_session?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    token_hash?: Prisma.SortOrder;
    date_connexion?: Prisma.SortOrder;
    derniere_activite?: Prisma.SortOrder;
    date_deconnexion?: Prisma.SortOrderInput | Prisma.SortOrder;
    statut?: Prisma.SortOrder;
    _count?: Prisma.sessionCountOrderByAggregateInput;
    _avg?: Prisma.sessionAvgOrderByAggregateInput;
    _max?: Prisma.sessionMaxOrderByAggregateInput;
    _min?: Prisma.sessionMinOrderByAggregateInput;
    _sum?: Prisma.sessionSumOrderByAggregateInput;
};
export type sessionScalarWhereWithAggregatesInput = {
    AND?: Prisma.sessionScalarWhereWithAggregatesInput | Prisma.sessionScalarWhereWithAggregatesInput[];
    OR?: Prisma.sessionScalarWhereWithAggregatesInput[];
    NOT?: Prisma.sessionScalarWhereWithAggregatesInput | Prisma.sessionScalarWhereWithAggregatesInput[];
    id_session?: Prisma.BigIntWithAggregatesFilter<"session"> | bigint | number;
    id_utilisateur?: Prisma.BigIntWithAggregatesFilter<"session"> | bigint | number;
    token_hash?: Prisma.StringWithAggregatesFilter<"session"> | string;
    date_connexion?: Prisma.DateTimeWithAggregatesFilter<"session"> | Date | string;
    derniere_activite?: Prisma.DateTimeWithAggregatesFilter<"session"> | Date | string;
    date_deconnexion?: Prisma.DateTimeNullableWithAggregatesFilter<"session"> | Date | string | null;
    statut?: Prisma.StringWithAggregatesFilter<"session"> | string;
};
export type sessionCreateInput = {
    id_session?: bigint | number;
    token_hash: string;
    date_connexion?: Date | string;
    derniere_activite?: Date | string;
    date_deconnexion?: Date | string | null;
    statut?: string;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutSessionInput;
};
export type sessionUncheckedCreateInput = {
    id_session?: bigint | number;
    id_utilisateur: bigint | number;
    token_hash: string;
    date_connexion?: Date | string;
    derniere_activite?: Date | string;
    date_deconnexion?: Date | string | null;
    statut?: string;
};
export type sessionUpdateInput = {
    id_session?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    token_hash?: Prisma.StringFieldUpdateOperationsInput | string;
    date_connexion?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    derniere_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_deconnexion?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutSessionNestedInput;
};
export type sessionUncheckedUpdateInput = {
    id_session?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    token_hash?: Prisma.StringFieldUpdateOperationsInput | string;
    date_connexion?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    derniere_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_deconnexion?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type sessionCreateManyInput = {
    id_session?: bigint | number;
    id_utilisateur: bigint | number;
    token_hash: string;
    date_connexion?: Date | string;
    derniere_activite?: Date | string;
    date_deconnexion?: Date | string | null;
    statut?: string;
};
export type sessionUpdateManyMutationInput = {
    id_session?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    token_hash?: Prisma.StringFieldUpdateOperationsInput | string;
    date_connexion?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    derniere_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_deconnexion?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type sessionUncheckedUpdateManyInput = {
    id_session?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    token_hash?: Prisma.StringFieldUpdateOperationsInput | string;
    date_connexion?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    derniere_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_deconnexion?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type sessionCountOrderByAggregateInput = {
    id_session?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    token_hash?: Prisma.SortOrder;
    date_connexion?: Prisma.SortOrder;
    derniere_activite?: Prisma.SortOrder;
    date_deconnexion?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type sessionAvgOrderByAggregateInput = {
    id_session?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type sessionMaxOrderByAggregateInput = {
    id_session?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    token_hash?: Prisma.SortOrder;
    date_connexion?: Prisma.SortOrder;
    derniere_activite?: Prisma.SortOrder;
    date_deconnexion?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type sessionMinOrderByAggregateInput = {
    id_session?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    token_hash?: Prisma.SortOrder;
    date_connexion?: Prisma.SortOrder;
    derniere_activite?: Prisma.SortOrder;
    date_deconnexion?: Prisma.SortOrder;
    statut?: Prisma.SortOrder;
};
export type sessionSumOrderByAggregateInput = {
    id_session?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type SessionListRelationFilter = {
    every?: Prisma.sessionWhereInput;
    some?: Prisma.sessionWhereInput;
    none?: Prisma.sessionWhereInput;
};
export type sessionOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type sessionCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.sessionCreateWithoutUtilisateurInput, Prisma.sessionUncheckedCreateWithoutUtilisateurInput> | Prisma.sessionCreateWithoutUtilisateurInput[] | Prisma.sessionUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.sessionCreateOrConnectWithoutUtilisateurInput | Prisma.sessionCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.sessionCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
};
export type sessionUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.sessionCreateWithoutUtilisateurInput, Prisma.sessionUncheckedCreateWithoutUtilisateurInput> | Prisma.sessionCreateWithoutUtilisateurInput[] | Prisma.sessionUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.sessionCreateOrConnectWithoutUtilisateurInput | Prisma.sessionCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.sessionCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
};
export type sessionUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.sessionCreateWithoutUtilisateurInput, Prisma.sessionUncheckedCreateWithoutUtilisateurInput> | Prisma.sessionCreateWithoutUtilisateurInput[] | Prisma.sessionUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.sessionCreateOrConnectWithoutUtilisateurInput | Prisma.sessionCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.sessionUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.sessionUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.sessionCreateManyUtilisateurInputEnvelope;
    set?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
    disconnect?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
    delete?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
    connect?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
    update?: Prisma.sessionUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.sessionUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.sessionUpdateManyWithWhereWithoutUtilisateurInput | Prisma.sessionUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.sessionScalarWhereInput | Prisma.sessionScalarWhereInput[];
};
export type sessionUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.sessionCreateWithoutUtilisateurInput, Prisma.sessionUncheckedCreateWithoutUtilisateurInput> | Prisma.sessionCreateWithoutUtilisateurInput[] | Prisma.sessionUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.sessionCreateOrConnectWithoutUtilisateurInput | Prisma.sessionCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.sessionUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.sessionUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.sessionCreateManyUtilisateurInputEnvelope;
    set?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
    disconnect?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
    delete?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
    connect?: Prisma.sessionWhereUniqueInput | Prisma.sessionWhereUniqueInput[];
    update?: Prisma.sessionUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.sessionUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.sessionUpdateManyWithWhereWithoutUtilisateurInput | Prisma.sessionUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.sessionScalarWhereInput | Prisma.sessionScalarWhereInput[];
};
export type sessionCreateWithoutUtilisateurInput = {
    id_session?: bigint | number;
    token_hash: string;
    date_connexion?: Date | string;
    derniere_activite?: Date | string;
    date_deconnexion?: Date | string | null;
    statut?: string;
};
export type sessionUncheckedCreateWithoutUtilisateurInput = {
    id_session?: bigint | number;
    token_hash: string;
    date_connexion?: Date | string;
    derniere_activite?: Date | string;
    date_deconnexion?: Date | string | null;
    statut?: string;
};
export type sessionCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.sessionWhereUniqueInput;
    create: Prisma.XOR<Prisma.sessionCreateWithoutUtilisateurInput, Prisma.sessionUncheckedCreateWithoutUtilisateurInput>;
};
export type sessionCreateManyUtilisateurInputEnvelope = {
    data: Prisma.sessionCreateManyUtilisateurInput | Prisma.sessionCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type sessionUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.sessionWhereUniqueInput;
    update: Prisma.XOR<Prisma.sessionUpdateWithoutUtilisateurInput, Prisma.sessionUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.sessionCreateWithoutUtilisateurInput, Prisma.sessionUncheckedCreateWithoutUtilisateurInput>;
};
export type sessionUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.sessionWhereUniqueInput;
    data: Prisma.XOR<Prisma.sessionUpdateWithoutUtilisateurInput, Prisma.sessionUncheckedUpdateWithoutUtilisateurInput>;
};
export type sessionUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.sessionScalarWhereInput;
    data: Prisma.XOR<Prisma.sessionUpdateManyMutationInput, Prisma.sessionUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type sessionScalarWhereInput = {
    AND?: Prisma.sessionScalarWhereInput | Prisma.sessionScalarWhereInput[];
    OR?: Prisma.sessionScalarWhereInput[];
    NOT?: Prisma.sessionScalarWhereInput | Prisma.sessionScalarWhereInput[];
    id_session?: Prisma.BigIntFilter<"session"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"session"> | bigint | number;
    token_hash?: Prisma.StringFilter<"session"> | string;
    date_connexion?: Prisma.DateTimeFilter<"session"> | Date | string;
    derniere_activite?: Prisma.DateTimeFilter<"session"> | Date | string;
    date_deconnexion?: Prisma.DateTimeNullableFilter<"session"> | Date | string | null;
    statut?: Prisma.StringFilter<"session"> | string;
};
export type sessionCreateManyUtilisateurInput = {
    id_session?: bigint | number;
    token_hash: string;
    date_connexion?: Date | string;
    derniere_activite?: Date | string;
    date_deconnexion?: Date | string | null;
    statut?: string;
};
export type sessionUpdateWithoutUtilisateurInput = {
    id_session?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    token_hash?: Prisma.StringFieldUpdateOperationsInput | string;
    date_connexion?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    derniere_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_deconnexion?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type sessionUncheckedUpdateWithoutUtilisateurInput = {
    id_session?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    token_hash?: Prisma.StringFieldUpdateOperationsInput | string;
    date_connexion?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    derniere_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_deconnexion?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type sessionUncheckedUpdateManyWithoutUtilisateurInput = {
    id_session?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    token_hash?: Prisma.StringFieldUpdateOperationsInput | string;
    date_connexion?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    derniere_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_deconnexion?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    statut?: Prisma.StringFieldUpdateOperationsInput | string;
};
export type sessionSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_session?: boolean;
    id_utilisateur?: boolean;
    token_hash?: boolean;
    date_connexion?: boolean;
    derniere_activite?: boolean;
    date_deconnexion?: boolean;
    statut?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["session"]>;
export type sessionSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_session?: boolean;
    id_utilisateur?: boolean;
    token_hash?: boolean;
    date_connexion?: boolean;
    derniere_activite?: boolean;
    date_deconnexion?: boolean;
    statut?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["session"]>;
export type sessionSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_session?: boolean;
    id_utilisateur?: boolean;
    token_hash?: boolean;
    date_connexion?: boolean;
    derniere_activite?: boolean;
    date_deconnexion?: boolean;
    statut?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["session"]>;
export type sessionSelectScalar = {
    id_session?: boolean;
    id_utilisateur?: boolean;
    token_hash?: boolean;
    date_connexion?: boolean;
    derniere_activite?: boolean;
    date_deconnexion?: boolean;
    statut?: boolean;
};
export type sessionOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_session" | "id_utilisateur" | "token_hash" | "date_connexion" | "derniere_activite" | "date_deconnexion" | "statut", ExtArgs["result"]["session"]>;
export type sessionInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type sessionIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type sessionIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $sessionPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "session";
    objects: {
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_session: bigint;
        id_utilisateur: bigint;
        token_hash: string;
        date_connexion: Date;
        derniere_activite: Date;
        date_deconnexion: Date | null;
        statut: string;
    }, ExtArgs["result"]["session"]>;
    composites: {};
};
export type sessionGetPayload<S extends boolean | null | undefined | sessionDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$sessionPayload, S>;
export type sessionCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<sessionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: SessionCountAggregateInputType | true;
};
export interface sessionDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['session'];
        meta: {
            name: 'session';
        };
    };
    findUnique<T extends sessionFindUniqueArgs>(args: Prisma.SelectSubset<T, sessionFindUniqueArgs<ExtArgs>>): Prisma.Prisma__sessionClient<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends sessionFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, sessionFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__sessionClient<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends sessionFindFirstArgs>(args?: Prisma.SelectSubset<T, sessionFindFirstArgs<ExtArgs>>): Prisma.Prisma__sessionClient<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends sessionFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, sessionFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__sessionClient<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends sessionFindManyArgs>(args?: Prisma.SelectSubset<T, sessionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends sessionCreateArgs>(args: Prisma.SelectSubset<T, sessionCreateArgs<ExtArgs>>): Prisma.Prisma__sessionClient<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends sessionCreateManyArgs>(args?: Prisma.SelectSubset<T, sessionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends sessionCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, sessionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends sessionDeleteArgs>(args: Prisma.SelectSubset<T, sessionDeleteArgs<ExtArgs>>): Prisma.Prisma__sessionClient<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends sessionUpdateArgs>(args: Prisma.SelectSubset<T, sessionUpdateArgs<ExtArgs>>): Prisma.Prisma__sessionClient<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends sessionDeleteManyArgs>(args?: Prisma.SelectSubset<T, sessionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends sessionUpdateManyArgs>(args: Prisma.SelectSubset<T, sessionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends sessionUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, sessionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends sessionUpsertArgs>(args: Prisma.SelectSubset<T, sessionUpsertArgs<ExtArgs>>): Prisma.Prisma__sessionClient<runtime.Types.Result.GetResult<Prisma.$sessionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends sessionCountArgs>(args?: Prisma.Subset<T, sessionCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], SessionCountAggregateOutputType> : number>;
    aggregate<T extends SessionAggregateArgs>(args: Prisma.Subset<T, SessionAggregateArgs>): Prisma.PrismaPromise<GetSessionAggregateType<T>>;
    groupBy<T extends sessionGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: sessionGroupByArgs['orderBy'];
    } : {
        orderBy?: sessionGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, sessionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSessionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: sessionFieldRefs;
}
export interface Prisma__sessionClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    utilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface sessionFieldRefs {
    readonly id_session: Prisma.FieldRef<"session", 'BigInt'>;
    readonly id_utilisateur: Prisma.FieldRef<"session", 'BigInt'>;
    readonly token_hash: Prisma.FieldRef<"session", 'String'>;
    readonly date_connexion: Prisma.FieldRef<"session", 'DateTime'>;
    readonly derniere_activite: Prisma.FieldRef<"session", 'DateTime'>;
    readonly date_deconnexion: Prisma.FieldRef<"session", 'DateTime'>;
    readonly statut: Prisma.FieldRef<"session", 'String'>;
}
export type sessionFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    where: Prisma.sessionWhereUniqueInput;
};
export type sessionFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    where: Prisma.sessionWhereUniqueInput;
};
export type sessionFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    where?: Prisma.sessionWhereInput;
    orderBy?: Prisma.sessionOrderByWithRelationInput | Prisma.sessionOrderByWithRelationInput[];
    cursor?: Prisma.sessionWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.SessionScalarFieldEnum | Prisma.SessionScalarFieldEnum[];
};
export type sessionFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    where?: Prisma.sessionWhereInput;
    orderBy?: Prisma.sessionOrderByWithRelationInput | Prisma.sessionOrderByWithRelationInput[];
    cursor?: Prisma.sessionWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.SessionScalarFieldEnum | Prisma.SessionScalarFieldEnum[];
};
export type sessionFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    where?: Prisma.sessionWhereInput;
    orderBy?: Prisma.sessionOrderByWithRelationInput | Prisma.sessionOrderByWithRelationInput[];
    cursor?: Prisma.sessionWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.SessionScalarFieldEnum | Prisma.SessionScalarFieldEnum[];
};
export type sessionCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.sessionCreateInput, Prisma.sessionUncheckedCreateInput>;
};
export type sessionCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.sessionCreateManyInput | Prisma.sessionCreateManyInput[];
    skipDuplicates?: boolean;
};
export type sessionCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    data: Prisma.sessionCreateManyInput | Prisma.sessionCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.sessionIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type sessionUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.sessionUpdateInput, Prisma.sessionUncheckedUpdateInput>;
    where: Prisma.sessionWhereUniqueInput;
};
export type sessionUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.sessionUpdateManyMutationInput, Prisma.sessionUncheckedUpdateManyInput>;
    where?: Prisma.sessionWhereInput;
    limit?: number;
};
export type sessionUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.sessionUpdateManyMutationInput, Prisma.sessionUncheckedUpdateManyInput>;
    where?: Prisma.sessionWhereInput;
    limit?: number;
    include?: Prisma.sessionIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type sessionUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    where: Prisma.sessionWhereUniqueInput;
    create: Prisma.XOR<Prisma.sessionCreateInput, Prisma.sessionUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.sessionUpdateInput, Prisma.sessionUncheckedUpdateInput>;
};
export type sessionDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
    where: Prisma.sessionWhereUniqueInput;
};
export type sessionDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.sessionWhereInput;
    limit?: number;
};
export type sessionDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.sessionSelect<ExtArgs> | null;
    omit?: Prisma.sessionOmit<ExtArgs> | null;
    include?: Prisma.sessionInclude<ExtArgs> | null;
};
