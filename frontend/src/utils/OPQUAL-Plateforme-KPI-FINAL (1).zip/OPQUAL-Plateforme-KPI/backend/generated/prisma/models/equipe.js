export {};
//# sourceMappingURL=equipe.js.map