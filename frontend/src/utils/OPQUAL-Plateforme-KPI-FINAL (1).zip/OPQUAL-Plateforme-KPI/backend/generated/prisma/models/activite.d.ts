import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type activiteModel = runtime.Types.Result.DefaultSelection<Prisma.$activitePayload>;
export type AggregateActivite = {
    _count: ActiviteCountAggregateOutputType | null;
    _avg: ActiviteAvgAggregateOutputType | null;
    _sum: ActiviteSumAggregateOutputType | null;
    _min: ActiviteMinAggregateOutputType | null;
    _max: ActiviteMaxAggregateOutputType | null;
};
export type ActiviteAvgAggregateOutputType = {
    id_activite: number | null;
    id_tache: number | null;
    id_utilisateur: number | null;
    temps_passe: runtime.Decimal | null;
};
export type ActiviteSumAggregateOutputType = {
    id_activite: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
    temps_passe: runtime.Decimal | null;
};
export type ActiviteMinAggregateOutputType = {
    id_activite: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
    description: string | null;
    temps_passe: runtime.Decimal | null;
    date_activite: Date | null;
};
export type ActiviteMaxAggregateOutputType = {
    id_activite: bigint | null;
    id_tache: bigint | null;
    id_utilisateur: bigint | null;
    description: string | null;
    temps_passe: runtime.Decimal | null;
    date_activite: Date | null;
};
export type ActiviteCountAggregateOutputType = {
    id_activite: number;
    id_tache: number;
    id_utilisateur: number;
    description: number;
    temps_passe: number;
    date_activite: number;
    _all: number;
};
export type ActiviteAvgAggregateInputType = {
    id_activite?: true;
    id_tache?: true;
    id_utilisateur?: true;
    temps_passe?: true;
};
export type ActiviteSumAggregateInputType = {
    id_activite?: true;
    id_tache?: true;
    id_utilisateur?: true;
    temps_passe?: true;
};
export type ActiviteMinAggregateInputType = {
    id_activite?: true;
    id_tache?: true;
    id_utilisateur?: true;
    description?: true;
    temps_passe?: true;
    date_activite?: true;
};
export type ActiviteMaxAggregateInputType = {
    id_activite?: true;
    id_tache?: true;
    id_utilisateur?: true;
    description?: true;
    temps_passe?: true;
    date_activite?: true;
};
export type ActiviteCountAggregateInputType = {
    id_activite?: true;
    id_tache?: true;
    id_utilisateur?: true;
    description?: true;
    temps_passe?: true;
    date_activite?: true;
    _all?: true;
};
export type ActiviteAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.activiteWhereInput;
    orderBy?: Prisma.activiteOrderByWithRelationInput | Prisma.activiteOrderByWithRelationInput[];
    cursor?: Prisma.activiteWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | ActiviteCountAggregateInputType;
    _avg?: ActiviteAvgAggregateInputType;
    _sum?: ActiviteSumAggregateInputType;
    _min?: ActiviteMinAggregateInputType;
    _max?: ActiviteMaxAggregateInputType;
};
export type GetActiviteAggregateType<T extends ActiviteAggregateArgs> = {
    [P in keyof T & keyof AggregateActivite]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateActivite[P]> : Prisma.GetScalarType<T[P], AggregateActivite[P]>;
};
export type activiteGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.activiteWhereInput;
    orderBy?: Prisma.activiteOrderByWithAggregationInput | Prisma.activiteOrderByWithAggregationInput[];
    by: Prisma.ActiviteScalarFieldEnum[] | Prisma.ActiviteScalarFieldEnum;
    having?: Prisma.activiteScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: ActiviteCountAggregateInputType | true;
    _avg?: ActiviteAvgAggregateInputType;
    _sum?: ActiviteSumAggregateInputType;
    _min?: ActiviteMinAggregateInputType;
    _max?: ActiviteMaxAggregateInputType;
};
export type ActiviteGroupByOutputType = {
    id_activite: bigint;
    id_tache: bigint;
    id_utilisateur: bigint;
    description: string | null;
    temps_passe: runtime.Decimal;
    date_activite: Date;
    _count: ActiviteCountAggregateOutputType | null;
    _avg: ActiviteAvgAggregateOutputType | null;
    _sum: ActiviteSumAggregateOutputType | null;
    _min: ActiviteMinAggregateOutputType | null;
    _max: ActiviteMaxAggregateOutputType | null;
};
export type GetActiviteGroupByPayload<T extends activiteGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<ActiviteGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof ActiviteGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], ActiviteGroupByOutputType[P]> : Prisma.GetScalarType<T[P], ActiviteGroupByOutputType[P]>;
}>>;
export type activiteWhereInput = {
    AND?: Prisma.activiteWhereInput | Prisma.activiteWhereInput[];
    OR?: Prisma.activiteWhereInput[];
    NOT?: Prisma.activiteWhereInput | Prisma.activiteWhereInput[];
    id_activite?: Prisma.BigIntFilter<"activite"> | bigint | number;
    id_tache?: Prisma.BigIntFilter<"activite"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"activite"> | bigint | number;
    description?: Prisma.StringNullableFilter<"activite"> | string | null;
    temps_passe?: Prisma.DecimalFilter<"activite"> | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFilter<"activite"> | Date | string;
    tache?: Prisma.XOR<Prisma.TacheScalarRelationFilter, Prisma.tacheWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
};
export type activiteOrderByWithRelationInput = {
    id_activite?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    temps_passe?: Prisma.SortOrder;
    date_activite?: Prisma.SortOrder;
    tache?: Prisma.tacheOrderByWithRelationInput;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
};
export type activiteWhereUniqueInput = Prisma.AtLeast<{
    id_activite?: bigint | number;
    AND?: Prisma.activiteWhereInput | Prisma.activiteWhereInput[];
    OR?: Prisma.activiteWhereInput[];
    NOT?: Prisma.activiteWhereInput | Prisma.activiteWhereInput[];
    id_tache?: Prisma.BigIntFilter<"activite"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"activite"> | bigint | number;
    description?: Prisma.StringNullableFilter<"activite"> | string | null;
    temps_passe?: Prisma.DecimalFilter<"activite"> | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFilter<"activite"> | Date | string;
    tache?: Prisma.XOR<Prisma.TacheScalarRelationFilter, Prisma.tacheWhereInput>;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
}, "id_activite">;
export type activiteOrderByWithAggregationInput = {
    id_activite?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    description?: Prisma.SortOrderInput | Prisma.SortOrder;
    temps_passe?: Prisma.SortOrder;
    date_activite?: Prisma.SortOrder;
    _count?: Prisma.activiteCountOrderByAggregateInput;
    _avg?: Prisma.activiteAvgOrderByAggregateInput;
    _max?: Prisma.activiteMaxOrderByAggregateInput;
    _min?: Prisma.activiteMinOrderByAggregateInput;
    _sum?: Prisma.activiteSumOrderByAggregateInput;
};
export type activiteScalarWhereWithAggregatesInput = {
    AND?: Prisma.activiteScalarWhereWithAggregatesInput | Prisma.activiteScalarWhereWithAggregatesInput[];
    OR?: Prisma.activiteScalarWhereWithAggregatesInput[];
    NOT?: Prisma.activiteScalarWhereWithAggregatesInput | Prisma.activiteScalarWhereWithAggregatesInput[];
    id_activite?: Prisma.BigIntWithAggregatesFilter<"activite"> | bigint | number;
    id_tache?: Prisma.BigIntWithAggregatesFilter<"activite"> | bigint | number;
    id_utilisateur?: Prisma.BigIntWithAggregatesFilter<"activite"> | bigint | number;
    description?: Prisma.StringNullableWithAggregatesFilter<"activite"> | string | null;
    temps_passe?: Prisma.DecimalWithAggregatesFilter<"activite"> | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeWithAggregatesFilter<"activite"> | Date | string;
};
export type activiteCreateInput = {
    id_activite?: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutActiviteInput;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutActiviteInput;
};
export type activiteUncheckedCreateInput = {
    id_activite?: bigint | number;
    id_tache: bigint | number;
    id_utilisateur: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
};
export type activiteUpdateInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutActiviteNestedInput;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutActiviteNestedInput;
};
export type activiteUncheckedUpdateInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type activiteCreateManyInput = {
    id_activite?: bigint | number;
    id_tache: bigint | number;
    id_utilisateur: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
};
export type activiteUpdateManyMutationInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type activiteUncheckedUpdateManyInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type activiteCountOrderByAggregateInput = {
    id_activite?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    temps_passe?: Prisma.SortOrder;
    date_activite?: Prisma.SortOrder;
};
export type activiteAvgOrderByAggregateInput = {
    id_activite?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    temps_passe?: Prisma.SortOrder;
};
export type activiteMaxOrderByAggregateInput = {
    id_activite?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    temps_passe?: Prisma.SortOrder;
    date_activite?: Prisma.SortOrder;
};
export type activiteMinOrderByAggregateInput = {
    id_activite?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    description?: Prisma.SortOrder;
    temps_passe?: Prisma.SortOrder;
    date_activite?: Prisma.SortOrder;
};
export type activiteSumOrderByAggregateInput = {
    id_activite?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    temps_passe?: Prisma.SortOrder;
};
export type ActiviteListRelationFilter = {
    every?: Prisma.activiteWhereInput;
    some?: Prisma.activiteWhereInput;
    none?: Prisma.activiteWhereInput;
};
export type activiteOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type BigIntFieldUpdateOperationsInput = {
    set?: bigint | number;
    increment?: bigint | number;
    decrement?: bigint | number;
    multiply?: bigint | number;
    divide?: bigint | number;
};
export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null;
};
export type DecimalFieldUpdateOperationsInput = {
    set?: runtime.Decimal | runtime.DecimalJsLike | number | string;
    increment?: runtime.Decimal | runtime.DecimalJsLike | number | string;
    decrement?: runtime.Decimal | runtime.DecimalJsLike | number | string;
    multiply?: runtime.Decimal | runtime.DecimalJsLike | number | string;
    divide?: runtime.Decimal | runtime.DecimalJsLike | number | string;
};
export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string;
};
export type activiteCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.activiteCreateWithoutTacheInput, Prisma.activiteUncheckedCreateWithoutTacheInput> | Prisma.activiteCreateWithoutTacheInput[] | Prisma.activiteUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.activiteCreateOrConnectWithoutTacheInput | Prisma.activiteCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.activiteCreateManyTacheInputEnvelope;
    connect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
};
export type activiteUncheckedCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.activiteCreateWithoutTacheInput, Prisma.activiteUncheckedCreateWithoutTacheInput> | Prisma.activiteCreateWithoutTacheInput[] | Prisma.activiteUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.activiteCreateOrConnectWithoutTacheInput | Prisma.activiteCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.activiteCreateManyTacheInputEnvelope;
    connect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
};
export type activiteUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.activiteCreateWithoutTacheInput, Prisma.activiteUncheckedCreateWithoutTacheInput> | Prisma.activiteCreateWithoutTacheInput[] | Prisma.activiteUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.activiteCreateOrConnectWithoutTacheInput | Prisma.activiteCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.activiteUpsertWithWhereUniqueWithoutTacheInput | Prisma.activiteUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.activiteCreateManyTacheInputEnvelope;
    set?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    disconnect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    delete?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    connect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    update?: Prisma.activiteUpdateWithWhereUniqueWithoutTacheInput | Prisma.activiteUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.activiteUpdateManyWithWhereWithoutTacheInput | Prisma.activiteUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.activiteScalarWhereInput | Prisma.activiteScalarWhereInput[];
};
export type activiteUncheckedUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.activiteCreateWithoutTacheInput, Prisma.activiteUncheckedCreateWithoutTacheInput> | Prisma.activiteCreateWithoutTacheInput[] | Prisma.activiteUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.activiteCreateOrConnectWithoutTacheInput | Prisma.activiteCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.activiteUpsertWithWhereUniqueWithoutTacheInput | Prisma.activiteUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.activiteCreateManyTacheInputEnvelope;
    set?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    disconnect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    delete?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    connect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    update?: Prisma.activiteUpdateWithWhereUniqueWithoutTacheInput | Prisma.activiteUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.activiteUpdateManyWithWhereWithoutTacheInput | Prisma.activiteUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.activiteScalarWhereInput | Prisma.activiteScalarWhereInput[];
};
export type activiteCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.activiteCreateWithoutUtilisateurInput, Prisma.activiteUncheckedCreateWithoutUtilisateurInput> | Prisma.activiteCreateWithoutUtilisateurInput[] | Prisma.activiteUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.activiteCreateOrConnectWithoutUtilisateurInput | Prisma.activiteCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.activiteCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
};
export type activiteUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.activiteCreateWithoutUtilisateurInput, Prisma.activiteUncheckedCreateWithoutUtilisateurInput> | Prisma.activiteCreateWithoutUtilisateurInput[] | Prisma.activiteUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.activiteCreateOrConnectWithoutUtilisateurInput | Prisma.activiteCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.activiteCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
};
export type activiteUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.activiteCreateWithoutUtilisateurInput, Prisma.activiteUncheckedCreateWithoutUtilisateurInput> | Prisma.activiteCreateWithoutUtilisateurInput[] | Prisma.activiteUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.activiteCreateOrConnectWithoutUtilisateurInput | Prisma.activiteCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.activiteUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.activiteUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.activiteCreateManyUtilisateurInputEnvelope;
    set?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    disconnect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    delete?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    connect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    update?: Prisma.activiteUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.activiteUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.activiteUpdateManyWithWhereWithoutUtilisateurInput | Prisma.activiteUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.activiteScalarWhereInput | Prisma.activiteScalarWhereInput[];
};
export type activiteUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.activiteCreateWithoutUtilisateurInput, Prisma.activiteUncheckedCreateWithoutUtilisateurInput> | Prisma.activiteCreateWithoutUtilisateurInput[] | Prisma.activiteUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.activiteCreateOrConnectWithoutUtilisateurInput | Prisma.activiteCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.activiteUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.activiteUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.activiteCreateManyUtilisateurInputEnvelope;
    set?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    disconnect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    delete?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    connect?: Prisma.activiteWhereUniqueInput | Prisma.activiteWhereUniqueInput[];
    update?: Prisma.activiteUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.activiteUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.activiteUpdateManyWithWhereWithoutUtilisateurInput | Prisma.activiteUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.activiteScalarWhereInput | Prisma.activiteScalarWhereInput[];
};
export type activiteCreateWithoutTacheInput = {
    id_activite?: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutActiviteInput;
};
export type activiteUncheckedCreateWithoutTacheInput = {
    id_activite?: bigint | number;
    id_utilisateur: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
};
export type activiteCreateOrConnectWithoutTacheInput = {
    where: Prisma.activiteWhereUniqueInput;
    create: Prisma.XOR<Prisma.activiteCreateWithoutTacheInput, Prisma.activiteUncheckedCreateWithoutTacheInput>;
};
export type activiteCreateManyTacheInputEnvelope = {
    data: Prisma.activiteCreateManyTacheInput | Prisma.activiteCreateManyTacheInput[];
    skipDuplicates?: boolean;
};
export type activiteUpsertWithWhereUniqueWithoutTacheInput = {
    where: Prisma.activiteWhereUniqueInput;
    update: Prisma.XOR<Prisma.activiteUpdateWithoutTacheInput, Prisma.activiteUncheckedUpdateWithoutTacheInput>;
    create: Prisma.XOR<Prisma.activiteCreateWithoutTacheInput, Prisma.activiteUncheckedCreateWithoutTacheInput>;
};
export type activiteUpdateWithWhereUniqueWithoutTacheInput = {
    where: Prisma.activiteWhereUniqueInput;
    data: Prisma.XOR<Prisma.activiteUpdateWithoutTacheInput, Prisma.activiteUncheckedUpdateWithoutTacheInput>;
};
export type activiteUpdateManyWithWhereWithoutTacheInput = {
    where: Prisma.activiteScalarWhereInput;
    data: Prisma.XOR<Prisma.activiteUpdateManyMutationInput, Prisma.activiteUncheckedUpdateManyWithoutTacheInput>;
};
export type activiteScalarWhereInput = {
    AND?: Prisma.activiteScalarWhereInput | Prisma.activiteScalarWhereInput[];
    OR?: Prisma.activiteScalarWhereInput[];
    NOT?: Prisma.activiteScalarWhereInput | Prisma.activiteScalarWhereInput[];
    id_activite?: Prisma.BigIntFilter<"activite"> | bigint | number;
    id_tache?: Prisma.BigIntFilter<"activite"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"activite"> | bigint | number;
    description?: Prisma.StringNullableFilter<"activite"> | string | null;
    temps_passe?: Prisma.DecimalFilter<"activite"> | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFilter<"activite"> | Date | string;
};
export type activiteCreateWithoutUtilisateurInput = {
    id_activite?: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutActiviteInput;
};
export type activiteUncheckedCreateWithoutUtilisateurInput = {
    id_activite?: bigint | number;
    id_tache: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
};
export type activiteCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.activiteWhereUniqueInput;
    create: Prisma.XOR<Prisma.activiteCreateWithoutUtilisateurInput, Prisma.activiteUncheckedCreateWithoutUtilisateurInput>;
};
export type activiteCreateManyUtilisateurInputEnvelope = {
    data: Prisma.activiteCreateManyUtilisateurInput | Prisma.activiteCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type activiteUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.activiteWhereUniqueInput;
    update: Prisma.XOR<Prisma.activiteUpdateWithoutUtilisateurInput, Prisma.activiteUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.activiteCreateWithoutUtilisateurInput, Prisma.activiteUncheckedCreateWithoutUtilisateurInput>;
};
export type activiteUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.activiteWhereUniqueInput;
    data: Prisma.XOR<Prisma.activiteUpdateWithoutUtilisateurInput, Prisma.activiteUncheckedUpdateWithoutUtilisateurInput>;
};
export type activiteUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.activiteScalarWhereInput;
    data: Prisma.XOR<Prisma.activiteUpdateManyMutationInput, Prisma.activiteUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type activiteCreateManyTacheInput = {
    id_activite?: bigint | number;
    id_utilisateur: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
};
export type activiteUpdateWithoutTacheInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutActiviteNestedInput;
};
export type activiteUncheckedUpdateWithoutTacheInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type activiteUncheckedUpdateManyWithoutTacheInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type activiteCreateManyUtilisateurInput = {
    id_activite?: bigint | number;
    id_tache: bigint | number;
    description?: string | null;
    temps_passe: runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Date | string;
};
export type activiteUpdateWithoutUtilisateurInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutActiviteNestedInput;
};
export type activiteUncheckedUpdateWithoutUtilisateurInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type activiteUncheckedUpdateManyWithoutUtilisateurInput = {
    id_activite?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    description?: Prisma.NullableStringFieldUpdateOperationsInput | string | null;
    temps_passe?: Prisma.DecimalFieldUpdateOperationsInput | runtime.Decimal | runtime.DecimalJsLike | number | string;
    date_activite?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type activiteSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_activite?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    description?: boolean;
    temps_passe?: boolean;
    date_activite?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["activite"]>;
export type activiteSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_activite?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    description?: boolean;
    temps_passe?: boolean;
    date_activite?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["activite"]>;
export type activiteSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_activite?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    description?: boolean;
    temps_passe?: boolean;
    date_activite?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["activite"]>;
export type activiteSelectScalar = {
    id_activite?: boolean;
    id_tache?: boolean;
    id_utilisateur?: boolean;
    description?: boolean;
    temps_passe?: boolean;
    date_activite?: boolean;
};
export type activiteOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_activite" | "id_tache" | "id_utilisateur" | "description" | "temps_passe" | "date_activite", ExtArgs["result"]["activite"]>;
export type activiteInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type activiteIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type activiteIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $activitePayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "activite";
    objects: {
        tache: Prisma.$tachePayload<ExtArgs>;
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_activite: bigint;
        id_tache: bigint;
        id_utilisateur: bigint;
        description: string | null;
        temps_passe: runtime.Decimal;
        date_activite: Date;
    }, ExtArgs["result"]["activite"]>;
    composites: {};
};
export type activiteGetPayload<S extends boolean | null | undefined | activiteDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$activitePayload, S>;
export type activiteCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<activiteFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: ActiviteCountAggregateInputType | true;
};
export interface activiteDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['activite'];
        meta: {
            name: 'activite';
        };
    };
    findUnique<T extends activiteFindUniqueArgs>(args: Prisma.SelectSubset<T, activiteFindUniqueArgs<ExtArgs>>): Prisma.Prisma__activiteClient<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends activiteFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, activiteFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__activiteClient<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends activiteFindFirstArgs>(args?: Prisma.SelectSubset<T, activiteFindFirstArgs<ExtArgs>>): Prisma.Prisma__activiteClient<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends activiteFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, activiteFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__activiteClient<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends activiteFindManyArgs>(args?: Prisma.SelectSubset<T, activiteFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends activiteCreateArgs>(args: Prisma.SelectSubset<T, activiteCreateArgs<ExtArgs>>): Prisma.Prisma__activiteClient<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends activiteCreateManyArgs>(args?: Prisma.SelectSubset<T, activiteCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends activiteCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, activiteCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends activiteDeleteArgs>(args: Prisma.SelectSubset<T, activiteDeleteArgs<ExtArgs>>): Prisma.Prisma__activiteClient<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends activiteUpdateArgs>(args: Prisma.SelectSubset<T, activiteUpdateArgs<ExtArgs>>): Prisma.Prisma__activiteClient<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends activiteDeleteManyArgs>(args?: Prisma.SelectSubset<T, activiteDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends activiteUpdateManyArgs>(args: Prisma.SelectSubset<T, activiteUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends activiteUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, activiteUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends activiteUpsertArgs>(args: Prisma.SelectSubset<T, activiteUpsertArgs<ExtArgs>>): Prisma.Prisma__activiteClient<runtime.Types.Result.GetResult<Prisma.$activitePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends activiteCountArgs>(args?: Prisma.Subset<T, activiteCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], ActiviteCountAggregateOutputType> : number>;
    aggregate<T extends ActiviteAggregateArgs>(args: Prisma.Subset<T, ActiviteAggregateArgs>): Prisma.PrismaPromise<GetActiviteAggregateType<T>>;
    groupBy<T extends activiteGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: activiteGroupByArgs['orderBy'];
    } : {
        orderBy?: activiteGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, activiteGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetActiviteGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: activiteFieldRefs;
}
export interface Prisma__activiteClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    tache<T extends Prisma.tacheDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.tacheDefaultArgs<ExtArgs>>): Prisma.Prisma__tacheClient<runtime.Types.Result.GetResult<Prisma.$tachePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    utilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface activiteFieldRefs {
    readonly id_activite: Prisma.FieldRef<"activite", 'BigInt'>;
    readonly id_tache: Prisma.FieldRef<"activite", 'BigInt'>;
    readonly id_utilisateur: Prisma.FieldRef<"activite", 'BigInt'>;
    readonly description: Prisma.FieldRef<"activite", 'String'>;
    readonly temps_passe: Prisma.FieldRef<"activite", 'Decimal'>;
    readonly date_activite: Prisma.FieldRef<"activite", 'DateTime'>;
}
export type activiteFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    where: Prisma.activiteWhereUniqueInput;
};
export type activiteFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    where: Prisma.activiteWhereUniqueInput;
};
export type activiteFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    where?: Prisma.activiteWhereInput;
    orderBy?: Prisma.activiteOrderByWithRelationInput | Prisma.activiteOrderByWithRelationInput[];
    cursor?: Prisma.activiteWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ActiviteScalarFieldEnum | Prisma.ActiviteScalarFieldEnum[];
};
export type activiteFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    where?: Prisma.activiteWhereInput;
    orderBy?: Prisma.activiteOrderByWithRelationInput | Prisma.activiteOrderByWithRelationInput[];
    cursor?: Prisma.activiteWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ActiviteScalarFieldEnum | Prisma.ActiviteScalarFieldEnum[];
};
export type activiteFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    where?: Prisma.activiteWhereInput;
    orderBy?: Prisma.activiteOrderByWithRelationInput | Prisma.activiteOrderByWithRelationInput[];
    cursor?: Prisma.activiteWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ActiviteScalarFieldEnum | Prisma.ActiviteScalarFieldEnum[];
};
export type activiteCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.activiteCreateInput, Prisma.activiteUncheckedCreateInput>;
};
export type activiteCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.activiteCreateManyInput | Prisma.activiteCreateManyInput[];
    skipDuplicates?: boolean;
};
export type activiteCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    data: Prisma.activiteCreateManyInput | Prisma.activiteCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.activiteIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type activiteUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.activiteUpdateInput, Prisma.activiteUncheckedUpdateInput>;
    where: Prisma.activiteWhereUniqueInput;
};
export type activiteUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.activiteUpdateManyMutationInput, Prisma.activiteUncheckedUpdateManyInput>;
    where?: Prisma.activiteWhereInput;
    limit?: number;
};
export type activiteUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.activiteUpdateManyMutationInput, Prisma.activiteUncheckedUpdateManyInput>;
    where?: Prisma.activiteWhereInput;
    limit?: number;
    include?: Prisma.activiteIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type activiteUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    where: Prisma.activiteWhereUniqueInput;
    create: Prisma.XOR<Prisma.activiteCreateInput, Prisma.activiteUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.activiteUpdateInput, Prisma.activiteUncheckedUpdateInput>;
};
export type activiteDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
    where: Prisma.activiteWhereUniqueInput;
};
export type activiteDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.activiteWhereInput;
    limit?: number;
};
export type activiteDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.activiteSelect<ExtArgs> | null;
    omit?: Prisma.activiteOmit<ExtArgs> | null;
    include?: Prisma.activiteInclude<ExtArgs> | null;
};
