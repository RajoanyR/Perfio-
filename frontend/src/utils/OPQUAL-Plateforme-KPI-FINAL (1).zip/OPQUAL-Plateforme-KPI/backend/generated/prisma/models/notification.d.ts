import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type notificationModel = runtime.Types.Result.DefaultSelection<Prisma.$notificationPayload>;
export type AggregateNotification = {
    _count: NotificationCountAggregateOutputType | null;
    _avg: NotificationAvgAggregateOutputType | null;
    _sum: NotificationSumAggregateOutputType | null;
    _min: NotificationMinAggregateOutputType | null;
    _max: NotificationMaxAggregateOutputType | null;
};
export type NotificationAvgAggregateOutputType = {
    id_notification: number | null;
    id_utilisateur: number | null;
};
export type NotificationSumAggregateOutputType = {
    id_notification: bigint | null;
    id_utilisateur: bigint | null;
};
export type NotificationMinAggregateOutputType = {
    id_notification: bigint | null;
    id_utilisateur: bigint | null;
    type: string | null;
    message: string | null;
    est_lue: boolean | null;
    date_creation: Date | null;
    date_lecture: Date | null;
};
export type NotificationMaxAggregateOutputType = {
    id_notification: bigint | null;
    id_utilisateur: bigint | null;
    type: string | null;
    message: string | null;
    est_lue: boolean | null;
    date_creation: Date | null;
    date_lecture: Date | null;
};
export type NotificationCountAggregateOutputType = {
    id_notification: number;
    id_utilisateur: number;
    type: number;
    message: number;
    est_lue: number;
    date_creation: number;
    date_lecture: number;
    _all: number;
};
export type NotificationAvgAggregateInputType = {
    id_notification?: true;
    id_utilisateur?: true;
};
export type NotificationSumAggregateInputType = {
    id_notification?: true;
    id_utilisateur?: true;
};
export type NotificationMinAggregateInputType = {
    id_notification?: true;
    id_utilisateur?: true;
    type?: true;
    message?: true;
    est_lue?: true;
    date_creation?: true;
    date_lecture?: true;
};
export type NotificationMaxAggregateInputType = {
    id_notification?: true;
    id_utilisateur?: true;
    type?: true;
    message?: true;
    est_lue?: true;
    date_creation?: true;
    date_lecture?: true;
};
export type NotificationCountAggregateInputType = {
    id_notification?: true;
    id_utilisateur?: true;
    type?: true;
    message?: true;
    est_lue?: true;
    date_creation?: true;
    date_lecture?: true;
    _all?: true;
};
export type NotificationAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.notificationWhereInput;
    orderBy?: Prisma.notificationOrderByWithRelationInput | Prisma.notificationOrderByWithRelationInput[];
    cursor?: Prisma.notificationWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | NotificationCountAggregateInputType;
    _avg?: NotificationAvgAggregateInputType;
    _sum?: NotificationSumAggregateInputType;
    _min?: NotificationMinAggregateInputType;
    _max?: NotificationMaxAggregateInputType;
};
export type GetNotificationAggregateType<T extends NotificationAggregateArgs> = {
    [P in keyof T & keyof AggregateNotification]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateNotification[P]> : Prisma.GetScalarType<T[P], AggregateNotification[P]>;
};
export type notificationGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.notificationWhereInput;
    orderBy?: Prisma.notificationOrderByWithAggregationInput | Prisma.notificationOrderByWithAggregationInput[];
    by: Prisma.NotificationScalarFieldEnum[] | Prisma.NotificationScalarFieldEnum;
    having?: Prisma.notificationScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: NotificationCountAggregateInputType | true;
    _avg?: NotificationAvgAggregateInputType;
    _sum?: NotificationSumAggregateInputType;
    _min?: NotificationMinAggregateInputType;
    _max?: NotificationMaxAggregateInputType;
};
export type NotificationGroupByOutputType = {
    id_notification: bigint;
    id_utilisateur: bigint;
    type: string;
    message: string;
    est_lue: boolean;
    date_creation: Date;
    date_lecture: Date | null;
    _count: NotificationCountAggregateOutputType | null;
    _avg: NotificationAvgAggregateOutputType | null;
    _sum: NotificationSumAggregateOutputType | null;
    _min: NotificationMinAggregateOutputType | null;
    _max: NotificationMaxAggregateOutputType | null;
};
export type GetNotificationGroupByPayload<T extends notificationGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<NotificationGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof NotificationGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], NotificationGroupByOutputType[P]> : Prisma.GetScalarType<T[P], NotificationGroupByOutputType[P]>;
}>>;
export type notificationWhereInput = {
    AND?: Prisma.notificationWhereInput | Prisma.notificationWhereInput[];
    OR?: Prisma.notificationWhereInput[];
    NOT?: Prisma.notificationWhereInput | Prisma.notificationWhereInput[];
    id_notification?: Prisma.BigIntFilter<"notification"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"notification"> | bigint | number;
    type?: Prisma.StringFilter<"notification"> | string;
    message?: Prisma.StringFilter<"notification"> | string;
    est_lue?: Prisma.BoolFilter<"notification"> | boolean;
    date_creation?: Prisma.DateTimeFilter<"notification"> | Date | string;
    date_lecture?: Prisma.DateTimeNullableFilter<"notification"> | Date | string | null;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
};
export type notificationOrderByWithRelationInput = {
    id_notification?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    message?: Prisma.SortOrder;
    est_lue?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_lecture?: Prisma.SortOrderInput | Prisma.SortOrder;
    utilisateur?: Prisma.utilisateurOrderByWithRelationInput;
};
export type notificationWhereUniqueInput = Prisma.AtLeast<{
    id_notification?: bigint | number;
    AND?: Prisma.notificationWhereInput | Prisma.notificationWhereInput[];
    OR?: Prisma.notificationWhereInput[];
    NOT?: Prisma.notificationWhereInput | Prisma.notificationWhereInput[];
    id_utilisateur?: Prisma.BigIntFilter<"notification"> | bigint | number;
    type?: Prisma.StringFilter<"notification"> | string;
    message?: Prisma.StringFilter<"notification"> | string;
    est_lue?: Prisma.BoolFilter<"notification"> | boolean;
    date_creation?: Prisma.DateTimeFilter<"notification"> | Date | string;
    date_lecture?: Prisma.DateTimeNullableFilter<"notification"> | Date | string | null;
    utilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
}, "id_notification">;
export type notificationOrderByWithAggregationInput = {
    id_notification?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    message?: Prisma.SortOrder;
    est_lue?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_lecture?: Prisma.SortOrderInput | Prisma.SortOrder;
    _count?: Prisma.notificationCountOrderByAggregateInput;
    _avg?: Prisma.notificationAvgOrderByAggregateInput;
    _max?: Prisma.notificationMaxOrderByAggregateInput;
    _min?: Prisma.notificationMinOrderByAggregateInput;
    _sum?: Prisma.notificationSumOrderByAggregateInput;
};
export type notificationScalarWhereWithAggregatesInput = {
    AND?: Prisma.notificationScalarWhereWithAggregatesInput | Prisma.notificationScalarWhereWithAggregatesInput[];
    OR?: Prisma.notificationScalarWhereWithAggregatesInput[];
    NOT?: Prisma.notificationScalarWhereWithAggregatesInput | Prisma.notificationScalarWhereWithAggregatesInput[];
    id_notification?: Prisma.BigIntWithAggregatesFilter<"notification"> | bigint | number;
    id_utilisateur?: Prisma.BigIntWithAggregatesFilter<"notification"> | bigint | number;
    type?: Prisma.StringWithAggregatesFilter<"notification"> | string;
    message?: Prisma.StringWithAggregatesFilter<"notification"> | string;
    est_lue?: Prisma.BoolWithAggregatesFilter<"notification"> | boolean;
    date_creation?: Prisma.DateTimeWithAggregatesFilter<"notification"> | Date | string;
    date_lecture?: Prisma.DateTimeNullableWithAggregatesFilter<"notification"> | Date | string | null;
};
export type notificationCreateInput = {
    id_notification?: bigint | number;
    type: string;
    message: string;
    est_lue?: boolean;
    date_creation?: Date | string;
    date_lecture?: Date | string | null;
    utilisateur: Prisma.utilisateurCreateNestedOneWithoutNotificationInput;
};
export type notificationUncheckedCreateInput = {
    id_notification?: bigint | number;
    id_utilisateur: bigint | number;
    type: string;
    message: string;
    est_lue?: boolean;
    date_creation?: Date | string;
    date_lecture?: Date | string | null;
};
export type notificationUpdateInput = {
    id_notification?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    message?: Prisma.StringFieldUpdateOperationsInput | string;
    est_lue?: Prisma.BoolFieldUpdateOperationsInput | boolean;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_lecture?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    utilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutNotificationNestedInput;
};
export type notificationUncheckedUpdateInput = {
    id_notification?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    message?: Prisma.StringFieldUpdateOperationsInput | string;
    est_lue?: Prisma.BoolFieldUpdateOperationsInput | boolean;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_lecture?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type notificationCreateManyInput = {
    id_notification?: bigint | number;
    id_utilisateur: bigint | number;
    type: string;
    message: string;
    est_lue?: boolean;
    date_creation?: Date | string;
    date_lecture?: Date | string | null;
};
export type notificationUpdateManyMutationInput = {
    id_notification?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    message?: Prisma.StringFieldUpdateOperationsInput | string;
    est_lue?: Prisma.BoolFieldUpdateOperationsInput | boolean;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_lecture?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type notificationUncheckedUpdateManyInput = {
    id_notification?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_utilisateur?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    message?: Prisma.StringFieldUpdateOperationsInput | string;
    est_lue?: Prisma.BoolFieldUpdateOperationsInput | boolean;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_lecture?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type notificationCountOrderByAggregateInput = {
    id_notification?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    message?: Prisma.SortOrder;
    est_lue?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_lecture?: Prisma.SortOrder;
};
export type notificationAvgOrderByAggregateInput = {
    id_notification?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type notificationMaxOrderByAggregateInput = {
    id_notification?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    message?: Prisma.SortOrder;
    est_lue?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_lecture?: Prisma.SortOrder;
};
export type notificationMinOrderByAggregateInput = {
    id_notification?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
    type?: Prisma.SortOrder;
    message?: Prisma.SortOrder;
    est_lue?: Prisma.SortOrder;
    date_creation?: Prisma.SortOrder;
    date_lecture?: Prisma.SortOrder;
};
export type notificationSumOrderByAggregateInput = {
    id_notification?: Prisma.SortOrder;
    id_utilisateur?: Prisma.SortOrder;
};
export type NotificationListRelationFilter = {
    every?: Prisma.notificationWhereInput;
    some?: Prisma.notificationWhereInput;
    none?: Prisma.notificationWhereInput;
};
export type notificationOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type BoolFieldUpdateOperationsInput = {
    set?: boolean;
};
export type notificationCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.notificationCreateWithoutUtilisateurInput, Prisma.notificationUncheckedCreateWithoutUtilisateurInput> | Prisma.notificationCreateWithoutUtilisateurInput[] | Prisma.notificationUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.notificationCreateOrConnectWithoutUtilisateurInput | Prisma.notificationCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.notificationCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
};
export type notificationUncheckedCreateNestedManyWithoutUtilisateurInput = {
    create?: Prisma.XOR<Prisma.notificationCreateWithoutUtilisateurInput, Prisma.notificationUncheckedCreateWithoutUtilisateurInput> | Prisma.notificationCreateWithoutUtilisateurInput[] | Prisma.notificationUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.notificationCreateOrConnectWithoutUtilisateurInput | Prisma.notificationCreateOrConnectWithoutUtilisateurInput[];
    createMany?: Prisma.notificationCreateManyUtilisateurInputEnvelope;
    connect?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
};
export type notificationUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.notificationCreateWithoutUtilisateurInput, Prisma.notificationUncheckedCreateWithoutUtilisateurInput> | Prisma.notificationCreateWithoutUtilisateurInput[] | Prisma.notificationUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.notificationCreateOrConnectWithoutUtilisateurInput | Prisma.notificationCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.notificationUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.notificationUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.notificationCreateManyUtilisateurInputEnvelope;
    set?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
    disconnect?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
    delete?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
    connect?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
    update?: Prisma.notificationUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.notificationUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.notificationUpdateManyWithWhereWithoutUtilisateurInput | Prisma.notificationUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.notificationScalarWhereInput | Prisma.notificationScalarWhereInput[];
};
export type notificationUncheckedUpdateManyWithoutUtilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.notificationCreateWithoutUtilisateurInput, Prisma.notificationUncheckedCreateWithoutUtilisateurInput> | Prisma.notificationCreateWithoutUtilisateurInput[] | Prisma.notificationUncheckedCreateWithoutUtilisateurInput[];
    connectOrCreate?: Prisma.notificationCreateOrConnectWithoutUtilisateurInput | Prisma.notificationCreateOrConnectWithoutUtilisateurInput[];
    upsert?: Prisma.notificationUpsertWithWhereUniqueWithoutUtilisateurInput | Prisma.notificationUpsertWithWhereUniqueWithoutUtilisateurInput[];
    createMany?: Prisma.notificationCreateManyUtilisateurInputEnvelope;
    set?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
    disconnect?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
    delete?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
    connect?: Prisma.notificationWhereUniqueInput | Prisma.notificationWhereUniqueInput[];
    update?: Prisma.notificationUpdateWithWhereUniqueWithoutUtilisateurInput | Prisma.notificationUpdateWithWhereUniqueWithoutUtilisateurInput[];
    updateMany?: Prisma.notificationUpdateManyWithWhereWithoutUtilisateurInput | Prisma.notificationUpdateManyWithWhereWithoutUtilisateurInput[];
    deleteMany?: Prisma.notificationScalarWhereInput | Prisma.notificationScalarWhereInput[];
};
export type notificationCreateWithoutUtilisateurInput = {
    id_notification?: bigint | number;
    type: string;
    message: string;
    est_lue?: boolean;
    date_creation?: Date | string;
    date_lecture?: Date | string | null;
};
export type notificationUncheckedCreateWithoutUtilisateurInput = {
    id_notification?: bigint | number;
    type: string;
    message: string;
    est_lue?: boolean;
    date_creation?: Date | string;
    date_lecture?: Date | string | null;
};
export type notificationCreateOrConnectWithoutUtilisateurInput = {
    where: Prisma.notificationWhereUniqueInput;
    create: Prisma.XOR<Prisma.notificationCreateWithoutUtilisateurInput, Prisma.notificationUncheckedCreateWithoutUtilisateurInput>;
};
export type notificationCreateManyUtilisateurInputEnvelope = {
    data: Prisma.notificationCreateManyUtilisateurInput | Prisma.notificationCreateManyUtilisateurInput[];
    skipDuplicates?: boolean;
};
export type notificationUpsertWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.notificationWhereUniqueInput;
    update: Prisma.XOR<Prisma.notificationUpdateWithoutUtilisateurInput, Prisma.notificationUncheckedUpdateWithoutUtilisateurInput>;
    create: Prisma.XOR<Prisma.notificationCreateWithoutUtilisateurInput, Prisma.notificationUncheckedCreateWithoutUtilisateurInput>;
};
export type notificationUpdateWithWhereUniqueWithoutUtilisateurInput = {
    where: Prisma.notificationWhereUniqueInput;
    data: Prisma.XOR<Prisma.notificationUpdateWithoutUtilisateurInput, Prisma.notificationUncheckedUpdateWithoutUtilisateurInput>;
};
export type notificationUpdateManyWithWhereWithoutUtilisateurInput = {
    where: Prisma.notificationScalarWhereInput;
    data: Prisma.XOR<Prisma.notificationUpdateManyMutationInput, Prisma.notificationUncheckedUpdateManyWithoutUtilisateurInput>;
};
export type notificationScalarWhereInput = {
    AND?: Prisma.notificationScalarWhereInput | Prisma.notificationScalarWhereInput[];
    OR?: Prisma.notificationScalarWhereInput[];
    NOT?: Prisma.notificationScalarWhereInput | Prisma.notificationScalarWhereInput[];
    id_notification?: Prisma.BigIntFilter<"notification"> | bigint | number;
    id_utilisateur?: Prisma.BigIntFilter<"notification"> | bigint | number;
    type?: Prisma.StringFilter<"notification"> | string;
    message?: Prisma.StringFilter<"notification"> | string;
    est_lue?: Prisma.BoolFilter<"notification"> | boolean;
    date_creation?: Prisma.DateTimeFilter<"notification"> | Date | string;
    date_lecture?: Prisma.DateTimeNullableFilter<"notification"> | Date | string | null;
};
export type notificationCreateManyUtilisateurInput = {
    id_notification?: bigint | number;
    type: string;
    message: string;
    est_lue?: boolean;
    date_creation?: Date | string;
    date_lecture?: Date | string | null;
};
export type notificationUpdateWithoutUtilisateurInput = {
    id_notification?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    message?: Prisma.StringFieldUpdateOperationsInput | string;
    est_lue?: Prisma.BoolFieldUpdateOperationsInput | boolean;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_lecture?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type notificationUncheckedUpdateWithoutUtilisateurInput = {
    id_notification?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    message?: Prisma.StringFieldUpdateOperationsInput | string;
    est_lue?: Prisma.BoolFieldUpdateOperationsInput | boolean;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_lecture?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type notificationUncheckedUpdateManyWithoutUtilisateurInput = {
    id_notification?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    type?: Prisma.StringFieldUpdateOperationsInput | string;
    message?: Prisma.StringFieldUpdateOperationsInput | string;
    est_lue?: Prisma.BoolFieldUpdateOperationsInput | boolean;
    date_creation?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    date_lecture?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type notificationSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_notification?: boolean;
    id_utilisateur?: boolean;
    type?: boolean;
    message?: boolean;
    est_lue?: boolean;
    date_creation?: boolean;
    date_lecture?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["notification"]>;
export type notificationSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_notification?: boolean;
    id_utilisateur?: boolean;
    type?: boolean;
    message?: boolean;
    est_lue?: boolean;
    date_creation?: boolean;
    date_lecture?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["notification"]>;
export type notificationSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_notification?: boolean;
    id_utilisateur?: boolean;
    type?: boolean;
    message?: boolean;
    est_lue?: boolean;
    date_creation?: boolean;
    date_lecture?: boolean;
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["notification"]>;
export type notificationSelectScalar = {
    id_notification?: boolean;
    id_utilisateur?: boolean;
    type?: boolean;
    message?: boolean;
    est_lue?: boolean;
    date_creation?: boolean;
    date_lecture?: boolean;
};
export type notificationOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_notification" | "id_utilisateur" | "type" | "message" | "est_lue" | "date_creation" | "date_lecture", ExtArgs["result"]["notification"]>;
export type notificationInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type notificationIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type notificationIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    utilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $notificationPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "notification";
    objects: {
        utilisateur: Prisma.$utilisateurPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_notification: bigint;
        id_utilisateur: bigint;
        type: string;
        message: string;
        est_lue: boolean;
        date_creation: Date;
        date_lecture: Date | null;
    }, ExtArgs["result"]["notification"]>;
    composites: {};
};
export type notificationGetPayload<S extends boolean | null | undefined | notificationDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$notificationPayload, S>;
export type notificationCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<notificationFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: NotificationCountAggregateInputType | true;
};
export interface notificationDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['notification'];
        meta: {
            name: 'notification';
        };
    };
    findUnique<T extends notificationFindUniqueArgs>(args: Prisma.SelectSubset<T, notificationFindUniqueArgs<ExtArgs>>): Prisma.Prisma__notificationClient<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends notificationFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, notificationFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__notificationClient<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends notificationFindFirstArgs>(args?: Prisma.SelectSubset<T, notificationFindFirstArgs<ExtArgs>>): Prisma.Prisma__notificationClient<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends notificationFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, notificationFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__notificationClient<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends notificationFindManyArgs>(args?: Prisma.SelectSubset<T, notificationFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends notificationCreateArgs>(args: Prisma.SelectSubset<T, notificationCreateArgs<ExtArgs>>): Prisma.Prisma__notificationClient<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends notificationCreateManyArgs>(args?: Prisma.SelectSubset<T, notificationCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends notificationCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, notificationCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends notificationDeleteArgs>(args: Prisma.SelectSubset<T, notificationDeleteArgs<ExtArgs>>): Prisma.Prisma__notificationClient<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends notificationUpdateArgs>(args: Prisma.SelectSubset<T, notificationUpdateArgs<ExtArgs>>): Prisma.Prisma__notificationClient<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends notificationDeleteManyArgs>(args?: Prisma.SelectSubset<T, notificationDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends notificationUpdateManyArgs>(args: Prisma.SelectSubset<T, notificationUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends notificationUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, notificationUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends notificationUpsertArgs>(args: Prisma.SelectSubset<T, notificationUpsertArgs<ExtArgs>>): Prisma.Prisma__notificationClient<runtime.Types.Result.GetResult<Prisma.$notificationPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends notificationCountArgs>(args?: Prisma.Subset<T, notificationCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], NotificationCountAggregateOutputType> : number>;
    aggregate<T extends NotificationAggregateArgs>(args: Prisma.Subset<T, NotificationAggregateArgs>): Prisma.PrismaPromise<GetNotificationAggregateType<T>>;
    groupBy<T extends notificationGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: notificationGroupByArgs['orderBy'];
    } : {
        orderBy?: notificationGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, notificationGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetNotificationGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: notificationFieldRefs;
}
export interface Prisma__notificationClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    utilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface notificationFieldRefs {
    readonly id_notification: Prisma.FieldRef<"notification", 'BigInt'>;
    readonly id_utilisateur: Prisma.FieldRef<"notification", 'BigInt'>;
    readonly type: Prisma.FieldRef<"notification", 'String'>;
    readonly message: Prisma.FieldRef<"notification", 'String'>;
    readonly est_lue: Prisma.FieldRef<"notification", 'Boolean'>;
    readonly date_creation: Prisma.FieldRef<"notification", 'DateTime'>;
    readonly date_lecture: Prisma.FieldRef<"notification", 'DateTime'>;
}
export type notificationFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    where: Prisma.notificationWhereUniqueInput;
};
export type notificationFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    where: Prisma.notificationWhereUniqueInput;
};
export type notificationFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    where?: Prisma.notificationWhereInput;
    orderBy?: Prisma.notificationOrderByWithRelationInput | Prisma.notificationOrderByWithRelationInput[];
    cursor?: Prisma.notificationWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.NotificationScalarFieldEnum | Prisma.NotificationScalarFieldEnum[];
};
export type notificationFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    where?: Prisma.notificationWhereInput;
    orderBy?: Prisma.notificationOrderByWithRelationInput | Prisma.notificationOrderByWithRelationInput[];
    cursor?: Prisma.notificationWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.NotificationScalarFieldEnum | Prisma.NotificationScalarFieldEnum[];
};
export type notificationFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    where?: Prisma.notificationWhereInput;
    orderBy?: Prisma.notificationOrderByWithRelationInput | Prisma.notificationOrderByWithRelationInput[];
    cursor?: Prisma.notificationWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.NotificationScalarFieldEnum | Prisma.NotificationScalarFieldEnum[];
};
export type notificationCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.notificationCreateInput, Prisma.notificationUncheckedCreateInput>;
};
export type notificationCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.notificationCreateManyInput | Prisma.notificationCreateManyInput[];
    skipDuplicates?: boolean;
};
export type notificationCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    data: Prisma.notificationCreateManyInput | Prisma.notificationCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.notificationIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type notificationUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.notificationUpdateInput, Prisma.notificationUncheckedUpdateInput>;
    where: Prisma.notificationWhereUniqueInput;
};
export type notificationUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.notificationUpdateManyMutationInput, Prisma.notificationUncheckedUpdateManyInput>;
    where?: Prisma.notificationWhereInput;
    limit?: number;
};
export type notificationUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.notificationUpdateManyMutationInput, Prisma.notificationUncheckedUpdateManyInput>;
    where?: Prisma.notificationWhereInput;
    limit?: number;
    include?: Prisma.notificationIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type notificationUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    where: Prisma.notificationWhereUniqueInput;
    create: Prisma.XOR<Prisma.notificationCreateInput, Prisma.notificationUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.notificationUpdateInput, Prisma.notificationUncheckedUpdateInput>;
};
export type notificationDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
    where: Prisma.notificationWhereUniqueInput;
};
export type notificationDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.notificationWhereInput;
    limit?: number;
};
export type notificationDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.notificationSelect<ExtArgs> | null;
    omit?: Prisma.notificationOmit<ExtArgs> | null;
    include?: Prisma.notificationInclude<ExtArgs> | null;
};
