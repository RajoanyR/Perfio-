export {};
//# sourceMappingURL=role_permission.js.map