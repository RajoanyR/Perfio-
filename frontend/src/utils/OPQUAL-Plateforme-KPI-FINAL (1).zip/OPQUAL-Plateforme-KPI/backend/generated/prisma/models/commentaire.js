export {};
//# sourceMappingURL=commentaire.js.map