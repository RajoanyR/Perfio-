import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace.js";
export type transfert_tacheModel = runtime.Types.Result.DefaultSelection<Prisma.$transfert_tachePayload>;
export type AggregateTransfert_tache = {
    _count: Transfert_tacheCountAggregateOutputType | null;
    _avg: Transfert_tacheAvgAggregateOutputType | null;
    _sum: Transfert_tacheSumAggregateOutputType | null;
    _min: Transfert_tacheMinAggregateOutputType | null;
    _max: Transfert_tacheMaxAggregateOutputType | null;
};
export type Transfert_tacheAvgAggregateOutputType = {
    id_transfert: number | null;
    id_tache: number | null;
    ancien_responsable: number | null;
    nouveau_responsable: number | null;
    ancienne_equipe: number | null;
    nouvelle_equipe: number | null;
    utilisateur_transfert: number | null;
};
export type Transfert_tacheSumAggregateOutputType = {
    id_transfert: bigint | null;
    id_tache: bigint | null;
    ancien_responsable: bigint | null;
    nouveau_responsable: bigint | null;
    ancienne_equipe: bigint | null;
    nouvelle_equipe: bigint | null;
    utilisateur_transfert: bigint | null;
};
export type Transfert_tacheMinAggregateOutputType = {
    id_transfert: bigint | null;
    id_tache: bigint | null;
    ancien_responsable: bigint | null;
    nouveau_responsable: bigint | null;
    ancienne_equipe: bigint | null;
    nouvelle_equipe: bigint | null;
    utilisateur_transfert: bigint | null;
    motif: string | null;
    date_transfert: Date | null;
};
export type Transfert_tacheMaxAggregateOutputType = {
    id_transfert: bigint | null;
    id_tache: bigint | null;
    ancien_responsable: bigint | null;
    nouveau_responsable: bigint | null;
    ancienne_equipe: bigint | null;
    nouvelle_equipe: bigint | null;
    utilisateur_transfert: bigint | null;
    motif: string | null;
    date_transfert: Date | null;
};
export type Transfert_tacheCountAggregateOutputType = {
    id_transfert: number;
    id_tache: number;
    ancien_responsable: number;
    nouveau_responsable: number;
    ancienne_equipe: number;
    nouvelle_equipe: number;
    utilisateur_transfert: number;
    motif: number;
    date_transfert: number;
    _all: number;
};
export type Transfert_tacheAvgAggregateInputType = {
    id_transfert?: true;
    id_tache?: true;
    ancien_responsable?: true;
    nouveau_responsable?: true;
    ancienne_equipe?: true;
    nouvelle_equipe?: true;
    utilisateur_transfert?: true;
};
export type Transfert_tacheSumAggregateInputType = {
    id_transfert?: true;
    id_tache?: true;
    ancien_responsable?: true;
    nouveau_responsable?: true;
    ancienne_equipe?: true;
    nouvelle_equipe?: true;
    utilisateur_transfert?: true;
};
export type Transfert_tacheMinAggregateInputType = {
    id_transfert?: true;
    id_tache?: true;
    ancien_responsable?: true;
    nouveau_responsable?: true;
    ancienne_equipe?: true;
    nouvelle_equipe?: true;
    utilisateur_transfert?: true;
    motif?: true;
    date_transfert?: true;
};
export type Transfert_tacheMaxAggregateInputType = {
    id_transfert?: true;
    id_tache?: true;
    ancien_responsable?: true;
    nouveau_responsable?: true;
    ancienne_equipe?: true;
    nouvelle_equipe?: true;
    utilisateur_transfert?: true;
    motif?: true;
    date_transfert?: true;
};
export type Transfert_tacheCountAggregateInputType = {
    id_transfert?: true;
    id_tache?: true;
    ancien_responsable?: true;
    nouveau_responsable?: true;
    ancienne_equipe?: true;
    nouvelle_equipe?: true;
    utilisateur_transfert?: true;
    motif?: true;
    date_transfert?: true;
    _all?: true;
};
export type Transfert_tacheAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.transfert_tacheWhereInput;
    orderBy?: Prisma.transfert_tacheOrderByWithRelationInput | Prisma.transfert_tacheOrderByWithRelationInput[];
    cursor?: Prisma.transfert_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | Transfert_tacheCountAggregateInputType;
    _avg?: Transfert_tacheAvgAggregateInputType;
    _sum?: Transfert_tacheSumAggregateInputType;
    _min?: Transfert_tacheMinAggregateInputType;
    _max?: Transfert_tacheMaxAggregateInputType;
};
export type GetTransfert_tacheAggregateType<T extends Transfert_tacheAggregateArgs> = {
    [P in keyof T & keyof AggregateTransfert_tache]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateTransfert_tache[P]> : Prisma.GetScalarType<T[P], AggregateTransfert_tache[P]>;
};
export type transfert_tacheGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.transfert_tacheWhereInput;
    orderBy?: Prisma.transfert_tacheOrderByWithAggregationInput | Prisma.transfert_tacheOrderByWithAggregationInput[];
    by: Prisma.Transfert_tacheScalarFieldEnum[] | Prisma.Transfert_tacheScalarFieldEnum;
    having?: Prisma.transfert_tacheScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: Transfert_tacheCountAggregateInputType | true;
    _avg?: Transfert_tacheAvgAggregateInputType;
    _sum?: Transfert_tacheSumAggregateInputType;
    _min?: Transfert_tacheMinAggregateInputType;
    _max?: Transfert_tacheMaxAggregateInputType;
};
export type Transfert_tacheGroupByOutputType = {
    id_transfert: bigint;
    id_tache: bigint;
    ancien_responsable: bigint;
    nouveau_responsable: bigint;
    ancienne_equipe: bigint;
    nouvelle_equipe: bigint;
    utilisateur_transfert: bigint;
    motif: string;
    date_transfert: Date;
    _count: Transfert_tacheCountAggregateOutputType | null;
    _avg: Transfert_tacheAvgAggregateOutputType | null;
    _sum: Transfert_tacheSumAggregateOutputType | null;
    _min: Transfert_tacheMinAggregateOutputType | null;
    _max: Transfert_tacheMaxAggregateOutputType | null;
};
export type GetTransfert_tacheGroupByPayload<T extends transfert_tacheGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<Transfert_tacheGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof Transfert_tacheGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], Transfert_tacheGroupByOutputType[P]> : Prisma.GetScalarType<T[P], Transfert_tacheGroupByOutputType[P]>;
}>>;
export type transfert_tacheWhereInput = {
    AND?: Prisma.transfert_tacheWhereInput | Prisma.transfert_tacheWhereInput[];
    OR?: Prisma.transfert_tacheWhereInput[];
    NOT?: Prisma.transfert_tacheWhereInput | Prisma.transfert_tacheWhereInput[];
    id_transfert?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    id_tache?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    ancien_responsable?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    nouveau_responsable?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    ancienne_equipe?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    motif?: Prisma.StringFilter<"transfert_tache"> | string;
    date_transfert?: Prisma.DateTimeFilter<"transfert_tache"> | Date | string;
    tache?: Prisma.XOR<Prisma.TacheScalarRelationFilter, Prisma.tacheWhereInput>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.XOR<Prisma.EquipeScalarRelationFilter, Prisma.equipeWhereInput>;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.XOR<Prisma.EquipeScalarRelationFilter, Prisma.equipeWhereInput>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
};
export type transfert_tacheOrderByWithRelationInput = {
    id_transfert?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    ancien_responsable?: Prisma.SortOrder;
    nouveau_responsable?: Prisma.SortOrder;
    ancienne_equipe?: Prisma.SortOrder;
    nouvelle_equipe?: Prisma.SortOrder;
    utilisateur_transfert?: Prisma.SortOrder;
    motif?: Prisma.SortOrder;
    date_transfert?: Prisma.SortOrder;
    tache?: Prisma.tacheOrderByWithRelationInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.utilisateurOrderByWithRelationInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.utilisateurOrderByWithRelationInput;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.equipeOrderByWithRelationInput;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.equipeOrderByWithRelationInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.utilisateurOrderByWithRelationInput;
};
export type transfert_tacheWhereUniqueInput = Prisma.AtLeast<{
    id_transfert?: bigint | number;
    AND?: Prisma.transfert_tacheWhereInput | Prisma.transfert_tacheWhereInput[];
    OR?: Prisma.transfert_tacheWhereInput[];
    NOT?: Prisma.transfert_tacheWhereInput | Prisma.transfert_tacheWhereInput[];
    id_tache?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    ancien_responsable?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    nouveau_responsable?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    ancienne_equipe?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    motif?: Prisma.StringFilter<"transfert_tache"> | string;
    date_transfert?: Prisma.DateTimeFilter<"transfert_tache"> | Date | string;
    tache?: Prisma.XOR<Prisma.TacheScalarRelationFilter, Prisma.tacheWhereInput>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.XOR<Prisma.EquipeScalarRelationFilter, Prisma.equipeWhereInput>;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.XOR<Prisma.EquipeScalarRelationFilter, Prisma.equipeWhereInput>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.XOR<Prisma.UtilisateurScalarRelationFilter, Prisma.utilisateurWhereInput>;
}, "id_transfert">;
export type transfert_tacheOrderByWithAggregationInput = {
    id_transfert?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    ancien_responsable?: Prisma.SortOrder;
    nouveau_responsable?: Prisma.SortOrder;
    ancienne_equipe?: Prisma.SortOrder;
    nouvelle_equipe?: Prisma.SortOrder;
    utilisateur_transfert?: Prisma.SortOrder;
    motif?: Prisma.SortOrder;
    date_transfert?: Prisma.SortOrder;
    _count?: Prisma.transfert_tacheCountOrderByAggregateInput;
    _avg?: Prisma.transfert_tacheAvgOrderByAggregateInput;
    _max?: Prisma.transfert_tacheMaxOrderByAggregateInput;
    _min?: Prisma.transfert_tacheMinOrderByAggregateInput;
    _sum?: Prisma.transfert_tacheSumOrderByAggregateInput;
};
export type transfert_tacheScalarWhereWithAggregatesInput = {
    AND?: Prisma.transfert_tacheScalarWhereWithAggregatesInput | Prisma.transfert_tacheScalarWhereWithAggregatesInput[];
    OR?: Prisma.transfert_tacheScalarWhereWithAggregatesInput[];
    NOT?: Prisma.transfert_tacheScalarWhereWithAggregatesInput | Prisma.transfert_tacheScalarWhereWithAggregatesInput[];
    id_transfert?: Prisma.BigIntWithAggregatesFilter<"transfert_tache"> | bigint | number;
    id_tache?: Prisma.BigIntWithAggregatesFilter<"transfert_tache"> | bigint | number;
    ancien_responsable?: Prisma.BigIntWithAggregatesFilter<"transfert_tache"> | bigint | number;
    nouveau_responsable?: Prisma.BigIntWithAggregatesFilter<"transfert_tache"> | bigint | number;
    ancienne_equipe?: Prisma.BigIntWithAggregatesFilter<"transfert_tache"> | bigint | number;
    nouvelle_equipe?: Prisma.BigIntWithAggregatesFilter<"transfert_tache"> | bigint | number;
    utilisateur_transfert?: Prisma.BigIntWithAggregatesFilter<"transfert_tache"> | bigint | number;
    motif?: Prisma.StringWithAggregatesFilter<"transfert_tache"> | string;
    date_transfert?: Prisma.DateTimeWithAggregatesFilter<"transfert_tache"> | Date | string;
};
export type transfert_tacheCreateInput = {
    id_transfert?: bigint | number;
    motif: string;
    date_transfert?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutTransfert_tacheInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurInput;
    equipe_transfert_tache_ancienne_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    equipe_transfert_tache_nouvelle_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurInput;
};
export type transfert_tacheUncheckedCreateInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheUpdateInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutTransfert_tacheNestedInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurNestedInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurNestedInput;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeNestedInput;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurNestedInput;
};
export type transfert_tacheUncheckedUpdateInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheCreateManyInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheUpdateManyMutationInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUncheckedUpdateManyInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type Transfert_tacheListRelationFilter = {
    every?: Prisma.transfert_tacheWhereInput;
    some?: Prisma.transfert_tacheWhereInput;
    none?: Prisma.transfert_tacheWhereInput;
};
export type transfert_tacheOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type transfert_tacheCountOrderByAggregateInput = {
    id_transfert?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    ancien_responsable?: Prisma.SortOrder;
    nouveau_responsable?: Prisma.SortOrder;
    ancienne_equipe?: Prisma.SortOrder;
    nouvelle_equipe?: Prisma.SortOrder;
    utilisateur_transfert?: Prisma.SortOrder;
    motif?: Prisma.SortOrder;
    date_transfert?: Prisma.SortOrder;
};
export type transfert_tacheAvgOrderByAggregateInput = {
    id_transfert?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    ancien_responsable?: Prisma.SortOrder;
    nouveau_responsable?: Prisma.SortOrder;
    ancienne_equipe?: Prisma.SortOrder;
    nouvelle_equipe?: Prisma.SortOrder;
    utilisateur_transfert?: Prisma.SortOrder;
};
export type transfert_tacheMaxOrderByAggregateInput = {
    id_transfert?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    ancien_responsable?: Prisma.SortOrder;
    nouveau_responsable?: Prisma.SortOrder;
    ancienne_equipe?: Prisma.SortOrder;
    nouvelle_equipe?: Prisma.SortOrder;
    utilisateur_transfert?: Prisma.SortOrder;
    motif?: Prisma.SortOrder;
    date_transfert?: Prisma.SortOrder;
};
export type transfert_tacheMinOrderByAggregateInput = {
    id_transfert?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    ancien_responsable?: Prisma.SortOrder;
    nouveau_responsable?: Prisma.SortOrder;
    ancienne_equipe?: Prisma.SortOrder;
    nouvelle_equipe?: Prisma.SortOrder;
    utilisateur_transfert?: Prisma.SortOrder;
    motif?: Prisma.SortOrder;
    date_transfert?: Prisma.SortOrder;
};
export type transfert_tacheSumOrderByAggregateInput = {
    id_transfert?: Prisma.SortOrder;
    id_tache?: Prisma.SortOrder;
    ancien_responsable?: Prisma.SortOrder;
    nouveau_responsable?: Prisma.SortOrder;
    ancienne_equipe?: Prisma.SortOrder;
    nouvelle_equipe?: Prisma.SortOrder;
    utilisateur_transfert?: Prisma.SortOrder;
};
export type transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput> | Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[] | Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    createMany?: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_ancienne_equipeToequipeInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput> | Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[] | Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    createMany?: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_nouvelle_equipeToequipeInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput> | Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[] | Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    createMany?: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_ancienne_equipeToequipeInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUncheckedCreateNestedManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput> | Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[] | Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    createMany?: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_nouvelle_equipeToequipeInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput> | Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[] | Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    createMany?: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_ancienne_equipeToequipeInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput> | Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[] | Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    createMany?: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_nouvelle_equipeToequipeInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput> | Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[] | Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    createMany?: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_ancienne_equipeToequipeInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput> | Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[] | Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    createMany?: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_nouvelle_equipeToequipeInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutTacheInput, Prisma.transfert_tacheUncheckedCreateWithoutTacheInput> | Prisma.transfert_tacheCreateWithoutTacheInput[] | Prisma.transfert_tacheUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutTacheInput | Prisma.transfert_tacheCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.transfert_tacheCreateManyTacheInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUncheckedCreateNestedManyWithoutTacheInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutTacheInput, Prisma.transfert_tacheUncheckedCreateWithoutTacheInput> | Prisma.transfert_tacheCreateWithoutTacheInput[] | Prisma.transfert_tacheUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutTacheInput | Prisma.transfert_tacheCreateOrConnectWithoutTacheInput[];
    createMany?: Prisma.transfert_tacheCreateManyTacheInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutTacheInput, Prisma.transfert_tacheUncheckedCreateWithoutTacheInput> | Prisma.transfert_tacheCreateWithoutTacheInput[] | Prisma.transfert_tacheUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutTacheInput | Prisma.transfert_tacheCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutTacheInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.transfert_tacheCreateManyTacheInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutTacheInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutTacheInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUncheckedUpdateManyWithoutTacheNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutTacheInput, Prisma.transfert_tacheUncheckedCreateWithoutTacheInput> | Prisma.transfert_tacheCreateWithoutTacheInput[] | Prisma.transfert_tacheUncheckedCreateWithoutTacheInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutTacheInput | Prisma.transfert_tacheCreateOrConnectWithoutTacheInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutTacheInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutTacheInput[];
    createMany?: Prisma.transfert_tacheCreateManyTacheInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutTacheInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutTacheInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutTacheInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutTacheInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheCreateNestedManyWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_ancien_responsableToutilisateurInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheCreateNestedManyWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_nouveau_responsableToutilisateurInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheCreateNestedManyWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUncheckedCreateNestedManyWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_ancien_responsableToutilisateurInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUncheckedCreateNestedManyWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_nouveau_responsableToutilisateurInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUncheckedCreateNestedManyWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInputEnvelope;
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
};
export type transfert_tacheUpdateManyWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_ancien_responsableToutilisateurInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUpdateManyWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_nouveau_responsableToutilisateurInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUpdateManyWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_ancien_responsableToutilisateurInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_nouveau_responsableToutilisateurInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurNestedInput = {
    create?: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput> | Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[] | Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    connectOrCreate?: Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    upsert?: Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    createMany?: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInputEnvelope;
    set?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    disconnect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    delete?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    connect?: Prisma.transfert_tacheWhereUniqueInput | Prisma.transfert_tacheWhereUniqueInput[];
    update?: Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    updateMany?: Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    deleteMany?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
};
export type transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    id_transfert?: bigint | number;
    motif: string;
    date_transfert?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutTransfert_tacheInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurInput;
    equipe_transfert_tache_nouvelle_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurInput;
};
export type transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput>;
};
export type transfert_tacheCreateManyEquipe_transfert_tache_ancienne_equipeToequipeInputEnvelope = {
    data: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_ancienne_equipeToequipeInput | Prisma.transfert_tacheCreateManyEquipe_transfert_tache_ancienne_equipeToequipeInput[];
    skipDuplicates?: boolean;
};
export type transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    id_transfert?: bigint | number;
    motif: string;
    date_transfert?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutTransfert_tacheInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurInput;
    equipe_transfert_tache_ancienne_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurInput;
};
export type transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateOrConnectWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput>;
};
export type transfert_tacheCreateManyEquipe_transfert_tache_nouvelle_equipeToequipeInputEnvelope = {
    data: Prisma.transfert_tacheCreateManyEquipe_transfert_tache_nouvelle_equipeToequipeInput | Prisma.transfert_tacheCreateManyEquipe_transfert_tache_nouvelle_equipeToequipeInput[];
    skipDuplicates?: boolean;
};
export type transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    update: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput, Prisma.transfert_tacheUncheckedUpdateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput>;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput>;
};
export type transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput, Prisma.transfert_tacheUncheckedUpdateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput>;
};
export type transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    where: Prisma.transfert_tacheScalarWhereInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateManyMutationInput, Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput>;
};
export type transfert_tacheScalarWhereInput = {
    AND?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
    OR?: Prisma.transfert_tacheScalarWhereInput[];
    NOT?: Prisma.transfert_tacheScalarWhereInput | Prisma.transfert_tacheScalarWhereInput[];
    id_transfert?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    id_tache?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    ancien_responsable?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    nouveau_responsable?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    ancienne_equipe?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFilter<"transfert_tache"> | bigint | number;
    motif?: Prisma.StringFilter<"transfert_tache"> | string;
    date_transfert?: Prisma.DateTimeFilter<"transfert_tache"> | Date | string;
};
export type transfert_tacheUpsertWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    update: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput, Prisma.transfert_tacheUncheckedUpdateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput>;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput, Prisma.transfert_tacheUncheckedCreateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput>;
};
export type transfert_tacheUpdateWithWhereUniqueWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput, Prisma.transfert_tacheUncheckedUpdateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput>;
};
export type transfert_tacheUpdateManyWithWhereWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    where: Prisma.transfert_tacheScalarWhereInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateManyMutationInput, Prisma.transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput>;
};
export type transfert_tacheCreateWithoutTacheInput = {
    id_transfert?: bigint | number;
    motif: string;
    date_transfert?: Date | string;
    utilisateur_transfert_tache_ancien_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurInput;
    equipe_transfert_tache_ancienne_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    equipe_transfert_tache_nouvelle_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurInput;
};
export type transfert_tacheUncheckedCreateWithoutTacheInput = {
    id_transfert?: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateOrConnectWithoutTacheInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutTacheInput, Prisma.transfert_tacheUncheckedCreateWithoutTacheInput>;
};
export type transfert_tacheCreateManyTacheInputEnvelope = {
    data: Prisma.transfert_tacheCreateManyTacheInput | Prisma.transfert_tacheCreateManyTacheInput[];
    skipDuplicates?: boolean;
};
export type transfert_tacheUpsertWithWhereUniqueWithoutTacheInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    update: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutTacheInput, Prisma.transfert_tacheUncheckedUpdateWithoutTacheInput>;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutTacheInput, Prisma.transfert_tacheUncheckedCreateWithoutTacheInput>;
};
export type transfert_tacheUpdateWithWhereUniqueWithoutTacheInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutTacheInput, Prisma.transfert_tacheUncheckedUpdateWithoutTacheInput>;
};
export type transfert_tacheUpdateManyWithWhereWithoutTacheInput = {
    where: Prisma.transfert_tacheScalarWhereInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateManyMutationInput, Prisma.transfert_tacheUncheckedUpdateManyWithoutTacheInput>;
};
export type transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    id_transfert?: bigint | number;
    motif: string;
    date_transfert?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutTransfert_tacheInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurInput;
    equipe_transfert_tache_ancienne_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    equipe_transfert_tache_nouvelle_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurInput;
};
export type transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput>;
};
export type transfert_tacheCreateManyUtilisateur_transfert_tache_ancien_responsableToutilisateurInputEnvelope = {
    data: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_ancien_responsableToutilisateurInput | Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_ancien_responsableToutilisateurInput[];
    skipDuplicates?: boolean;
};
export type transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    id_transfert?: bigint | number;
    motif: string;
    date_transfert?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutTransfert_tacheInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurInput;
    equipe_transfert_tache_ancienne_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    equipe_transfert_tache_nouvelle_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurInput;
};
export type transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput>;
};
export type transfert_tacheCreateManyUtilisateur_transfert_tache_nouveau_responsableToutilisateurInputEnvelope = {
    data: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput | Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput[];
    skipDuplicates?: boolean;
};
export type transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    id_transfert?: bigint | number;
    motif: string;
    date_transfert?: Date | string;
    tache: Prisma.tacheCreateNestedOneWithoutTransfert_tacheInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur: Prisma.utilisateurCreateNestedOneWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurInput;
    equipe_transfert_tache_ancienne_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeInput;
    equipe_transfert_tache_nouvelle_equipeToequipe: Prisma.equipeCreateNestedOneWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeInput;
};
export type transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateOrConnectWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput>;
};
export type transfert_tacheCreateManyUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInputEnvelope = {
    data: Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput | Prisma.transfert_tacheCreateManyUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput[];
    skipDuplicates?: boolean;
};
export type transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    update: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput>;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput>;
};
export type transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput>;
};
export type transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    where: Prisma.transfert_tacheScalarWhereInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateManyMutationInput, Prisma.transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput>;
};
export type transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    update: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput>;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput>;
};
export type transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput, Prisma.transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput>;
};
export type transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    where: Prisma.transfert_tacheScalarWhereInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateManyMutationInput, Prisma.transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput>;
};
export type transfert_tacheUpsertWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    update: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput, Prisma.transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput>;
    create: Prisma.XOR<Prisma.transfert_tacheCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput, Prisma.transfert_tacheUncheckedCreateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput>;
};
export type transfert_tacheUpdateWithWhereUniqueWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    where: Prisma.transfert_tacheWhereUniqueInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput, Prisma.transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput>;
};
export type transfert_tacheUpdateManyWithWhereWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    where: Prisma.transfert_tacheScalarWhereInput;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateManyMutationInput, Prisma.transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput>;
};
export type transfert_tacheCreateManyEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateManyEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheUpdateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutTransfert_tacheNestedInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurNestedInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurNestedInput;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurNestedInput;
};
export type transfert_tacheUncheckedUpdateWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_ancienne_equipeToequipeInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUpdateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutTransfert_tacheNestedInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurNestedInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurNestedInput;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeNestedInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurNestedInput;
};
export type transfert_tacheUncheckedUpdateWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUncheckedUpdateManyWithoutEquipe_transfert_tache_nouvelle_equipeToequipeInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheCreateManyTacheInput = {
    id_transfert?: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheUpdateWithoutTacheInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurNestedInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurNestedInput;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeNestedInput;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurNestedInput;
};
export type transfert_tacheUncheckedUpdateWithoutTacheInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUncheckedUpdateManyWithoutTacheInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheCreateManyUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateManyUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    utilisateur_transfert: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheCreateManyUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    id_transfert?: bigint | number;
    id_tache: bigint | number;
    ancien_responsable: bigint | number;
    nouveau_responsable: bigint | number;
    ancienne_equipe: bigint | number;
    nouvelle_equipe: bigint | number;
    motif: string;
    date_transfert?: Date | string;
};
export type transfert_tacheUpdateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutTransfert_tacheNestedInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurNestedInput;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeNestedInput;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurNestedInput;
};
export type transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_ancien_responsableToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUpdateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutTransfert_tacheNestedInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurNestedInput;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeNestedInput;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeNestedInput;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_utilisateur_transfertToutilisateurNestedInput;
};
export type transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_nouveau_responsableToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    utilisateur_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUpdateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    tache?: Prisma.tacheUpdateOneRequiredWithoutTransfert_tacheNestedInput;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancien_responsableToutilisateurNestedInput;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: Prisma.utilisateurUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouveau_responsableToutilisateurNestedInput;
    equipe_transfert_tache_ancienne_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_ancienne_equipeToequipeNestedInput;
    equipe_transfert_tache_nouvelle_equipeToequipe?: Prisma.equipeUpdateOneRequiredWithoutTransfert_tache_transfert_tache_nouvelle_equipeToequipeNestedInput;
};
export type transfert_tacheUncheckedUpdateWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheUncheckedUpdateManyWithoutUtilisateur_transfert_tache_utilisateur_transfertToutilisateurInput = {
    id_transfert?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    id_tache?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancien_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouveau_responsable?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    ancienne_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    nouvelle_equipe?: Prisma.BigIntFieldUpdateOperationsInput | bigint | number;
    motif?: Prisma.StringFieldUpdateOperationsInput | string;
    date_transfert?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type transfert_tacheSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_transfert?: boolean;
    id_tache?: boolean;
    ancien_responsable?: boolean;
    nouveau_responsable?: boolean;
    ancienne_equipe?: boolean;
    nouvelle_equipe?: boolean;
    utilisateur_transfert?: boolean;
    motif?: boolean;
    date_transfert?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    equipe_transfert_tache_ancienne_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    equipe_transfert_tache_nouvelle_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["transfert_tache"]>;
export type transfert_tacheSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_transfert?: boolean;
    id_tache?: boolean;
    ancien_responsable?: boolean;
    nouveau_responsable?: boolean;
    ancienne_equipe?: boolean;
    nouvelle_equipe?: boolean;
    utilisateur_transfert?: boolean;
    motif?: boolean;
    date_transfert?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    equipe_transfert_tache_ancienne_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    equipe_transfert_tache_nouvelle_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["transfert_tache"]>;
export type transfert_tacheSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id_transfert?: boolean;
    id_tache?: boolean;
    ancien_responsable?: boolean;
    nouveau_responsable?: boolean;
    ancienne_equipe?: boolean;
    nouvelle_equipe?: boolean;
    utilisateur_transfert?: boolean;
    motif?: boolean;
    date_transfert?: boolean;
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    equipe_transfert_tache_ancienne_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    equipe_transfert_tache_nouvelle_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["transfert_tache"]>;
export type transfert_tacheSelectScalar = {
    id_transfert?: boolean;
    id_tache?: boolean;
    ancien_responsable?: boolean;
    nouveau_responsable?: boolean;
    ancienne_equipe?: boolean;
    nouvelle_equipe?: boolean;
    utilisateur_transfert?: boolean;
    motif?: boolean;
    date_transfert?: boolean;
};
export type transfert_tacheOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id_transfert" | "id_tache" | "ancien_responsable" | "nouveau_responsable" | "ancienne_equipe" | "nouvelle_equipe" | "utilisateur_transfert" | "motif" | "date_transfert", ExtArgs["result"]["transfert_tache"]>;
export type transfert_tacheInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    equipe_transfert_tache_ancienne_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    equipe_transfert_tache_nouvelle_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type transfert_tacheIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    equipe_transfert_tache_ancienne_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    equipe_transfert_tache_nouvelle_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type transfert_tacheIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    tache?: boolean | Prisma.tacheDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
    equipe_transfert_tache_ancienne_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    equipe_transfert_tache_nouvelle_equipeToequipe?: boolean | Prisma.equipeDefaultArgs<ExtArgs>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur?: boolean | Prisma.utilisateurDefaultArgs<ExtArgs>;
};
export type $transfert_tachePayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "transfert_tache";
    objects: {
        tache: Prisma.$tachePayload<ExtArgs>;
        utilisateur_transfert_tache_ancien_responsableToutilisateur: Prisma.$utilisateurPayload<ExtArgs>;
        utilisateur_transfert_tache_nouveau_responsableToutilisateur: Prisma.$utilisateurPayload<ExtArgs>;
        equipe_transfert_tache_ancienne_equipeToequipe: Prisma.$equipePayload<ExtArgs>;
        equipe_transfert_tache_nouvelle_equipeToequipe: Prisma.$equipePayload<ExtArgs>;
        utilisateur_transfert_tache_utilisateur_transfertToutilisateur: Prisma.$utilisateurPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id_transfert: bigint;
        id_tache: bigint;
        ancien_responsable: bigint;
        nouveau_responsable: bigint;
        ancienne_equipe: bigint;
        nouvelle_equipe: bigint;
        utilisateur_transfert: bigint;
        motif: string;
        date_transfert: Date;
    }, ExtArgs["result"]["transfert_tache"]>;
    composites: {};
};
export type transfert_tacheGetPayload<S extends boolean | null | undefined | transfert_tacheDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload, S>;
export type transfert_tacheCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<transfert_tacheFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: Transfert_tacheCountAggregateInputType | true;
};
export interface transfert_tacheDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['transfert_tache'];
        meta: {
            name: 'transfert_tache';
        };
    };
    findUnique<T extends transfert_tacheFindUniqueArgs>(args: Prisma.SelectSubset<T, transfert_tacheFindUniqueArgs<ExtArgs>>): Prisma.Prisma__transfert_tacheClient<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends transfert_tacheFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, transfert_tacheFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__transfert_tacheClient<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends transfert_tacheFindFirstArgs>(args?: Prisma.SelectSubset<T, transfert_tacheFindFirstArgs<ExtArgs>>): Prisma.Prisma__transfert_tacheClient<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends transfert_tacheFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, transfert_tacheFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__transfert_tacheClient<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends transfert_tacheFindManyArgs>(args?: Prisma.SelectSubset<T, transfert_tacheFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends transfert_tacheCreateArgs>(args: Prisma.SelectSubset<T, transfert_tacheCreateArgs<ExtArgs>>): Prisma.Prisma__transfert_tacheClient<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends transfert_tacheCreateManyArgs>(args?: Prisma.SelectSubset<T, transfert_tacheCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends transfert_tacheCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, transfert_tacheCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends transfert_tacheDeleteArgs>(args: Prisma.SelectSubset<T, transfert_tacheDeleteArgs<ExtArgs>>): Prisma.Prisma__transfert_tacheClient<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends transfert_tacheUpdateArgs>(args: Prisma.SelectSubset<T, transfert_tacheUpdateArgs<ExtArgs>>): Prisma.Prisma__transfert_tacheClient<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends transfert_tacheDeleteManyArgs>(args?: Prisma.SelectSubset<T, transfert_tacheDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends transfert_tacheUpdateManyArgs>(args: Prisma.SelectSubset<T, transfert_tacheUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends transfert_tacheUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, transfert_tacheUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends transfert_tacheUpsertArgs>(args: Prisma.SelectSubset<T, transfert_tacheUpsertArgs<ExtArgs>>): Prisma.Prisma__transfert_tacheClient<runtime.Types.Result.GetResult<Prisma.$transfert_tachePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends transfert_tacheCountArgs>(args?: Prisma.Subset<T, transfert_tacheCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], Transfert_tacheCountAggregateOutputType> : number>;
    aggregate<T extends Transfert_tacheAggregateArgs>(args: Prisma.Subset<T, Transfert_tacheAggregateArgs>): Prisma.PrismaPromise<GetTransfert_tacheAggregateType<T>>;
    groupBy<T extends transfert_tacheGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: transfert_tacheGroupByArgs['orderBy'];
    } : {
        orderBy?: transfert_tacheGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, transfert_tacheGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTransfert_tacheGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: transfert_tacheFieldRefs;
}
export interface Prisma__transfert_tacheClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    tache<T extends Prisma.tacheDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.tacheDefaultArgs<ExtArgs>>): Prisma.Prisma__tacheClient<runtime.Types.Result.GetResult<Prisma.$tachePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    utilisateur_transfert_tache_ancien_responsableToutilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    utilisateur_transfert_tache_nouveau_responsableToutilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    equipe_transfert_tache_ancienne_equipeToequipe<T extends Prisma.equipeDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.equipeDefaultArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    equipe_transfert_tache_nouvelle_equipeToequipe<T extends Prisma.equipeDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.equipeDefaultArgs<ExtArgs>>): Prisma.Prisma__equipeClient<runtime.Types.Result.GetResult<Prisma.$equipePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    utilisateur_transfert_tache_utilisateur_transfertToutilisateur<T extends Prisma.utilisateurDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.utilisateurDefaultArgs<ExtArgs>>): Prisma.Prisma__utilisateurClient<runtime.Types.Result.GetResult<Prisma.$utilisateurPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface transfert_tacheFieldRefs {
    readonly id_transfert: Prisma.FieldRef<"transfert_tache", 'BigInt'>;
    readonly id_tache: Prisma.FieldRef<"transfert_tache", 'BigInt'>;
    readonly ancien_responsable: Prisma.FieldRef<"transfert_tache", 'BigInt'>;
    readonly nouveau_responsable: Prisma.FieldRef<"transfert_tache", 'BigInt'>;
    readonly ancienne_equipe: Prisma.FieldRef<"transfert_tache", 'BigInt'>;
    readonly nouvelle_equipe: Prisma.FieldRef<"transfert_tache", 'BigInt'>;
    readonly utilisateur_transfert: Prisma.FieldRef<"transfert_tache", 'BigInt'>;
    readonly motif: Prisma.FieldRef<"transfert_tache", 'String'>;
    readonly date_transfert: Prisma.FieldRef<"transfert_tache", 'DateTime'>;
}
export type transfert_tacheFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where: Prisma.transfert_tacheWhereUniqueInput;
};
export type transfert_tacheFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where: Prisma.transfert_tacheWhereUniqueInput;
};
export type transfert_tacheFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where?: Prisma.transfert_tacheWhereInput;
    orderBy?: Prisma.transfert_tacheOrderByWithRelationInput | Prisma.transfert_tacheOrderByWithRelationInput[];
    cursor?: Prisma.transfert_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Transfert_tacheScalarFieldEnum | Prisma.Transfert_tacheScalarFieldEnum[];
};
export type transfert_tacheFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where?: Prisma.transfert_tacheWhereInput;
    orderBy?: Prisma.transfert_tacheOrderByWithRelationInput | Prisma.transfert_tacheOrderByWithRelationInput[];
    cursor?: Prisma.transfert_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Transfert_tacheScalarFieldEnum | Prisma.Transfert_tacheScalarFieldEnum[];
};
export type transfert_tacheFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where?: Prisma.transfert_tacheWhereInput;
    orderBy?: Prisma.transfert_tacheOrderByWithRelationInput | Prisma.transfert_tacheOrderByWithRelationInput[];
    cursor?: Prisma.transfert_tacheWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.Transfert_tacheScalarFieldEnum | Prisma.Transfert_tacheScalarFieldEnum[];
};
export type transfert_tacheCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.transfert_tacheCreateInput, Prisma.transfert_tacheUncheckedCreateInput>;
};
export type transfert_tacheCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.transfert_tacheCreateManyInput | Prisma.transfert_tacheCreateManyInput[];
    skipDuplicates?: boolean;
};
export type transfert_tacheCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    data: Prisma.transfert_tacheCreateManyInput | Prisma.transfert_tacheCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.transfert_tacheIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type transfert_tacheUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateInput, Prisma.transfert_tacheUncheckedUpdateInput>;
    where: Prisma.transfert_tacheWhereUniqueInput;
};
export type transfert_tacheUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.transfert_tacheUpdateManyMutationInput, Prisma.transfert_tacheUncheckedUpdateManyInput>;
    where?: Prisma.transfert_tacheWhereInput;
    limit?: number;
};
export type transfert_tacheUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.transfert_tacheUpdateManyMutationInput, Prisma.transfert_tacheUncheckedUpdateManyInput>;
    where?: Prisma.transfert_tacheWhereInput;
    limit?: number;
    include?: Prisma.transfert_tacheIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type transfert_tacheUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where: Prisma.transfert_tacheWhereUniqueInput;
    create: Prisma.XOR<Prisma.transfert_tacheCreateInput, Prisma.transfert_tacheUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.transfert_tacheUpdateInput, Prisma.transfert_tacheUncheckedUpdateInput>;
};
export type transfert_tacheDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
    where: Prisma.transfert_tacheWhereUniqueInput;
};
export type transfert_tacheDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.transfert_tacheWhereInput;
    limit?: number;
};
export type transfert_tacheDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.transfert_tacheSelect<ExtArgs> | null;
    omit?: Prisma.transfert_tacheOmit<ExtArgs> | null;
    include?: Prisma.transfert_tacheInclude<ExtArgs> | null;
};
