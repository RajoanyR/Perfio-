export {};
//# sourceMappingURL=utilisateur.js.map